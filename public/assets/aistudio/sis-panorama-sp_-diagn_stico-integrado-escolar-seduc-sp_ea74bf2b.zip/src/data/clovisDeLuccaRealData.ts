import { 
  SchoolProfile, 
  PlatformDataRecord, 
  TurmaPerformance, 
  ActionPlanItem, 
  HistoricalSnapshot 
} from '../types';

export const CLOVIS_DE_LUCCA_PROFILE: SchoolProfile = {
  nome: 'EE Professor Clovis de Lucca',
  codCIE: '009124',
  diretoriaEnsino: 'Diretoria de Ensino Região São Bernardo do Campo (Cód. 10606)',
  municipio: 'São Bernardo do Campo - SP',
  modelo: 'PEI_7H',
  segmentos: [
    'Ensino Fundamental Anos Finais (6º ao 9º ano)',
    'Novo Ensino Médio Integral (1ª à 3ª série)',
    'Novotec Integrado - Habilitação Profissional em Logística'
  ],
  totalAlunos: 744,
  totalTurmas: 22,
  totalDocentes: 46,
  anoLetivo: 2026,
  bimestreReferencia: '3º Bimestre'
};

// 22 turmas reais extraídas dos relatórios da SED e Prova Paulista
export const CLOVIS_DE_LUCCA_TURMAS: TurmaPerformance[] = [
  {
    turma: '1ª SERIE A INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 26,
    frequenciaMedia: 91.4, // Mais alta presença da escola
    tarefaSpAdesao: 64.2,
    redacaoEntregas: 71.0,
    provaPaulistaAcertos: 50.2, // PP3
    plataformasAdesaoGeral: 68.5,
    statusGeral: 'excelente'
  },
  {
    turma: '1ª SERIE B INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 23,
    frequenciaMedia: 86.9,
    tarefaSpAdesao: 58.4,
    redacaoEntregas: 62.0,
    provaPaulistaAcertos: 47.2,
    plataformasAdesaoGeral: 61.2,
    statusGeral: 'atencao'
  },
  {
    turma: '1ª SERIE C INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 32,
    frequenciaMedia: 87.1,
    tarefaSpAdesao: 63.5,
    redacaoEntregas: 69.5,
    provaPaulistaAcertos: 53.7,
    plataformasAdesaoGeral: 67.0,
    statusGeral: 'excelente'
  },
  {
    turma: '4056 - LOGÍSTICA - 2ª SERIE A',
    segmento: 'Ensino Médio',
    totalAlunos: 36,
    frequenciaMedia: 89.8,
    tarefaSpAdesao: 72.8,
    redacaoEntregas: 78.4,
    provaPaulistaAcertos: 56.9,
    plataformasAdesaoGeral: 74.0,
    statusGeral: 'excelente'
  },
  {
    turma: '2ª SERIE B INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 24,
    frequenciaMedia: 82.7,
    tarefaSpAdesao: 56.0,
    redacaoEntregas: 58.0,
    provaPaulistaAcertos: 55.5,
    plataformasAdesaoGeral: 62.1,
    statusGeral: 'atencao'
  },
  {
    turma: '3ª SERIE A INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 19,
    frequenciaMedia: 88.5,
    tarefaSpAdesao: 74.0,
    redacaoEntregas: 82.0,
    provaPaulistaAcertos: 67.2, // Destaque na PP3
    plataformasAdesaoGeral: 76.5,
    statusGeral: 'excelente'
  },
  {
    turma: '3ª SERIE B INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 25,
    frequenciaMedia: 84.2,
    tarefaSpAdesao: 68.0,
    redacaoEntregas: 76.0,
    provaPaulistaAcertos: 66.9,
    plataformasAdesaoGeral: 73.0,
    statusGeral: 'excelente'
  },
  {
    turma: '3ª SERIE C INTEGRAL 7H',
    segmento: 'Ensino Médio',
    totalAlunos: 20,
    frequenciaMedia: 83.5,
    tarefaSpAdesao: 61.5,
    redacaoEntregas: 65.0,
    provaPaulistaAcertos: 64.3,
    plataformasAdesaoGeral: 68.2,
    statusGeral: 'excelente'
  },
  {
    turma: '6° ANO A INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 36,
    frequenciaMedia: 88.2,
    tarefaSpAdesao: 62.0,
    redacaoEntregas: 66.0,
    provaPaulistaAcertos: 50.1,
    plataformasAdesaoGeral: 65.4,
    statusGeral: 'excelente'
  },
  {
    turma: '6° ANO B INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 37,
    frequenciaMedia: 89.4,
    tarefaSpAdesao: 66.0,
    redacaoEntregas: 70.0,
    provaPaulistaAcertos: 54.4,
    plataformasAdesaoGeral: 69.8,
    statusGeral: 'excelente'
  },
  {
    turma: '6° ANO C INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 87.7,
    tarefaSpAdesao: 64.0,
    redacaoEntregas: 68.0,
    provaPaulistaAcertos: 54.0,
    plataformasAdesaoGeral: 67.5,
    statusGeral: 'excelente'
  },
  {
    turma: '6° ANO D INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 36,
    frequenciaMedia: 89.2,
    tarefaSpAdesao: 65.0,
    redacaoEntregas: 67.5,
    provaPaulistaAcertos: 52.5,
    plataformasAdesaoGeral: 68.0,
    statusGeral: 'excelente'
  },
  {
    turma: '7° ANO A INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 85.9,
    tarefaSpAdesao: 59.5,
    redacaoEntregas: 64.0,
    provaPaulistaAcertos: 56.7,
    plataformasAdesaoGeral: 65.2,
    statusGeral: 'atencao'
  },
  {
    turma: '7° ANO B INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 88.1,
    tarefaSpAdesao: 62.0,
    redacaoEntregas: 68.0,
    provaPaulistaAcertos: 53.0,
    plataformasAdesaoGeral: 66.5,
    statusGeral: 'excelente'
  },
  {
    turma: '7° ANO C INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 36,
    frequenciaMedia: 84.4,
    tarefaSpAdesao: 58.0,
    redacaoEntregas: 63.0,
    provaPaulistaAcertos: 52.4,
    plataformasAdesaoGeral: 63.8,
    statusGeral: 'atencao'
  },
  {
    turma: '7° ANO D INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 82.2,
    tarefaSpAdesao: 57.0,
    redacaoEntregas: 61.0,
    provaPaulistaAcertos: 55.1,
    plataformasAdesaoGeral: 62.5,
    statusGeral: 'atencao'
  },
  {
    turma: '8° ANO A INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 36,
    frequenciaMedia: 86.1,
    tarefaSpAdesao: 63.0,
    redacaoEntregas: 71.0,
    provaPaulistaAcertos: 57.5,
    plataformasAdesaoGeral: 68.0,
    statusGeral: 'excelente'
  },
  {
    turma: '8° ANO B INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 80.5, // Ponto de maior atenção da escola
    tarefaSpAdesao: 51.0,
    redacaoEntregas: 54.0,
    provaPaulistaAcertos: 48.3,
    plataformasAdesaoGeral: 57.2,
    statusGeral: 'critico'
  },
  {
    turma: '8° ANO C INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 38,
    frequenciaMedia: 83.5,
    tarefaSpAdesao: 59.0,
    redacaoEntregas: 65.0,
    provaPaulistaAcertos: 54.3,
    plataformasAdesaoGeral: 64.0,
    statusGeral: 'atencao'
  },
  {
    turma: '9° ANO A INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 84.8,
    tarefaSpAdesao: 60.5,
    redacaoEntregas: 68.0,
    provaPaulistaAcertos: 54.2,
    plataformasAdesaoGeral: 66.0,
    statusGeral: 'atencao'
  },
  {
    turma: '9° ANO B INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 83.5,
    tarefaSpAdesao: 58.0,
    redacaoEntregas: 64.0,
    provaPaulistaAcertos: 52.4,
    plataformasAdesaoGeral: 63.5,
    statusGeral: 'atencao'
  },
  {
    turma: '9° ANO C INTEGRAL 7H',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 86.2,
    tarefaSpAdesao: 61.0,
    redacaoEntregas: 69.0,
    provaPaulistaAcertos: 53.0,
    plataformasAdesaoGeral: 66.8,
    statusGeral: 'excelente'
  }
];

export function getClovisDeLuccaRealRecords(): Record<string, PlatformDataRecord> {
  return {
    super_bi: {
      id: 'rec_super_bi_real',
      platformId: 'super_bi',
      uploadedAt: '01/11/2026',
      fileName: '10_semanas_somadas__de_2607_a_0310_be4128a1.pdf',
      fileSize: '342 KB',
      rowCount: 1,
      currentValue: 7.5, // Nota Final Global do Super BI
      seducTarget: 8.5,
      status: 'atencao',
      summaryText: 'SUPER BI Oficial: Nota Final Global 7.5 pts (Farol SARESP 2). Aluno Presente: 87.1%, Professor Presente: 97.5%, Tarefa SP: 9.3, Apoio Presencial: 2.880, Qualidade: 6.9.',
      criticalAlerts: [
        'Aluno Presente em 87.1% (meta 90% exige busca ativa)',
        'Qualidade Educacional em 6.9'
      ],
      keyInsights: [
        'Professor Presente exemplar em 97.5% de assiduidade',
        'Nota de Tarefa SP no Super BI atingiu 9.3 pontos',
        'Adesão Dummy em 100.0%'
      ]
    },
    prova_paulista_1b: {
      id: 'rec_pp1_real',
      platformId: 'prova_paulista_1b',
      uploadedAt: '01/11/2026',
      fileName: 'pp1_af32c689.pdf',
      fileSize: '412 KB',
      rowCount: 22,
      currentValue: 53.2,
      seducTarget: 65.0,
      status: 'atencao',
      summaryText: 'Prova Paulista 1º Bimestre: 744 estudantes avaliados, 96.0% de participação e 53.2% de média geral de acertos.',
      keyInsights: [
        'Língua Portuguesa atingiu 61.7% de acertos',
        'Inglês alcançou 60.8% e Educação Financeira 63.2%',
        'Matemática iniciou o ano em 40.5% de acertos (ponto de defasagem)'
      ],
      criticalAlerts: [
        'Matemática em 40.5% exigiu criação de salas ambiente'
      ]
    },
    prova_paulista_2b: {
      id: 'rec_pp2_real',
      platformId: 'prova_paulista_2b',
      uploadedAt: '01/11/2026',
      fileName: 'pp2_87d7db41.pdf',
      fileSize: '398 KB',
      rowCount: 22,
      currentValue: 48.0,
      seducTarget: 68.0,
      status: 'critico',
      summaryText: 'Prova Paulista 2º Bimestre: 712 estudantes avaliados, 98.1% de participação e 48.0% de média geral de acertos.',
      keyInsights: [
        'Participação cresceu de 96.0% para 98.1% da escola',
        'Sociologia atingiu 61.0% de acertos',
        'Língua Portuguesa manteve 57.8%'
      ],
      criticalAlerts: [
        'Queda sazonal de rendimento para 48.0% geral',
        'Matemática registrou 37.8% no 2º Bimestre'
      ]
    },
    prova_paulista_3b: {
      id: 'rec_pp3_real',
      platformId: 'prova_paulista_3b',
      uploadedAt: '01/11/2026',
      fileName: 'pp3_e9f36454.pdf',
      fileSize: '425 KB',
      rowCount: 22,
      currentValue: 54.6,
      seducTarget: 70.0,
      status: 'atencao',
      summaryText: 'Prova Paulista 3º Bimestre: Salto expressivo para 54.6% de acertos (+6.6 p.p. vs 2B) com 97.4% de participação!',
      keyInsights: [
        'Recuperação forte: saltou de 48.0% para 54.6%',
        'Matemática subiu de 37.8% para 49.8% (+12.0 p.p. de ganho!)',
        'Língua Portuguesa atingiu 65.0% de acertos',
        '3ª Série A alcançou 67.2% e 3ª Série B 66.9%'
      ],
      criticalAlerts: [
        '8º Ano B requer suporte continuado (48.3% de acertos)'
      ]
    },
    tarefa_sp: {
      id: 'rec_tarefa_real',
      platformId: 'tarefa_sp',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 60.69,
      seducTarget: 80.0,
      status: 'atencao',
      summaryText: 'Tarefa SP no Escola Total: 60.69% de realização semanal. Nota no Super BI consolidada em 8.4 pontos.',
      keyInsights: [
        'Nota de Tarefa SP no Super BI alcançou 8.4 / 10',
        'Engajamento sustentado ao longo das 10 semanas analisadas'
      ],
      criticalAlerts: [
        'Meta oficial de 80% requer mobilização dos líderes de turma'
      ]
    },
    redacao_paulista: {
      id: 'rec_redacao_real',
      platformId: 'redacao_paulista',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 0.69,
      seducTarget: 0.80,
      status: 'atencao',
      summaryText: 'Redação Paulista: Média de 0.69 redação por aluno no período (meta SEDUC: 0.80).',
      keyInsights: [
        'Adesão sólida com validação docente ativa',
        'Forte alinhamento com os 65.0% de acertos em Língua Portuguesa na PP3'
      ],
      criticalAlerts: [
        'Faltam apenas 0.11 redação por aluno para atingir o farol verde'
      ]
    },
    leia_sp: {
      id: 'rec_leia_real',
      platformId: 'leia_sp',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 655.88, // Minutos totais registrados
      seducTarget: 25.0,
      status: 'excelente',
      summaryText: 'Leia SP: 655.88 minutos de leitura efetiva acumulados na plataforma.',
      keyInsights: [
        'Farol Verde plenamente aceso no Escola Total',
        'Leitura digital em ritmo forte nos anos finais'
      ]
    },
    speak_ingles: {
      id: 'rec_speak_real',
      platformId: 'speak_ingles',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 0.438,
      seducTarget: 0.375,
      status: 'excelente',
      summaryText: 'SPeak (EF Corporate): Índice de 0.438 lição por aluno/semana, SUPERANDO a meta oficial de 0.375!',
      keyInsights: [
        'Farol Verde atingido com folga (+16.8% acima da meta)',
        'Inglês alcançou 60.8% de proficiência na Prova Paulista'
      ]
    },
    alura: {
      id: 'rec_alura_real',
      platformId: 'alura',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 4.85,
      seducTarget: 6.0,
      status: 'atencao',
      summaryText: 'Start by Alura: Média de 4.85 nas avaliações de Tecnologia e Inovação (meta: 6.0 pts).',
      criticalAlerts: [
        'Alunos necessitam de apoio na resolução dos desafios de lógica de programação'
      ]
    },
    matific_finais: {
      id: 'rec_matific_real',
      platformId: 'matific_finais',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 1.659,
      seducTarget: 4.0,
      status: 'atencao',
      summaryText: 'Matific Anos Finais: 1.659 atividades por aluno por quinzena (meta: 4.0).',
      criticalAlerts: [
        'Potencializar uso nas 2 novas salas ambiente de Matemática'
      ]
    },
    khan_academy: {
      id: 'rec_khan_real',
      platformId: 'khan_academy',
      uploadedAt: '01/11/2026',
      fileName: 'plataformas_c6788092.pdf',
      fileSize: '210 KB',
      rowCount: 1,
      currentValue: 6.35,
      seducTarget: 2.0,
      status: 'excelente',
      summaryText: 'Khan Academy (Ensino Médio): 6.35 atividades/mês por aluno — MAIS QUE O TRIPLO da meta oficial de 2.0!',
      keyInsights: [
        'Desempenho histórico: 6.35 atividades/mês (Farol Verde de excelência)',
        'Impacto direto no salto de Matemática do Ensino Médio na PP3'
      ]
    },
    aluno_presente: {
      id: 'rec_freq_real',
      platformId: 'aluno_presente',
      uploadedAt: '01/11/2026',
      fileName: 'aluno_presente_55073bb9.pdf',
      fileSize: '315 KB',
      rowCount: 22,
      currentValue: 87.1,
      seducTarget: 90.0,
      status: 'atencao',
      summaryText: 'Aluno Presente: Frequência média da unidade escolar em 87.1%. Varia de 91.4% (1ª Série A) a 80.5% (8º Ano B).',
      criticalAlerts: [
        '8º Ano B (80.5%), 7º Ano D (82.2%) e 2ª Série B (82.7%) exigem intervenção da Busca Ativa'
      ],
      keyInsights: [
        '1ª Série A atingiu 91.4% de presença exemplar',
        '2ª Série A (Novotec Logística) com 89.8% de frequência'
      ]
    },
    matriculas_2026: {
      id: 'rec_matr_real',
      platformId: 'matriculas_2026',
      uploadedAt: '01/11/2026',
      fileName: 'matriculas_36e448f1.pdf',
      fileSize: '280 KB',
      rowCount: 22,
      currentValue: 98.5,
      seducTarget: 98.0,
      status: 'excelente',
      summaryText: 'Matrículas SED: 744 estudantes ativos enturmados nas 22 turmas do PEI 7H e Novotec.',
      keyInsights: [
        'Anos Finais com 100% de ocupação e zero ociosidade',
        'Vagas disponíveis concentradas nas 3ªs séries do Ensino Médio'
      ]
    },
    saresp_diagnostico: {
      id: 'rec_saresp_real',
      platformId: 'saresp_diagnostico',
      uploadedAt: '01/11/2026',
      fileName: 'saresp_diag_8b71762b.pdf',
      fileSize: '310 KB',
      rowCount: 22,
      currentValue: 4.9, // Nota média geral
      seducTarget: 5.8,
      status: 'atencao',
      summaryText: 'SARESP Diagnóstico Inicial: Média geral da escola em 4.9 (LPT: 5.6, MAT: 4.5, ING: 4.6, CIE: 5.2, HIS: 4.7).',
      keyInsights: [
        'Língua Portuguesa com média de 5.6',
        'Ciências alcançou 5.2 de média'
      ]
    },
    recomposicao_diagnostico: {
      id: 'rec_diag_entrada_real',
      platformId: 'recomposicao_diagnostico',
      uploadedAt: '01/11/2026',
      fileName: 'diagnostica_054805bb.pdf',
      fileSize: '335 KB',
      rowCount: 22,
      currentValue: 58.4,
      seducTarget: 75.0,
      status: 'atencao',
      summaryText: 'Avaliação Diagnóstica de Entrada: Variações de proficiência e distribuição entre Abaixo do Básico, Básico e Proficiente.',
      keyInsights: [
        'Redução significativa do Abaixo do Básico no 1º e 2º trimestres',
        '6º Ano A reduziu Abaixo do Básico em 8.6 p.p.'
      ]
    },
    manutencao_predial: {
      id: 'rec_manut_real',
      platformId: 'manutencao_predial',
      uploadedAt: '01/11/2026',
      fileName: 'manuten__o_predial_a2d059df.pdf',
      fileSize: '390 KB',
      rowCount: 19,
      currentValue: 88.0,
      seducTarget: 90.0,
      status: 'excelente',
      summaryText: 'Manutenção Predial FDE: Nova gestão escolar ativa! 2 novas salas ambiente de Matemática e Português, 3 monitores informativos no pátio e horta pedagógica.',
      keyInsights: [
        'Diretor implantando 2 novas salas ambiente de matemática e português via parceria',
        'Instalação de 3 monitores no pátio com cardápio, horários e informes da escola',
        'Horta pedagógica em pleno funcionamento'
      ],
      criticalAlerts: [
        'Vazamento no telhado requer intervenção urgente da FDE (ponto crítico na sala da direção e salas de aula)'
      ]
    },
    professor_tutor_finais: {
      id: 'rec_tutor_real',
      platformId: 'professor_tutor_finais',
      uploadedAt: '01/11/2026',
      fileName: 'professor_tutor_horizonte.pdf',
      fileSize: '295 KB',
      rowCount: 8,
      currentValue: 73.1,
      seducTarget: 75.0,
      status: 'atencao',
      summaryText: 'Professor Tutor / Horizonte (Tutor: Francisca Janaina Duarte Silva): 118 alunos enturmados, 1.130 tarefas finalizadas com 73.1% de acertos.',
      keyInsights: [
        'Material Aquisição atingiu 89.9% de participação',
        'Material Consolidação em 9.6% e Expansão em 0.5%',
        '100% de alunos com tarefas realizadas nas turmas de LP e MAT do projeto horizonte'
      ]
    }
  };
}

export const CLOVIS_DE_LUCCA_MMR_ACTIONS: ActionPlanItem[] = [
  {
    id: 'mmr_clovis_01',
    origem: 'Manutenção Predial / Infraestrutura',
    problema: 'Vazamentos no telhado em múltiplos pontos da unidade escolar (incluindo sala da direção e salas de aula).',
    causaRaiz: 'Desgaste da cobertura estrutural pré-existente e calhas antigas.',
    acaoProposta: 'Abertura e reiteração de Ordem de Serviço emergencial junto à FDE e aplicação de recursos do PDDE Paulista para reparo emergencial de calhas.',
    responsavel: 'Diretor Rodrigo Guergolet & GOE',
    prazo: '15/11/2026',
    indicadorMeta: '100% dos pontos de infiltração estancados',
    status: 'em_andamento',
    prioridade: 'alta'
  },
  {
    id: 'mmr_clovis_02',
    origem: 'Prova Paulista & Recomposição',
    problema: 'Matemática registrou 37.8% de acertos na PP2, necessitando consolidar o salto de 49.8% obtido na PP3.',
    causaRaiz: 'Dificuldade de abstração e lacunas em frações, álgebra e geometria plana.',
    acaoProposta: 'Ativação das 2 novas salas ambiente de Matemática e uso intensivo da Khan Academy (6.35 ativ/mês) e Matific.',
    responsavel: 'CGPG & Professores de Matemática',
    prazo: '30/11/2026',
    indicadorMeta: 'Manter média de acertos em Matemática acima de 55% na PP4 e SARESP',
    status: 'em_andamento',
    prioridade: 'alta'
  },
  {
    id: 'mmr_clovis_03',
    origem: 'Aluno Presente & Busca Ativa',
    problema: '8º Ano B com frequência média de 80.5% (mais baixa da unidade escolar) e 7º Ano D com 82.2%.',
    causaRaiz: 'Casos isolados de infrequência crônica e desengajamento no período da tarde.',
    acaoProposta: 'Busca ativa direta com as famílias pelo Vice-Diretor, acionamento do Conselho Tutelar se necessário e acolhimento com tutoria individual.',
    responsavel: 'Vice-Direção & Equipe de Tutoria',
    prazo: '20/11/2026',
    indicadorMeta: 'Elevar a frequência do 8ºB para acima de 86%',
    status: 'em_andamento',
    prioridade: 'alta'
  },
  {
    id: 'mmr_clovis_04',
    origem: 'Plataformas Escola Total / Tarefa SP',
    problema: 'Taxa de entrega semanal da Tarefa SP em 60.69% (abaixo da meta de 80% do Escola Total).',
    causaRaiz: 'Estudantes deixam acúmulo de lições para o fim de semana.',
    acaoProposta: 'Utilizar os 3 monitores do pátio para divulgar o ranking semanal das turmas e reservar 30 min de Estudo Orientado para resolução.',
    responsavel: 'Líderes de Turma & CGPAC',
    prazo: '10/11/2026',
    indicadorMeta: 'Atingir 75% no 4º bimestre rumo ao farol verde',
    status: 'em_andamento',
    prioridade: 'media'
  }
];
