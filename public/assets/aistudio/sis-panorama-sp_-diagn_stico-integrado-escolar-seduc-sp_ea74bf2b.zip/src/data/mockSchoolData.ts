import { DiagnosticPanorama, PlatformDataRecord, SchoolProfile, TurmaPerformance, ActionPlanItem } from '../types';
import { PLATFORMS_CATALOG } from './platformsCatalog';

export const INITIAL_SCHOOL_PROFILE: SchoolProfile = {
  nome: 'EE Professora Esther Carpinelli Pagano',
  codCIE: '034.819',
  diretoriaEnsino: 'Diretoria de Ensino Região Leste 3',
  municipio: 'São Paulo - SP',
  modelo: 'PEI_9H',
  segmentos: ['Anos Finais do Ensino Fundamental (6º ao 9º)', 'Ensino Médio Integral (1ª à 3ª Série)'],
  totalAlunos: 742,
  totalTurmas: 22,
  totalDocentes: 48,
  anoLetivo: 2026,
  bimestreReferencia: '2º Bimestre'
};

export const INITIAL_TURMAS_PERFORMANCE: TurmaPerformance[] = [
  {
    turma: '6º Ano A',
    segmento: 'Anos Finais',
    totalAlunos: 34,
    frequenciaMedia: 92.4,
    tarefaSpAdesao: 88.2,
    redacaoEntregas: 84.0,
    provaPaulistaAcertos: 71.5,
    plataformasAdesaoGeral: 85.0,
    statusGeral: 'excelente'
  },
  {
    turma: '6º Ano B',
    segmento: 'Anos Finais',
    totalAlunos: 33,
    frequenciaMedia: 89.1,
    tarefaSpAdesao: 81.5,
    redacaoEntregas: 79.2,
    provaPaulistaAcertos: 66.8,
    plataformasAdesaoGeral: 78.4,
    statusGeral: 'excelente'
  },
  {
    turma: '7º Ano A',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 88.0,
    tarefaSpAdesao: 74.3,
    redacaoEntregas: 71.0,
    provaPaulistaAcertos: 62.4,
    plataformasAdesaoGeral: 72.1,
    statusGeral: 'atencao'
  },
  {
    turma: '7º Ano B',
    segmento: 'Anos Finais',
    totalAlunos: 34,
    frequenciaMedia: 85.6,
    tarefaSpAdesao: 69.4,
    redacaoEntregas: 65.5,
    provaPaulistaAcertos: 58.0,
    plataformasAdesaoGeral: 66.2,
    statusGeral: 'atencao'
  },
  {
    turma: '8º Ano A',
    segmento: 'Anos Finais',
    totalAlunos: 36,
    frequenciaMedia: 91.2,
    tarefaSpAdesao: 85.0,
    redacaoEntregas: 81.8,
    provaPaulistaAcertos: 69.2,
    plataformasAdesaoGeral: 82.5,
    statusGeral: 'excelente'
  },
  {
    turma: '8º Ano B',
    segmento: 'Anos Finais',
    totalAlunos: 35,
    frequenciaMedia: 82.3,
    tarefaSpAdesao: 62.1,
    redacaoEntregas: 58.0,
    provaPaulistaAcertos: 52.4,
    plataformasAdesaoGeral: 59.5,
    statusGeral: 'critico'
  },
  {
    turma: '9º Ano A',
    segmento: 'Anos Finais',
    totalAlunos: 33,
    frequenciaMedia: 90.5,
    tarefaSpAdesao: 86.4,
    redacaoEntregas: 88.1,
    provaPaulistaAcertos: 73.1,
    plataformasAdesaoGeral: 86.2,
    statusGeral: 'excelente'
  },
  {
    turma: '9º Ano B',
    segmento: 'Anos Finais',
    totalAlunos: 34,
    frequenciaMedia: 86.7,
    tarefaSpAdesao: 76.5,
    redacaoEntregas: 74.0,
    provaPaulistaAcertos: 63.8,
    plataformasAdesaoGeral: 75.0,
    statusGeral: 'atencao'
  },
  {
    turma: '1ª Série A EM',
    segmento: 'Ensino Médio',
    totalAlunos: 35,
    frequenciaMedia: 91.0,
    tarefaSpAdesao: 83.2,
    redacaoEntregas: 82.5,
    provaPaulistaAcertos: 68.0,
    plataformasAdesaoGeral: 81.0,
    statusGeral: 'excelente'
  },
  {
    turma: '1ª Série B EM',
    segmento: 'Ensino Médio',
    totalAlunos: 36,
    frequenciaMedia: 81.4,
    tarefaSpAdesao: 59.8,
    redacaoEntregas: 56.4,
    provaPaulistaAcertos: 51.2,
    plataformasAdesaoGeral: 57.0,
    statusGeral: 'critico'
  },
  {
    turma: '2ª Série A EM',
    segmento: 'Ensino Médio',
    totalAlunos: 34,
    frequenciaMedia: 89.8,
    tarefaSpAdesao: 84.1,
    redacaoEntregas: 86.0,
    provaPaulistaAcertos: 70.4,
    plataformasAdesaoGeral: 83.4,
    statusGeral: 'excelente'
  },
  {
    turma: '3ª Série A EM',
    segmento: 'Ensino Médio',
    totalAlunos: 32,
    frequenciaMedia: 93.5,
    tarefaSpAdesao: 91.2,
    redacaoEntregas: 93.0,
    provaPaulistaAcertos: 76.8,
    plataformasAdesaoGeral: 89.5,
    statusGeral: 'excelente'
  }
];

// Helper to generate initial record for all 41 platforms
export function generateInitialPlatformRecords(): Record<string, PlatformDataRecord> {
  const records: Record<string, PlatformDataRecord> = {};

  const valuesMap: Record<string, { val: number; text: string; alerts?: string[]; insights?: string[] }> = {
    super_bi: {
      val: 84.2,
      text: 'Índice de Atingimento Geral da unidade em 84.2%, posicionando a escola entre as top 15% da Diretoria de Ensino Leste 3.',
      insights: ['Fluxo regular com 98% de retenção ativa', 'Indicadores de Tutoria e Guias de Aprendizagem com nota máxima']
    },
    saresp_diagnostico: {
      val: 72.8,
      text: '72.8% dos alunos avaliados atingiram os padrões Adequado e Avançado na avaliação diagnóstica de entrada.',
      insights: ['Língua Portuguesa com 76.4% no padrão adequado', 'Matemática requer atenção em Geometria Espacial (58.2%)']
    },
    recomposicao_diagnostico: {
      val: 78.4,
      text: '78.4% das habilidades defasadas do ciclo anterior foram recompostas após as oficinas de nivelamento de início de ano.',
      alerts: ['Habilidade EF07MA05 (Operações com Números Racionais) ainda em alerta no 8ºB'],
      insights: ['Evolução positiva de +14 pontos percentuais em leitura e interpretação']
    },
    plataformas_2026: {
      val: 82.6,
      text: 'Cumprimento semanal agregado das plataformas digitais em 82.6% (meta SEDUC superada em 2.6 p.p.).',
      insights: ['Tarefa SP e Redação lideram o engajamento', 'Speak e Alura demandam suporte técnico no laboratório móvel']
    },
    matriculas_2026: {
      val: 99.1,
      text: '742 estudantes com matrícula 100% regularizada no SED. Zero abandono escolar registrado até o momento.',
      insights: ['Capacidade de enturmação em 96.4% nas 22 turmas', '3 transferências recebidas acolhidas pela tutoria']
    },
    aluno_presente: {
      val: 88.7,
      text: 'Frequência média da escola em 88.7% (próxima à meta de 90%). 14 alunos em alerta de infrequência no radar da busca ativa.',
      alerts: ['Turmas 8º Ano B (82.3%) e 1ª Série B EM (81.4%) exigem intervenção imediata da Busca Ativa'],
      insights: ['3ª Série A com 93.5% de assiduidade exemplar']
    },
    prova_paulista_1b: {
      val: 67.4,
      text: 'Média de 67.4% de acertos na Prova Paulista 1º Bimestre com 95.8% de participação dos estudantes.',
      insights: ['Ciências Humanas e Linguagens com média de 71.2%', 'Matemática e Ciências da Natureza com média de 63.6%']
    },
    prova_paulista_2b: {
      val: 70.8,
      text: 'Média de 70.8% de acertos no 2º Bimestre, representando salto de +3.4 p.p. em relação à 1ª edição.',
      insights: ['Adesão de 96.4% na aplicação digital', '9ºA e 3ªA atingiram mais de 73% de acertos']
    },
    prova_paulista_3b: {
      val: 72.1,
      text: 'Projeção e dados parciais indicam 72.1% de acertos no 3º Bimestre, consolidando a meta anual da escola.',
      insights: ['Forte correlação com simulados do Provão Paulista']
    },
    tarefa_sp: {
      val: 83.5,
      text: '83.5% de resolução semanal de tarefas no CMSP, superando a meta oficial de 80% da SEDUC-SP.',
      alerts: ['1ª Série B EM com 59.8% (abaixo do limiar de 60%)'],
      insights: ['Docentes de Língua Portuguesa e História com 96% de devolução no prazo']
    },
    elefante_letrado: {
      val: 3.4,
      text: 'Média de 3.4 livros lidos por estudante por semana no acervo digital infantil.',
      insights: ['Excelente índice de letramento e interpretação leitora']
    },
    elefante_letrado_mun: {
      val: 78.0,
      text: '78.0% de adesão nos módulos de transição articulados com a rede municipal parceira.',
      insights: ['Compartilhamento de dados no diagnóstico do 6º ano']
    },
    redacao_paulista: {
      val: 84.7,
      text: '84.7% de redações enviadas e corrigidas com devolutiva pedagógica registrada.',
      alerts: ['Turma 8ºB com 58.0% de envio (necessita agendamento prioritário na sala de informática)'],
      insights: ['Nota média nas redações: 745/1000 pontos', 'Uso da IA para reescrita textual aumentou em 40% a qualidade']
    },
    leia_sp: {
      val: 2.3,
      text: 'Média de 2.3 obras literárias concluídas por estudante no bimestre (meta SEDUC: 2.0).',
      insights: ['Livros mais lidos: "O Quinze", "Capitães da Areia" e contos de Machado de Assis']
    },
    speak_ingles: {
      val: 73.2,
      text: '73.2% dos estudantes ativos na prática de conversação oral e pronúncia em inglês.',
      insights: ['32 estudantes atingiram o nível B1 no referencial CEFR']
    },
    alura: {
      val: 76.5,
      text: '76.5% de módulos concluídos nas trilhas de Pensamento Computacional, HTML/CSS e Python.',
      insights: ['84 estudantes finalizaram projetos de páginas web autorais']
    },
    matific_iniciais: {
      val: 5.6,
      text: '5.6 episódios matemáticos concluídos por estudante/semana na gamificação.',
      insights: ['Alta absorção lúdica dos conceitos de multiplicação e medidas']
    },
    matific_finais: {
      val: 77.8,
      text: '77.8% de aderência nos desafios matemáticos do 6º ao 9º ano.',
      insights: ['Avanço considerável em Geometria Plana no 7º e 8º anos']
    },
    khan_academy: {
      val: 68.4,
      text: 'Média de 68.4 minutos de prática semanal de matemática por estudante (meta: 60 min).',
      insights: ['Trilha adaptativa reduziu em 35% os erros em equações do 1º grau']
    },
    prepara_sp: {
      val: 86.2,
      text: '86.2% dos estudantes do Ensino Médio resolvendo os simulados preparatórios do Provão Paulista.',
      insights: ['3ª Série com 94% de adesão ao simulado FUVEST/ENEM']
    },
    robotica_sptec: {
      val: 2.2,
      text: '2.2 projetos práticos com kits de robótica e arduíno concluídos por turma neste semestre.',
      insights: ['Projeto de sensor de irrigação escolar selecionado para Mostra de Ciências Regional']
    },
    projeto_empreendedorismo: {
      val: 88.0,
      text: '88.0% dos grupos de Ensino Médio entregaram o plano de negócios e pitch gravado.',
      insights: ['12 planos de negócios desenvolvidos com viabilidade comunitária']
    },
    manutencao_predial: {
      val: 94.0,
      text: '94% das Ordens de Serviço e chamados de manutenção predial resolvidos via PDDE Paulista e FDE.',
      insights: ['Laboratório de Ciências revitalizado e 100% da rede elétrica do prédio estabilizada']
    },
    open_english: {
      val: 82.5,
      text: '82.5% de frequência em aulas ao vivo com falantes nativos para a turma de bolsistas.',
      insights: ['18 estudantes da 2ª e 3ª série com nota A nos simulados de fala']
    },
    professor_tutor_iniciais: {
      val: 84.0,
      text: '84.0% dos estudantes atendidos pela tutoria alcançaram o nível alfabético consolidado.',
      insights: ['Acompanhamento de 42 estudantes em reforço intensivo']
    },
    professor_tutor_finais: {
      val: 87.5,
      text: '87.5% dos estudantes dos anos finais contam com Plano de Tutoria e Projeto de Vida ativo.',
      insights: ['38 professores tutores realizando acolhimento individual mensal']
    },
    aulas_olimpicas: {
      val: 78.4,
      text: '78.4% de presença nas aulas preparatórias para a 2ª Fase da OBMEP e OBA.',
      insights: ['14 estudantes classificados para a Fase Nacional da OBMEP']
    },
    edu_profissional: {
      val: 91.2,
      text: '91.2% de retenção e assiduidade nas turmas do Novotec Integrado (Desenvolvimento de Sistemas).',
      insights: ['100% dos concluintes com projetos de estágio ou protótipos aprovados']
    },
    expansao_aula: {
      val: 86.0,
      text: '86.0% de presença nas turmas de aprofundamento e expansão de carga horária no contraturno.',
      insights: ['Foco em oficinas de escrita argumentativa e cálculo avançado']
    },
    meu_diploma_sp: {
      val: 100.0,
      text: '100% dos prontuários de concluintes da 3ª Série regularizados no SED, sem pendências cartorárias.',
      insights: ['Garantia de diplomação em tempo hábil para matrícula universitária']
    },
    apoio_presencial: {
      val: 92.0,
      text: '92% das orientações técnicas do Supervisor e PEC implementadas no Plano de Gestão.',
      insights: ['Feedback positivo sobre a gestão de conselho de classe participativo']
    },
    planejamento_de_aula: {
      val: 97.5,
      text: '97.5% dos planos de aula lançados no SED dentro do cronograma quinzenal.',
      insights: ['48 docentes com 100% de preenchimento e alinhamento às habilidades']
    },
    mapa_classe: {
      val: 100.0,
      text: '100% das 22 turmas com Mapa de Classe concluído, categorizando perfis e alunos PNEE.',
      insights: ['Mapeamento de 8 estudantes com PEI (Plano de Atendimento Educacional Especializado)']
    },
    mapa_classe_mun: {
      val: 88.5,
      text: '88.5% dos dados de transição dos estudantes oriundos das escolas municipais integrados.',
      insights: ['Facilitou o acolhimento e nivelamento no 6º ano']
    },
    escolas_excelencia_pei: {
      val: 92.4,
      text: 'Índice de Efetividade do Modelo PEI em 92.4% (nível de maturidade: Excelência PEI).',
      insights: ['Clubes Juvenis autônomos e Grêmio Estudantil atuante na governança escolar']
    },
    escolas_excelencia_pei_2: {
      val: 89.8,
      text: '89.8% de cumprimento das metas do ciclo de avaliação 360° e guias de aprendizagem divulgados.',
      insights: ['Conselho de escola participativo com 85% de presença dos responsáveis']
    },
    qualidade_educacional: {
      val: 5.92,
      text: 'IDESP projetado da escola em 5.92 pontos (meta SEDUC: 5.80), superando a meta em +0.12 pts.',
      insights: ['Crescimento constante nos últimos 3 anos letivos']
    },
    aluno_monitor_beem: {
      val: 86.8,
      text: '86.8% das horas de monitoria cumpridas pelos bolsistas do BEEM com resgate de 18 colegas infrequentes.',
      insights: ['Impacto direto na diminuição do abandono no Ensino Médio']
    },
    prova_paulista_boletins: {
      val: 96.0,
      text: '96.0% dos boletins individuais gerados, entregues às famílias e debatidos no Conselho de Classe.',
      insights: ['Uso da ficha de autoavaliação por estudante nas reuniões de tutoria']
    },
    simulado_sp: {
      val: 88.4,
      text: '88.4% de presença no Simulado SP com média geral de acertos de 69.2%.',
      insights: ['Redução do tempo médio de resolução e menor taxa de abstenção']
    },
    recuperacao_2026: {
      val: 81.5,
      text: '81.5% dos estudantes em recuperação contínua superaram as defasagens prioritárias no bimestre.',
      insights: ['Roteiros de estudo personalizados com apoio do Professor Tutor']
    }
  };

  PLATFORMS_CATALOG.forEach(p => {
    const defaultData = valuesMap[p.id] || {
      val: 80.0,
      text: `Dados integrados para ${p.name}. Indicador dentro do esperado para o ciclo 2026.`,
      insights: ['Sincronização realizada via relatório padrão SEDUC']
    };

    let status: 'excelente' | 'atencao' | 'critico' = 'excelente';
    if (defaultData.val < p.criticalThreshold) {
      status = 'critico';
    } else if (defaultData.val < p.seducTarget) {
      status = 'atencao';
    }

    records[p.id] = {
      id: `rec_${p.id}`,
      platformId: p.id,
      uploadedAt: '01/11/2026 10:30',
      fileName: `export_seduc_${p.code.toLowerCase()}.xlsx`,
      fileSize: '142 KB',
      rowCount: 742,
      currentValue: defaultData.val,
      seducTarget: p.seducTarget,
      status,
      summaryText: defaultData.text,
      criticalAlerts: defaultData.alerts || [],
      keyInsights: defaultData.insights || []
    };
  });

  return records;
}

export const INITIAL_ACTION_PLAN_MMR: ActionPlanItem[] = [
  {
    id: 'mmr_01',
    origem: 'Aluno Presente & Busca Ativa',
    problema: 'Turmas do 8º Ano B (82.3%) e 1ª Série B EM (81.4%) apresentam infrequência crítica e risco de evasão.',
    causaRaiz: 'Dificuldade de transporte de alunos de bairros periféricos e falta de rotina de estudos em casa.',
    acaoProposta: 'Convocar responsáveis para atendimento individual com o Vice-Diretor e acionar Aluno Monitor do BEEM para tutoria entre pares.',
    responsavel: 'Vice-Diretor & Coordenador de Organização Escolar',
    prazo: '15/11/2026',
    indicadorMeta: 'Elevar frequência de ambas as turmas para acima de 88%',
    status: 'em_andamento',
    prioridade: 'alta'
  },
  {
    id: 'mmr_02',
    origem: 'Tarefa SP & Redação Paulista',
    problema: '1ª Série B EM com taxa de entrega de Tarefa SP em 59.8% e Redação Paulista em 56.4%.',
    causaRaiz: 'Alunos sem acesso a celular/internet no contraturno e baixa ocupação dos laboratórios de informática.',
    acaoProposta: 'Criar escala fixa semanal de uso do laboratório móvel e reservar 2 aulas de Tutoria/Estudo Orientado para resolução.',
    responsavel: 'CGPG (Coord. de Gestão Pedagógica Geral) & Docentes de LP/Matemática',
    prazo: '20/11/2026',
    indicadorMeta: 'Alcançar 80% de resolução de Tarefa SP e 75% na Redação Paulista',
    status: 'em_andamento',
    prioridade: 'alta'
  },
  {
    id: 'mmr_03',
    origem: 'Prova Paulista 2ºB & Recomposição',
    problema: 'Defasagem persistente na habilidade EF07MA05 (Operações com Números Racionais) no 8º Ano B.',
    causaRaiz: 'Lacunas estruturais de anos anteriores no cálculo com frações e decimais não consolidadas.',
    acaoProposta: 'Oficinas práticas semanais com Matific Anos Finais e plantão de dúvidas no contraturno com o Professor Tutor.',
    responsavel: 'CGPAC da Área de Matemática & Professor Tutor Anos Finais',
    prazo: '30/11/2026',
    indicadorMeta: 'Superar 75% de acertos nos itens de racionais no Simulado SP',
    status: 'nao_iniciado',
    prioridade: 'alta'
  },
  {
    id: 'mmr_04',
    origem: 'Speak Inglês & Alura',
    problema: 'Uso irregular da plataforma Speak (73.2%) por instabilidade pontual em fones de ouvido no laboratório.',
    causaRaiz: 'Falta de kits de fones com microfone em 12 computadores da sala de informática.',
    acaoProposta: 'Aquisição de 25 headsets com cancelamento de ruído utilizando verba do PDDE Paulista / Manutenção Predial.',
    responsavel: 'Diretor de Escola & Gerente de Organização Escolar (GOE)',
    prazo: '10/11/2026',
    indicadorMeta: '100% dos alunos do EM com acesso pleno ao Speak e Alura',
    status: 'concluido',
    prioridade: 'media'
  },
  {
    id: 'mmr_05',
    origem: 'Escolas de Excelência PEI & Tutoria',
    problema: 'Dispersão de alguns Clubes Juvenis durante o horário de almoço no 7º ano.',
    causaRaiz: 'Falta de pauta clara dos presidentes de clube e rodízio de salas inadequado.',
    acaoProposta: 'Alinhamento quinzenal do Professor Articulador de Protagonismo com os líderes de clube juvenil.',
    responsavel: 'Professor Coordenador de Área de Linguagens & Grêmio Estudantil',
    prazo: '25/11/2026',
    indicadorMeta: '100% dos clubes com atas e projetos documentados',
    status: 'em_andamento',
    prioridade: 'baixa'
  }
];
