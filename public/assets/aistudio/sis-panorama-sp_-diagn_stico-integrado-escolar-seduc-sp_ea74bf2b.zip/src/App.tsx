import React, { useState, useMemo, useEffect } from 'react';
import { 
  DiagnosticPanorama, 
  PlatformDataRecord, 
  SchoolProfile, 
  TurmaPerformance, 
  ActionPlanItem,
  HistoricalSnapshot
} from './types';
import { PLATFORMS_CATALOG } from './data/platformsCatalog';
import { StorageService } from './services/storageService';
import { computeSchoolPanorama } from './services/diagnosticEngine';
import { Navbar } from './components/Navbar';
import { PanoramaExecutiveView } from './components/PanoramaExecutiveView';
import { PlatformsGridView } from './components/PlatformsGridView';
import { CorrelationsView } from './components/CorrelationsView';
import { ActionPlanMMRView } from './components/ActionPlanMMRView';
import { PrintReportView } from './components/PrintReportView';
import { HistoryTimelineView } from './components/HistoryTimelineView';
import { UploadModal } from './components/UploadModal';
import { PlatformDetailModal } from './components/PlatformDetailModal';
import { SchoolConfigModal } from './components/SchoolConfigModal';
import { EscolaTotalArchitectureView } from './components/EscolaTotalArchitectureView';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('panorama');

  // Real Persistent State (Zero mock data by default, stored safely in browser localStorage)
  const [schoolProfile, setSchoolProfile] = useState<SchoolProfile>(() => StorageService.loadProfile());
  const [platformRecords, setPlatformRecords] = useState<Record<string, PlatformDataRecord>>(() => StorageService.loadRecords());
  const [turmas, setTurmas] = useState<TurmaPerformance[]>(() => StorageService.loadTurmas());
  const [actionPlan, setActionPlan] = useState<ActionPlanItem[]>(() => StorageService.loadActionPlan());
  const [snapshots, setSnapshots] = useState<HistoricalSnapshot[]>(() => StorageService.loadSnapshots());

  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [uploadTargetPlatformId, setUploadTargetPlatformId] = useState<string | null>(null);
  const [detailPlatformId, setDetailPlatformId] = useState<string | null>(null);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Persist whenever state changes
  useEffect(() => {
    StorageService.saveProfile(schoolProfile);
  }, [schoolProfile]);

  useEffect(() => {
    StorageService.saveRecords(platformRecords);
  }, [platformRecords]);

  useEffect(() => {
    StorageService.saveTurmas(turmas);
  }, [turmas]);

  useEffect(() => {
    StorageService.saveActionPlan(actionPlan);
  }, [actionPlan]);

  // Recalculate 360° Diagnostic Panorama
  const panorama = useMemo(() => {
    return computeSchoolPanorama(schoolProfile, platformRecords, turmas, actionPlan);
  }, [schoolProfile, platformRecords, turmas, actionPlan]);

  const handleDataParsed = (newRecord: PlatformDataRecord, extractedTurmas?: TurmaPerformance[]) => {
    setPlatformRecords(prev => {
      const updated = {
        ...prev,
        [newRecord.platformId]: newRecord
      };
      StorageService.saveRecords(updated);
      return updated;
    });

    if (extractedTurmas && extractedTurmas.length > 0) {
      setTurmas(prev => {
        const map = new Map<string, TurmaPerformance>();
        prev.forEach(t => map.set(t.turma, t));
        extractedTurmas.forEach(t => map.set(t.turma, t));
        const merged = Array.from(map.values());
        StorageService.saveTurmas(merged);
        return merged;
      });
    }

    const plat = PLATFORMS_CATALOG.find(p => p.id === newRecord.platformId);
    showToast(`Relatório para "${plat ? plat.name : newRecord.platformId}" processado e salvo localmente com sucesso!`);
  };

  const handleRestoreSnapshot = (snap: HistoricalSnapshot) => {
    setPlatformRecords(snap.platformRecords);
    setTurmas(snap.turmas);
    setActionPlan(snap.actionPlan);
    setSchoolProfile(snap.schoolProfile);
    setCurrentTab('panorama');
    showToast(`Snapshot histórico "${snap.title}" carregado para visualização.`);
  };

  const handleFullDataImported = (data: {
    profile: SchoolProfile;
    records: Record<string, PlatformDataRecord>;
    turmas: TurmaPerformance[];
    actionPlan: ActionPlanItem[];
    snapshots: HistoricalSnapshot[];
  }) => {
    setSchoolProfile(data.profile);
    setPlatformRecords(data.records);
    setTurmas(data.turmas);
    setActionPlan(data.actionPlan);
    setSnapshots(data.snapshots);
    showToast('Backup completo importado com sucesso! Dados e linha do tempo sincronizados.');
  };

  const handleClearAllData = () => {
    if (confirm('Tem certeza de que deseja apagar todos os dados e o histórico local? Esta ação não pode ser desfeita.')) {
      StorageService.clearAll();
      setPlatformRecords({});
      setTurmas([]);
      setActionPlan([]);
      setSnapshots([]);
      setSchoolProfile(StorageService.loadProfile());
      showToast('Todos os dados foram reiniciados com sucesso.');
    }
  };

  const handleOpenUploadForPlatform = (platformId?: string) => {
    setUploadTargetPlatformId(platformId || null);
    setIsUploadModalOpen(true);
  };

  const handleOpenGeneralUpload = () => {
    setUploadTargetPlatformId(null);
    setIsUploadModalOpen(true);
  };

  const selectedPlatformConfig = detailPlatformId 
    ? PLATFORMS_CATALOG.find(p => p.id === detailPlatformId) || null
    : null;

  const loadedCount = Object.keys(platformRecords).length;
  const totalCount = PLATFORMS_CATALOG.length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-950 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 text-xs font-medium border border-slate-800 animate-in fade-in slide-in-from-bottom-2 duration-200 max-w-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onOpenUpload={handleOpenGeneralUpload}
        onOpenConfig={() => setIsConfigModalOpen(true)}
        loadedCount={loadedCount}
        totalCount={totalCount}
        snapshotsCount={snapshots.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'panorama' && (
          <PanoramaExecutiveView
            panorama={panorama}
            platformRecords={platformRecords}
            onNavigateTab={setCurrentTab}
            onSelectPlatform={setDetailPlatformId}
            onOpenUpload={handleOpenGeneralUpload}
          />
        )}

        {currentTab === 'plataformas' && (
          <PlatformsGridView
            platformRecords={platformRecords}
            onSelectPlatform={setDetailPlatformId}
            onUploadForPlatform={handleOpenUploadForPlatform}
          />
        )}

        {currentTab === 'escolatotal' && (
          <EscolaTotalArchitectureView
            platformRecords={platformRecords}
            onSelectPlatform={setDetailPlatformId}
            onOpenUpload={handleOpenUploadForPlatform}
          />
        )}

        {currentTab === 'turmas' && (
          <CorrelationsView 
            turmas={turmas} 
            onUpdateTurmas={setTurmas}
          />
        )}

        {currentTab === 'mmr' && (
          <ActionPlanMMRView
            actionPlan={actionPlan}
            onUpdatePlan={setActionPlan}
          />
        )}

        {currentTab === 'historico' && (
          <HistoryTimelineView
            currentPanorama={panorama}
            currentRecords={platformRecords}
            currentTurmas={turmas}
            currentActionPlan={actionPlan}
            currentProfile={schoolProfile}
            snapshots={snapshots}
            onSnapshotsUpdated={setSnapshots}
            onRestoreSnapshot={handleRestoreSnapshot}
            onFullDataImported={handleFullDataImported}
            onClearAllData={handleClearAllData}
          />
        )}

        {currentTab === 'dossie' && (
          <PrintReportView
            panorama={panorama}
            platformRecords={platformRecords}
            onBackToPanorama={() => setCurrentTab('panorama')}
          />
        )}
      </main>

      {/* Upload Modal */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        targetPlatformId={uploadTargetPlatformId}
        onDataParsed={handleDataParsed}
      />

      {/* Platform Detail Modal */}
      <PlatformDetailModal
        platform={selectedPlatformConfig}
        record={detailPlatformId ? platformRecords[detailPlatformId] : undefined}
        onClose={() => setDetailPlatformId(null)}
        onOpenUpload={handleOpenUploadForPlatform}
      />

      {/* School Configuration Modal */}
      <SchoolConfigModal
        isOpen={isConfigModalOpen}
        profile={schoolProfile}
        onClose={() => setIsConfigModalOpen(false)}
        onSave={setSchoolProfile}
      />
    </div>
  );
}
