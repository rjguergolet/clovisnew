import React, { useState } from 'react';
import { TurmaPerformance } from '../types';
import { 
  Users, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle,
  ArrowUpDown,
  Filter,
  Plus,
  Trash2
} from 'lucide-react';

interface CorrelationsViewProps {
  turmas: TurmaPerformance[];
  onUpdateTurmas?: (turmas: TurmaPerformance[]) => void;
}

export const CorrelationsView: React.FC<CorrelationsViewProps> = ({ 
  turmas,
  onUpdateTurmas
}) => {
  const [selectedSegment, setSelectedSegment] = useState<string>('all');
  const [sortField, setSortField] = useState<keyof TurmaPerformance>('turma');
  const [sortAsc, setSortAsc] = useState<boolean>(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Manual turma form
  const [newTurmaNome, setNewTurmaNome] = useState('');
  const [newSegmento, setNewSegmento] = useState<TurmaPerformance['segmento']>('Anos Finais');
  const [newAlunos, setNewAlunos] = useState(32);
  const [newFreq, setNewFreq] = useState(90);
  const [newTarefa, setNewTarefa] = useState(80);
  const [newRedacao, setNewRedacao] = useState(80);
  const [newProva, setNewProva] = useState(65);

  const handleSort = (field: keyof TurmaPerformance) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false); // default desc for numbers
    }
  };

  const handleAddTurma = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTurmaNome.trim()) return;

    const platAvg = parseFloat(((newFreq + newTarefa + newRedacao + newProva) / 4).toFixed(1));
    const newT: TurmaPerformance = {
      turma: newTurmaNome.trim(),
      segmento: newSegmento,
      totalAlunos: newAlunos,
      frequenciaMedia: newFreq,
      tarefaSpAdesao: newTarefa,
      redacaoEntregas: newRedacao,
      provaPaulistaAcertos: newProva,
      plataformasAdesaoGeral: platAvg,
      statusGeral: platAvg >= 80 ? 'excelente' : (platAvg < 65 ? 'critico' : 'atencao')
    };

    if (onUpdateTurmas) {
      onUpdateTurmas([...turmas, newT]);
    }
    setIsModalOpen(false);
    setNewTurmaNome('');
  };

  const handleDeleteTurma = (nome: string) => {
    if (onUpdateTurmas) {
      onUpdateTurmas(turmas.filter(t => t.turma !== nome));
    }
  };

  const filteredTurmas = turmas.filter(t => {
    if (selectedSegment === 'all') return true;
    return t.segmento === selectedSegment;
  }).sort((a, b) => {
    const valA = a[sortField];
    const valB = b[sortField];
    if (typeof valA === 'number' && typeof valB === 'number') {
      return sortAsc ? valA - valB : valB - valA;
    }
    return sortAsc 
      ? String(valA).localeCompare(String(valB)) 
      : String(valB).localeCompare(String(valA));
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Title & Introduction */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Cruzamento Pedagógico & Desempenho por Turma
            </h2>
            <p className="text-xs text-slate-500 mt-1 max-w-3xl leading-relaxed">
              Esta visão correlaciona os dados de assiduidade do <strong>Aluno Presente</strong> com o engajamento na <strong>Tarefa SP</strong>, <strong>Redação Paulista</strong> e o rendimento na <strong>Prova Paulista</strong>. As turmas podem ser importadas automaticamente das planilhas ou cadastradas manualmente.
            </p>
          </div>

          {onUpdateTurmas && (
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs whitespace-nowrap self-start sm:self-center"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Adicionar Turma</span>
            </button>
          )}
        </div>
      </div>

      {/* Turmas Heatmap Data Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Matriz Comparativa das Turmas (Heatmap SEDUC)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Clique nas colunas para ordenar por qualquer indicador.
            </p>
          </div>

          {/* Segment Filter */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setSelectedSegment('all')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedSegment === 'all' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Todas as Turmas ({turmas.length})
            </button>
            <button
              onClick={() => setSelectedSegment('Anos Iniciais')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedSegment === 'Anos Iniciais' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Anos Iniciais
            </button>
            <button
              onClick={() => setSelectedSegment('Anos Finais')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedSegment === 'Anos Finais' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Anos Finais
            </button>
            <button
              onClick={() => setSelectedSegment('Ensino Médio')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedSegment === 'Ensino Médio' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Ensino Médio
            </button>
          </div>
        </div>

        {filteredTurmas.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400 bg-slate-50/50">
            <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-700">Nenhuma turma cadastrada ou importada ainda.</p>
            <p className="mt-1">Ao subir planilhas do Aluno Presente, Tarefa SP ou Prova Paulista contendo as turmas, elas aparecerão aqui automaticamente.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 uppercase font-semibold tracking-wider text-[11px]">
                <tr>
                  <th 
                    onClick={() => handleSort('turma')}
                    className="px-4 py-3.5 cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Turma</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th className="px-4 py-3.5">Segmento</th>
                  <th 
                    onClick={() => handleSort('totalAlunos')}
                    className="px-4 py-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Alunos</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('frequenciaMedia')}
                    className="px-4 py-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Aluno Presente (%)</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('tarefaSpAdesao')}
                    className="px-4 py-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Tarefa SP (%)</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('redacaoEntregas')}
                    className="px-4 py-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Redação SP (%)</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('provaPaulistaAcertos')}
                    className="px-4 py-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Prova Paulista (% Acertos)</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('plataformasAdesaoGeral')}
                    className="px-4 py-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Plataformas Média</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th className="px-4 py-3.5 text-center">Status</th>
                  {onUpdateTurmas && <th className="px-4 py-3.5 text-center">Ações</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredTurmas.map((t) => {
                  const isFreqLow = t.frequenciaMedia < 85;
                  const isTarefaLow = t.tarefaSpAdesao < 70;
                  const isProvaLow = t.provaPaulistaAcertos < 60;

                  return (
                    <tr key={t.turma} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 font-bold text-slate-900 whitespace-nowrap">
                        {t.turma}
                      </td>
                      <td className="px-4 py-3 text-slate-500 whitespace-nowrap">
                        {t.segmento}
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-600">
                        {t.totalAlunos}
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums">
                        <span className={`inline-block px-2 py-0.5 rounded font-semibold ${
                          t.frequenciaMedia >= 90 
                            ? 'text-emerald-700 bg-emerald-50' 
                            : (isFreqLow ? 'text-rose-700 bg-rose-50 font-bold' : 'text-amber-700 bg-amber-50')
                        }`}>
                          {t.frequenciaMedia}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums">
                        <span className={`inline-block px-2 py-0.5 rounded font-semibold ${
                          t.tarefaSpAdesao >= 80 
                            ? 'text-emerald-700 bg-emerald-50' 
                            : (isTarefaLow ? 'text-rose-700 bg-rose-50 font-bold' : 'text-amber-700 bg-amber-50')
                        }`}>
                          {t.tarefaSpAdesao}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums">
                        <span className={`inline-block px-2 py-0.5 rounded font-semibold ${
                          t.redacaoEntregas >= 80 
                            ? 'text-emerald-700 bg-emerald-50' 
                            : (t.redacaoEntregas < 70 ? 'text-rose-700 bg-rose-50 font-bold' : 'text-amber-700 bg-amber-50')
                        }`}>
                          {t.redacaoEntregas}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums">
                        <span className={`inline-block px-2 py-0.5 rounded font-semibold ${
                          t.provaPaulistaAcertos >= 68 
                            ? 'text-emerald-700 bg-emerald-50' 
                            : (isProvaLow ? 'text-rose-700 bg-rose-50 font-bold' : 'text-amber-700 bg-amber-50')
                        }`}>
                          {t.provaPaulistaAcertos}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-800 font-semibold">
                        {t.plataformasAdesaoGeral}%
                      </td>
                      <td className="px-4 py-3 text-center">
                        {t.statusGeral === 'excelente' && (
                          <span className="text-emerald-700 font-semibold text-[11px]">
                            Consolidado
                          </span>
                        )}
                        {t.statusGeral === 'atencao' && (
                          <span className="text-amber-700 font-semibold text-[11px]">
                            Atenção
                          </span>
                        )}
                        {t.statusGeral === 'critico' && (
                          <span className="text-rose-700 font-bold text-[11px]">
                            Intervenção Urgente
                          </span>
                        )}
                      </td>
                      {onUpdateTurmas && (
                        <td className="px-4 py-3 text-center">
                          <button
                            onClick={() => handleDeleteTurma(t.turma)}
                            title="Remover turma"
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Table Legend */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Acima da Meta SEDUC</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>Atenção / Risco Moderado</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>Abaixo do Limiar Crítico</span>
            </span>
          </div>

          <span>Metas Oficiais: Aluno Presente $\ge 90\%$, Tarefa SP $\ge 80\%$, Redação $\ge 80\%$.</span>
        </div>
      </div>

      {/* Modal: Adicionar Turma Manualmente */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Cadastrar Nova Turma
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddTurma} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nome da Turma / Classe:
                </label>
                <input
                  type="text"
                  placeholder="Ex: 6º Ano A, 1ª Série B EM..."
                  value={newTurmaNome}
                  onChange={(e) => setNewTurmaNome(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Segmento:
                  </label>
                  <select
                    value={newSegmento}
                    onChange={(e) => setNewSegmento(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
                  >
                    <option value="Anos Iniciais">Anos Iniciais</option>
                    <option value="Anos Finais">Anos Finais</option>
                    <option value="Ensino Médio">Ensino Médio</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Total de Estudantes:
                  </label>
                  <input
                    type="number"
                    value={newAlunos}
                    onChange={(e) => setNewAlunos(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Frequência (%)
                  </label>
                  <input
                    type="number"
                    value={newFreq}
                    onChange={(e) => setNewFreq(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Tarefa SP (%)
                  </label>
                  <input
                    type="number"
                    value={newTarefa}
                    onChange={(e) => setNewTarefa(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Redação SP (%)
                  </label>
                  <input
                    type="number"
                    value={newRedacao}
                    onChange={(e) => setNewRedacao(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Prova Paulista (% Acertos)
                  </label>
                  <input
                    type="number"
                    value={newProva}
                    onChange={(e) => setNewProva(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
                >
                  Salvar Turma
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
