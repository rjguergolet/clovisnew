import React, { useState } from 'react';
import { ActionPlanItem } from '../types';
import { 
  ClipboardList, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Download,
  Trash2,
  Edit2
} from 'lucide-react';
import * as XLSX from 'xlsx';

interface ActionPlanMMRViewProps {
  actionPlan: ActionPlanItem[];
  onUpdatePlan: (updatedPlan: ActionPlanItem[]) => void;
}

export const ActionPlanMMRView: React.FC<ActionPlanMMRViewProps> = ({
  actionPlan,
  onUpdatePlan
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Form State
  const [newOrigem, setNewOrigem] = useState('');
  const [newProblema, setNewProblema] = useState('');
  const [newCausaRaiz, setNewCausaRaiz] = useState('');
  const [newAcao, setNewAcao] = useState('');
  const [newResponsavel, setNewResponsavel] = useState('CGPG & Docentes');
  const [newPrazo, setNewPrazo] = useState('30/11/2026');
  const [newIndicador, setNewIndicador] = useState('');
  const [newPrioridade, setNewPrioridade] = useState<'alta' | 'media' | 'baixa'>('alta');

  const handleToggleStatus = (id: string) => {
    const updated = actionPlan.map(item => {
      if (item.id === id) {
        const nextStatus = item.status === 'nao_iniciado' 
          ? 'em_andamento' 
          : (item.status === 'em_andamento' ? 'concluido' : 'em_andamento');
        return { ...item, status: nextStatus as ActionPlanItem['status'] };
      }
      return item;
    });
    onUpdatePlan(updated);
  };

  const handleDeleteItem = (id: string) => {
    onUpdatePlan(actionPlan.filter(item => item.id !== id));
  };

  const handleCreateAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProblema || !newAcao) return;

    const newItem: ActionPlanItem = {
      id: `mmr_${Date.now()}`,
      origem: newOrigem || 'Diagnóstico Integrado',
      problema: newProblema,
      causaRaiz: newCausaRaiz || 'Identificada no Conselho de Classe',
      acaoProposta: newAcao,
      responsavel: newResponsavel,
      prazo: newPrazo,
      indicadorMeta: newIndicador || 'Atingir meta SEDUC-SP',
      status: 'em_andamento',
      prioridade: newPrioridade
    };

    onUpdatePlan([newItem, ...actionPlan]);
    setIsModalOpen(false);
    // Reset form
    setNewOrigem('');
    setNewProblema('');
    setNewCausaRaiz('');
    setNewAcao('');
    setNewIndicador('');
  };

  const handleExportXLSX = () => {
    const dataToExport = actionPlan.map(a => ({
      'ID': a.id,
      'Origem / Plataforma': a.origem,
      'Problema Priorizado': a.problema,
      'Causa Raiz': a.causaRaiz,
      'Ação Proposta (5W2H)': a.acaoProposta,
      'Responsável': a.responsavel,
      'Prazo Final': a.prazo,
      'Indicador de Sucesso / Meta': a.indicadorMeta,
      'Prioridade': a.prioridade.toUpperCase(),
      'Status': a.status === 'concluido' ? 'Concluído' : (a.status === 'em_andamento' ? 'Em Andamento' : 'Não Iniciado')
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Plano_MMR_SEDUC');
    XLSX.writeFile(workbook, 'Plano_Acao_MMR_Escolar_SEDUC_SP.xlsx');
  };

  const filteredPlan = actionPlan.filter(item => {
    if (filterStatus === 'all') return true;
    return item.status === filterStatus;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>Método de Melhoria de Resultados (MMR)</span>
              <span aria-hidden="true">·</span>
              <span>Diretrizes Oficiais SEDUC-SP</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Plano de Ação Integrado (MMR / 5W2H)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Ações estruturadas automaticamente a partir dos gargalos detectados nas avaliações e no engajamento das plataformas.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={handleExportXLSX}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-slate-600" />
              <span>Exportar Excel (.xlsx)</span>
            </button>

            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Nova Ação MMR</span>
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 mt-5 border-t border-slate-100 pt-4 text-xs">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors ${
              filterStatus === 'all' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Todas as Ações ({actionPlan.length})
          </button>
          <button
            onClick={() => setFilterStatus('em_andamento')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors ${
              filterStatus === 'em_andamento' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Em Andamento ({actionPlan.filter(a => a.status === 'em_andamento').length})
          </button>
          <button
            onClick={() => setFilterStatus('nao_iniciado')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors ${
              filterStatus === 'nao_iniciado' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Não Iniciadas ({actionPlan.filter(a => a.status === 'nao_iniciado').length})
          </button>
          <button
            onClick={() => setFilterStatus('concluido')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors ${
              filterStatus === 'concluido' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Concluídas ({actionPlan.filter(a => a.status === 'concluido').length})
          </button>
        </div>
      </div>

      {/* Action Plan List / Cards */}
      <div className="space-y-4">
        {filteredPlan.map((item) => {
          const isDone = item.status === 'concluido';
          const isHigh = item.prioridade === 'alta';

          return (
            <div
              key={item.id}
              className={`bg-white border rounded-xl p-5 shadow-xs transition-all ${
                isDone 
                  ? 'border-slate-200 bg-slate-50/50 opacity-80' 
                  : (isHigh ? 'border-amber-300 hover:border-amber-400' : 'border-slate-200 hover:border-blue-400')
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-blue-700">{item.origem}</span>
                    <span aria-hidden="true">·</span>
                    <span className={`font-semibold ${
                      item.prioridade === 'alta' ? 'text-rose-700' : (item.prioridade === 'media' ? 'text-amber-700' : 'text-slate-600')
                    }`}>
                      Prioridade {item.prioridade.toUpperCase()}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>Prazo: {item.prazo}</span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {item.problema}
                  </h3>

                  <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-1">
                    <div>
                      <strong className="text-slate-800">Causa Raiz:</strong> {item.causaRaiz}
                    </div>
                    <div>
                      <strong className="text-slate-800">Ação Proposta (5W2H):</strong> {item.acaoProposta}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 pt-1">
                    <div>
                      <span className="text-slate-400">Responsável:</span>{' '}
                      <span className="font-medium text-slate-800">{item.responsavel}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Meta / Indicador:</span>{' '}
                      <span className="font-medium text-slate-800">{item.indicadorMeta}</span>
                    </div>
                  </div>
                </div>

                {/* Status Switcher & Actions */}
                <div className="flex items-center gap-2 self-end md:self-start shrink-0">
                  <button
                    onClick={() => handleToggleStatus(item.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                      isDone
                        ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                        : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'
                    }`}
                  >
                    {isDone ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Concluída</span>
                      </>
                    ) : (
                      <>
                        <Clock className="w-3.5 h-3.5 text-blue-600" />
                        <span>{item.status === 'em_andamento' ? 'Em Andamento' : 'Não Iniciado'}</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => handleDeleteItem(item.id)}
                    title="Remover ação"
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: New MMR Action */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Cadastrar Ação de Melhoria (MMR SEDUC)
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAction} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Origem / Plataforma Diagnosticada
                </label>
                <input
                  type="text"
                  placeholder="Ex: Prova Paulista 2B, Tarefa SP, Aluno Presente..."
                  value={newOrigem}
                  onChange={(e) => setNewOrigem(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Problema Priorizado (Gargalo Identificado)
                </label>
                <textarea
                  rows={2}
                  placeholder="Descreva a evidência ou fraqueza observada nos dados..."
                  value={newProblema}
                  onChange={(e) => setNewProblema(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Causa-Raiz (Diagnóstico do Porquê)
                </label>
                <input
                  type="text"
                  placeholder="Ex: Dificuldade estrutural com frações acumulada de anos anteriores..."
                  value={newCausaRaiz}
                  onChange={(e) => setNewCausaRaiz(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Ação Proposta (O que será feito / 5W2H)
                </label>
                <textarea
                  rows={2}
                  placeholder="Ação concreta de intervenção pedagógica ou de busca ativa..."
                  value={newAcao}
                  onChange={(e) => setNewAcao(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Responsável
                  </label>
                  <input
                    type="text"
                    value={newResponsavel}
                    onChange={(e) => setNewResponsavel(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Prazo de Conclusão
                  </label>
                  <input
                    type="text"
                    value={newPrazo}
                    onChange={(e) => setNewPrazo(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Indicador de Sucesso / Meta
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Elevar acertos para 75%"
                    value={newIndicador}
                    onChange={(e) => setNewIndicador(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Prioridade
                  </label>
                  <select
                    value={newPrioridade}
                    onChange={(e) => setNewPrioridade(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
                  >
                    <option value="alta">Alta</option>
                    <option value="media">Média</option>
                    <option value="baixa">Baixa</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
                >
                  Salvar Ação MMR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
