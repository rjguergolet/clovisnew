import React, { useState, useRef } from 'react';
import { PLATFORMS_CATALOG } from '../data/platformsCatalog';
import { parseUploadedFile, ParsedFileResult } from '../services/fileParser';
import { PlatformDataRecord } from '../types';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle, 
  AlertCircle, 
  X,
  FileText,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetPlatformId?: string | null;
  onDataParsed: (record: PlatformDataRecord, extractedTurmas?: any[]) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  targetPlatformId,
  onDataParsed
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<string>(targetPlatformId || 'tarefa_sp');
  const [isProcessing, setIsProcessing] = useState(false);
  const [parseResult, setParseResult] = useState<ParsedFileResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processFile = async (file: File) => {
    setIsProcessing(true);
    setErrorMessage(null);
    try {
      const result = await parseUploadedFile(file, targetPlatformId || selectedPlatform);
      setParseResult(result);
      if (result.detectedPlatformId) {
        setSelectedPlatform(result.detectedPlatformId);
      }
    } catch (err: any) {
      setErrorMessage(`Erro ao ler o arquivo: ${err.message || 'Formato não reconhecido'}.`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await processFile(e.target.files[0]);
    }
  };

  const handleConfirmIngestion = () => {
    if (!parseResult) return;
    const platform = PLATFORMS_CATALOG.find(p => p.id === selectedPlatform);
    if (!platform) return;

    let status: 'excelente' | 'atencao' | 'critico' = 'excelente';
    if (parseResult.calculatedValue < platform.criticalThreshold) {
      status = 'critico';
    } else if (parseResult.calculatedValue < platform.seducTarget) {
      status = 'atencao';
    }

    const newRecord: PlatformDataRecord = {
      id: `rec_${selectedPlatform}_${Date.now()}`,
      platformId: selectedPlatform,
      uploadedAt: new Date().toLocaleString('pt-BR'),
      fileName: parseResult.fileName,
      fileSize: parseResult.fileSize,
      rowCount: parseResult.rowCount,
      currentValue: parseResult.calculatedValue,
      seducTarget: platform.seducTarget,
      status,
      summaryText: parseResult.summaryText,
      criticalAlerts: parseResult.alerts,
      keyInsights: parseResult.insights,
      rawTablePreview: parseResult.previewRows
    };

    onDataParsed(newRecord, parseResult.extractedTurmas);
    onClose();
  };

  const currentPlatformInfo = PLATFORMS_CATALOG.find(p => p.id === selectedPlatform);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full p-6 space-y-5 animate-in fade-in duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <UploadCloud className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                Ingestão de Dados das Plataformas SEDUC-SP
              </h3>
              <p className="text-xs text-slate-500">
                Suporta planilhas Excel (.xlsx, .xls, .ods), arquivos CSV ou relatórios PDF.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-md"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Platform Selection */}
        <div className="space-y-1.5">
          <label className="block text-xs font-semibold text-slate-700">
            Plataforma ou Avaliação de Destino:
          </label>
          <select
            value={selectedPlatform}
            onChange={(e) => setSelectedPlatform(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
          >
            {PLATFORMS_CATALOG.map(p => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.categoryLabel}) — Meta: {p.seducTarget}{p.targetMetricUnit}
              </option>
            ))}
          </select>
          {currentPlatformInfo && (
            <p className="text-[11px] text-slate-500">
              {currentPlatformInfo.description} (Colunas esperadas: {currentPlatformInfo.sampleColumns.join(', ')})
            </p>
          )}
        </div>

        {/* Drag and Drop Zone */}
        {!parseResult ? (
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
              dragActive ? 'border-blue-600 bg-blue-50/50' : 'border-slate-300 hover:border-slate-400 bg-slate-50/50'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv,.tsv,.ods,.pdf,.json"
              onChange={handleChange}
              className="hidden"
            />
            <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-700 mx-auto flex items-center justify-center mb-3">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <p className="text-xs font-bold text-slate-800">
              Arraste sua planilha ou clique para selecionar
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Exportação do SED, CMSP, SuperBI ou Prova Paulista (.xlsx, .csv, .pdf)
            </p>
          </div>
        ) : (
          /* File Parsed Preview */
          <div className="border border-emerald-200 bg-emerald-50/50 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs font-bold text-emerald-950">
                  {parseResult.fileName} ({parseResult.fileSize})
                </span>
              </div>
              <button
                onClick={() => setParseResult(null)}
                className="text-[11px] text-slate-500 hover:text-slate-800 underline"
              >
                Trocar arquivo
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs bg-white p-3 rounded-lg border border-emerald-100">
              <div>
                <span className="text-slate-400 block text-[10px]">Linhas Lidas</span>
                <span className="font-bold text-slate-800 font-mono">{parseResult.rowCount}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Colunas</span>
                <span className="font-bold text-slate-800 font-mono">{parseResult.columns.length}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Métrica Apurada</span>
                <span className="font-bold text-blue-700 font-mono">{parseResult.calculatedValue}{currentPlatformInfo?.targetMetricUnit || '%'}</span>
              </div>
            </div>

            {parseResult.previewRows.length > 0 && (
              <div className="text-[11px] text-slate-600 bg-white p-2 rounded border border-slate-200 overflow-x-auto max-h-28">
                <span className="font-semibold text-slate-800 block mb-1">Prévia dos dados:</span>
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-100 font-semibold text-slate-700">
                      {parseResult.columns.slice(0, 4).map(c => (
                        <th key={c} className="pr-3 pb-1">{c}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {parseResult.previewRows.slice(0, 3).map((r, i) => (
                      <tr key={i} className="border-b border-slate-50 text-slate-600">
                        {parseResult.columns.slice(0, 4).map(c => (
                          <td key={c} className="pr-3 py-0.5">{String(r[c])}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {errorMessage && (
          <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Cancelar
          </button>

          <button
            disabled={!parseResult || isProcessing}
            onClick={handleConfirmIngestion}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors shadow-xs"
          >
            <span>Processar e Atualizar Diagnóstico</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
