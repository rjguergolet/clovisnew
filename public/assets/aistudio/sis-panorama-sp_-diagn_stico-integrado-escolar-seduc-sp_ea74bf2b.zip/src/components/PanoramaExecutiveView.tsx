import React from 'react';
import { DiagnosticPanorama, PlatformDataRecord } from '../types';
import { PLATFORMS_CATALOG } from '../data/platformsCatalog';
import { 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  GraduationCap, 
  Laptop, 
  UserCheck, 
  BookOpen, 
  Award, 
  Building2,
  ArrowRight,
  Sparkles,
  UploadCloud,
  FileSpreadsheet
} from 'lucide-react';

interface PanoramaExecutiveViewProps {
  panorama: DiagnosticPanorama;
  platformRecords: Record<string, PlatformDataRecord>;
  onNavigateTab: (tab: string) => void;
  onSelectPlatform: (platformId: string) => void;
  onOpenUpload: () => void;
}

export const PanoramaExecutiveView: React.FC<PanoramaExecutiveViewProps> = ({
  panorama,
  platformRecords,
  onNavigateTab,
  onSelectPlatform,
  onOpenUpload
}) => {
  const { schoolProfile, scoreGeralEscola, classificacaoEscola, eixosScores, loadedPlatformsCount } = panorama;

  const getScoreProgressBg = (score: number) => {
    if (score >= 85) return 'bg-emerald-600';
    if (score >= 70) return 'bg-blue-600';
    if (score >= 55) return 'bg-amber-500';
    return 'bg-rose-600';
  };

  const tarefaSp = platformRecords['tarefa_sp'];
  const alunoPresente = platformRecords['aluno_presente'];
  const redacao = platformRecords['redacao_paulista'];
  const provaP2 = platformRecords['prova_paulista_2b'] || platformRecords['prova_paulista_1b'];
  const superBi = platformRecords['super_bi'];
  const peiExcel = platformRecords['escolas_excelencia_pei'];

  return (
    <div className="space-y-8 pb-12">
      {/* School Header Banner */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1.5">
              <span>CIE: {schoolProfile.codCIE || 'Não Informado'}</span>
              <span aria-hidden="true">·</span>
              <span>{schoolProfile.diretoriaEnsino}</span>
              <span aria-hidden="true">·</span>
              <span>{schoolProfile.municipio}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              {schoolProfile.nome}
            </h1>
            <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-slate-600">
              <span className="font-semibold text-slate-800">
                {schoolProfile.modelo === 'PEI_9H' ? 'Programa Ensino Integral (PEI - 9 Horas)' : (schoolProfile.modelo === 'PEI_7H' ? 'PEI (7 Horas)' : 'Ensino Regular')}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-blue-700">{schoolProfile.bimestreReferencia} / {schoolProfile.anoLetivo}</span>
              <span aria-hidden="true">·</span>
              <span>{loadedPlatformsCount} de 41 Plataformas Sincronizadas</span>
            </div>
          </div>

          <div className="flex items-center gap-4 border-t lg:border-t-0 lg:border-l border-slate-100 pt-4 lg:pt-0 lg:pl-6 shrink-0">
            <div className="text-right">
              <span className="text-xs text-slate-500 uppercase tracking-wider block font-medium">
                Índice Geral de Desempenho
              </span>
              <div className="flex items-baseline justify-end gap-1.5 mt-0.5">
                <span className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-mono tabular-nums">
                  {scoreGeralEscola}
                </span>
                <span className="text-sm font-semibold text-slate-400">/ 100</span>
              </div>
              <span className={`text-xs font-semibold block mt-0.5 ${
                classificacaoEscola === 'Excelência PEI' ? 'text-emerald-700' : (classificacaoEscola === 'Aguardando Dados' ? 'text-slate-400' : 'text-blue-700')
              }`}>
                {classificacaoEscola}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Empty State Banner if 0 platforms loaded */}
      {loadedPlatformsCount === 0 && (
        <section className="bg-white border-2 border-dashed border-blue-200 rounded-xl p-8 text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-blue-50 text-blue-700 mx-auto flex items-center justify-center">
            <UploadCloud className="w-7 h-7" />
          </div>
          <div className="max-w-xl mx-auto space-y-1.5">
            <h3 className="text-base font-bold text-slate-900">
              Nenhum dado mockado carregado — Ambiente 100% Real
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              O sistema está pronto para receber as exportações em <strong>Excel (.xlsx)</strong>, <strong>CSV</strong> ou <strong>PDF</strong> de qualquer uma das 41 plataformas da SEDUC-SP. À medida que você sobe os arquivos, o diagnóstico, os alertas e o histórico são gerados e salvos localmente no seu navegador.
            </p>
          </div>
          <div className="pt-2 flex justify-center gap-3">
            <button
              onClick={onOpenUpload}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Fazer Upload do Primeiro Relatório</span>
            </button>
            <button
              onClick={() => onNavigateTab('plataformas')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <span>Ver Catálogo das 41 Plataformas</span>
            </button>
          </div>
        </section>
      )}

      {/* Main KPI Strip: Core SEDUC Indicators */}
      <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* KPI 1: Aluno Presente */}
        <div 
          onClick={() => onSelectPlatform('aluno_presente')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium truncate">Aluno Presente</span>
            <UserCheck className="w-4 h-4 text-blue-600 shrink-0" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {alunoPresente ? `${alunoPresente.currentValue}%` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Meta: 90%</span>
            {alunoPresente ? (
              <span className={alunoPresente.currentValue >= 90 ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                {alunoPresente.currentValue >= 90 ? 'Atingida' : 'Atenção'}
              </span>
            ) : (
              <span className="text-slate-400">Pendente</span>
            )}
          </div>
        </div>

        {/* KPI 2: Tarefa SP */}
        <div 
          onClick={() => onSelectPlatform('tarefa_sp')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium truncate">Tarefa SP</span>
            <Laptop className="w-4 h-4 text-amber-600 shrink-0" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {tarefaSp ? `${tarefaSp.currentValue}%` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Meta: 80%</span>
            {tarefaSp ? (
              <span className={tarefaSp.currentValue >= 80 ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                {tarefaSp.currentValue >= 80 ? 'Superada' : 'Abaixo'}
              </span>
            ) : (
              <span className="text-slate-400">Pendente</span>
            )}
          </div>
        </div>

        {/* KPI 3: Redação Paulista */}
        <div 
          onClick={() => onSelectPlatform('redacao_paulista')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium truncate">Redação Paulista</span>
            <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {redacao ? `${redacao.currentValue} red/aluno` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Meta: 0.80</span>
            {redacao ? (
              <span className={redacao.currentValue >= 0.8 ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                {redacao.currentValue >= 0.8 ? 'Superada' : 'Abaixo (0.69)'}
              </span>
            ) : (
              <span className="text-slate-400">Pendente</span>
            )}
          </div>
        </div>

        {/* KPI 4: Prova Paulista */}
        <div 
          onClick={() => onSelectPlatform('prova_paulista_3b')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium truncate">Prova Paulista (PP3)</span>
            <GraduationCap className="w-4 h-4 text-yellow-600 shrink-0" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {platformRecords['prova_paulista_3b'] ? `${platformRecords['prova_paulista_3b'].currentValue}%` : (provaP2 ? `${provaP2.currentValue}%` : '—')}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Evolução</span>
            <span className="text-emerald-700 font-semibold font-mono">
              PP1: 53.2% → PP3: 54.6%
            </span>
          </div>
        </div>

        {/* KPI 5: Escolas de Excelência PEI */}
        <div 
          onClick={() => onSelectPlatform('escolas_excelencia_pei')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium truncate">Excelência PEI</span>
            <Award className="w-4 h-4 text-emerald-600 shrink-0" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {peiExcel ? `${peiExcel.currentValue}%` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Premissas</span>
            {peiExcel ? (
              <span className="text-emerald-700 font-semibold">Ativo (7 Horas)</span>
            ) : (
              <span className="text-slate-400">Pendente</span>
            )}
          </div>
        </div>

        {/* KPI 6: Super BI Geral */}
        <div 
          onClick={() => onSelectPlatform('super_bi')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium truncate">SUPER BI (Nota)</span>
            <TrendingUp className="w-4 h-4 text-amber-600 shrink-0" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {superBi ? `${superBi.currentValue} pts` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Escala 0 a 10</span>
            {superBi ? (
              <span className="text-blue-700 font-semibold">Farol SARESP: 2</span>
            ) : (
              <span className="text-slate-400">Pendente</span>
            )}
          </div>
        </div>
      </section>

      {/* 6 Educational Axes Detailed Breakdown */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Diagnóstico Estruturado por Eixos Educacionais
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Consolidação das 41 plataformas divididas pelas dimensões estratégicas da gestão escolar paulista.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('plataformas')}
            className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1"
          >
            <span>Ver todas as 41 plataformas</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Eixo 1: Avaliações & Rendimento */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-yellow-600" />
                Avaliações & Rendimento
              </span>
              <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                {eixosScores.avaliacoes > 0 ? `${eixosScores.avaliacoes}%` : 'Sem dados'}
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full ${getScoreProgressBg(eixosScores.avaliacoes)}`} 
                style={{ width: `${eixosScores.avaliacoes}%` }}
              />
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Prova Paulista 1B, 2B e 3B, Saresp Diagnóstico, Recomposição, Simulado SP, Boletins e Recuperação Contínua.
            </p>
          </div>

          {/* Eixo 2: Plataformas Digitais de Aprendizagem */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Laptop className="w-4 h-4 text-blue-600" />
                Plataformas de Aprendizagem
              </span>
              <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                {eixosScores.plataformasDigitais > 0 ? `${eixosScores.plataformasDigitais}%` : 'Sem dados'}
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full ${getScoreProgressBg(eixosScores.plataformasDigitais)}`} 
                style={{ width: `${eixosScores.plataformasDigitais}%` }}
              />
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Tarefa SP, Redação Paulista, Leia SP, Alura, Matific, Khan Academy, Speak, Open English e Robótica SPtec.
            </p>
          </div>

          {/* Eixo 3: Frequência & Busca Ativa */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-emerald-600" />
                Frequência & Busca Ativa
              </span>
              <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                {eixosScores.frequencia > 0 ? `${eixosScores.frequencia}%` : 'Sem dados'}
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full ${getScoreProgressBg(eixosScores.frequencia)}`} 
                style={{ width: `${eixosScores.frequencia}%` }}
              />
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Aluno Presente diário, censo de matrículas ativas no SED, monitoramento de evasão e Monitores do BEEM.
            </p>
          </div>

          {/* Eixo 4: Gestão Pedagógica & Tutoria */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                Gestão Pedagógica & Tutoria
              </span>
              <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                {eixosScores.gestaoDocente > 0 ? `${eixosScores.gestaoDocente}%` : 'Sem dados'}
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full ${getScoreProgressBg(eixosScores.gestaoDocente)}`} 
                style={{ width: `${eixosScores.gestaoDocente}%` }}
              />
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Planejamento de Aula no SED, Mapa Classe, Professor Tutor Iniciais e Finais, Apoio Presencial e Expansão.
            </p>
          </div>

          {/* Eixo 5: Modelo PEI & Ensino Médio */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-rose-600" />
                Modelo PEI & Ensino Médio
              </span>
              <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                {eixosScores.modeloPeiFuturo > 0 ? `${eixosScores.modeloPeiFuturo}%` : 'Sem dados'}
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full ${getScoreProgressBg(eixosScores.modeloPeiFuturo)}`} 
                style={{ width: `${eixosScores.modeloPeiFuturo}%` }}
              />
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Escolas de Excelência PEI 1 e 2, Edu Profissional, Prepara SP, Aulas Olímpicas e Meu Diploma SP.
            </p>
          </div>

          {/* Eixo 6: Infraestrutura & Gestão Predial */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-slate-700" />
                Infraestrutura & Gestão
              </span>
              <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                {eixosScores.infraestrutura > 0 ? `${eixosScores.infraestrutura}%` : 'Sem dados'}
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full ${getScoreProgressBg(eixosScores.infraestrutura)}`} 
                style={{ width: `${eixosScores.infraestrutura}%` }}
              />
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              Manutenção Predial (FDE / PDDE Paulista), matrículas no SED e consolidação no SUPER BI.
            </p>
          </div>
        </div>
      </section>

      {/* Destaques Positivos & Vulnerabilidades Críticas (se houver dados) */}
      {(panorama.destaquesPositivos.length > 0 || panorama.vulnerabilidadesCriticas.length > 0) && (
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Destaques Positivos */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <h3 className="text-base font-bold text-slate-900">
                Destaques e Pontos Fortes da Escola
              </h3>
            </div>
            <ul className="space-y-3">
              {panorama.destaquesPositivos.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 leading-relaxed">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Vulnerabilidades Críticas */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <h3 className="text-base font-bold text-slate-900">
                Vulnerabilidades & Focos de Intervenção
              </h3>
            </div>
            <ul className="space-y-3">
              {panorama.vulnerabilidadesCriticas.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 leading-relaxed">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* Pedagogical Correlations (se houver dados) */}
      {panorama.correlacoesChave.length > 0 && (
        <section className="bg-gradient-to-r from-blue-900 to-indigo-900 rounded-xl p-6 text-white shadow-xs">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-amber-300" />
            <h3 className="text-base font-bold tracking-tight">
              Cruzamento Pedagógico & Correlações Calculadas com Dados Reais
            </h3>
          </div>
          <p className="text-xs text-blue-100 max-w-3xl mb-6">
            Relações apuradas a partir dos relatórios que você subiu:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {panorama.correlacoesChave.map((corr, idx) => (
              <div key={idx} className="bg-white/10 backdrop-blur-xs rounded-lg p-4 border border-white/10">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-white">
                    {corr.titulo}
                  </span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-300 bg-amber-400/20 px-1.5 py-0.5 rounded">
                    {corr.grau}
                  </span>
                </div>
                <p className="text-xs text-blue-100 leading-relaxed mb-2">
                  {corr.descricao}
                </p>
                <div className="text-[11px] text-blue-200 font-medium">
                  Orientação: {corr.impacto}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
