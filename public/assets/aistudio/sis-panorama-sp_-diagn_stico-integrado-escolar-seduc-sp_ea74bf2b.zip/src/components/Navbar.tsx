import React from 'react';
import { School, UploadCloud, History, Printer, Settings } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  onOpenUpload: () => void;
  onOpenConfig: () => void;
  loadedCount: number;
  totalCount: number;
  snapshotsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  onOpenUpload,
  onOpenConfig,
  loadedCount,
  totalCount,
  snapshotsCount
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          
          {/* Zone 1: Wordmark Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-blue-700 text-white flex items-center justify-center font-bold shadow-xs">
              <School className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap block leading-tight">
                SIS-PANORAMA SP
              </span>
              <span className="text-xs text-slate-600 whitespace-nowrap block">
                Diagnóstico Integrado SEDUC-SP
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links (single line) */}
          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-slate-600">
            <button
              onClick={() => onTabChange('panorama')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
                currentTab === 'panorama' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              Panorama 360°
            </button>

            <button
              onClick={() => onTabChange('plataformas')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1.5 ${
                currentTab === 'plataformas' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              <span>41 Plataformas</span>
              <span className="text-xs px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded font-mono">
                {loadedCount}/{totalCount}
              </span>
            </button>

            <button
              onClick={() => onTabChange('escolatotal')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
                currentTab === 'escolatotal' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              Escola Total & Super BI
            </button>

            <button
              onClick={() => onTabChange('turmas')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
                currentTab === 'turmas' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              Turmas & Cruzamento
            </button>

            <button
              onClick={() => onTabChange('mmr')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
                currentTab === 'mmr' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              Plano MMR
            </button>

            <button
              onClick={() => onTabChange('historico')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1.5 ${
                currentTab === 'historico' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Histórico ({snapshotsCount})</span>
            </button>

            <button
              onClick={() => onTabChange('dossie')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1 ${
                currentTab === 'dossie' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Dossiê Impresso</span>
            </button>
          </nav>

          {/* Zone 3: Primary Action buttons */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={onOpenConfig}
              title="Configurar Nome da Escola, CIE e Diretoria"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Settings className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenUpload}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs whitespace-nowrap"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Subir Relatório / Excel</span>
            </button>
          </div>

        </div>
      </div>
      
      {/* Mobile subnavigation bar */}
      <div className="lg:hidden flex items-center justify-between overflow-x-auto px-4 py-2 bg-slate-100 border-t border-slate-200 text-xs font-medium gap-2">
        <button
          onClick={() => onTabChange('panorama')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'panorama' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Panorama 360°
        </button>
        <button
          onClick={() => onTabChange('plataformas')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'plataformas' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Plataformas ({loadedCount})
        </button>
        <button
          onClick={() => onTabChange('escolatotal')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'escolatotal' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Escola Total & BI
        </button>
        <button
          onClick={() => onTabChange('turmas')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'turmas' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Turmas
        </button>
        <button
          onClick={() => onTabChange('mmr')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'mmr' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Plano MMR
        </button>
        <button
          onClick={() => onTabChange('historico')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'historico' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Histórico ({snapshotsCount})
        </button>
        <button
          onClick={() => onTabChange('dossie')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'dossie' ? 'bg-white text-blue-700 font-bold shadow-xs' : 'text-slate-600'}`}
        >
          Dossiê
        </button>
      </div>
    </header>
  );
};
