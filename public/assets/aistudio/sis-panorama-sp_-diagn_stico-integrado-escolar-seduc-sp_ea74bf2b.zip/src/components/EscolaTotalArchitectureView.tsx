import React, { useState } from 'react';
import { 
  ESCOLA_TOTAL_PORTALS, 
  SUPER_BI_ENGINE_RULES, 
  PLATFORMS_CATALOG 
} from '../data/platformsCatalog';
import { PlatformDataRecord } from '../types';
import { 
  ExternalLink, 
  Network, 
  Layers, 
  Calculator, 
  HelpCircle, 
  CheckCircle2, 
  BookOpen, 
  Laptop, 
  ShieldCheck, 
  ArrowRight,
  Sliders,
  Sparkles
} from 'lucide-react';

interface EscolaTotalArchitectureViewProps {
  platformRecords: Record<string, PlatformDataRecord>;
  onSelectPlatform: (platformId: string) => void;
  onOpenUpload: (platformId?: string) => void;
}

export const EscolaTotalArchitectureView: React.FC<EscolaTotalArchitectureViewProps> = ({
  platformRecords,
  onSelectPlatform,
  onOpenUpload
}) => {
  const [selectedSemester, setSelectedSemester] = useState<'1' | '2'>('2');
  const [selectedCiclo, setSelectedCiclo] = useState<'todos' | 'iniciais' | 'finais' | 'em'>('todos');

  // Simulation values (either from loaded real records or default reference targets)
  const [simTarefaSp, setSimTarefaSp] = useState<number>(
    platformRecords['tarefa_sp'] ? platformRecords['tarefa_sp'].currentValue : 80
  );
  const [simRedacao, setSimRedacao] = useState<number>(
    platformRecords['redacao_paulista'] ? platformRecords['redacao_paulista'].currentValue : 0.80
  );
  const [simLeiaSp, setSimLeiaSp] = useState<number>(
    platformRecords['leia_sp'] ? platformRecords['leia_sp'].currentValue : 25
  );
  const [simMatific, setSimMatific] = useState<number>(
    platformRecords['matific_finais'] ? platformRecords['matific_finais'].currentValue : 4.0
  );
  const [simKhan, setSimKhan] = useState<number>(
    platformRecords['khan_academy'] ? platformRecords['khan_academy'].currentValue : 2.0
  );
  const [simAlura, setSimAlura] = useState<number>(
    platformRecords['alura'] ? platformRecords['alura'].currentValue : 6.0
  );
  const [simSpeak, setSimSpeak] = useState<number>(
    platformRecords['speak_ingles'] ? platformRecords['speak_ingles'].currentValue : 0.375
  );

  // Compute 1st Semester Simulated Basket Score (Max 0.75 pt)
  // Weights: Matific/Khan: 2.86, Redacao: 2.14, Leia: 2.14, Alura: 1.43
  const calcScore1Semestre = () => {
    const factorMat = Math.min(1.0, simMatific / 4.0) * 2.86;
    const factorRed = Math.min(1.0, simRedacao / 0.80) * 2.14;
    const factorLeia = Math.min(1.0, simLeiaSp / 25.0) * 2.14;
    const factorAlura = Math.min(1.0, simAlura / 6.0) * 1.43;
    const totalWeight = 2.86 + 2.14 + 2.14 + 1.43; // 8.57
    const basketRatio = (factorMat + factorRed + factorLeia + factorAlura) / totalWeight;
    return parseFloat((basketRatio * 0.75).toFixed(2));
  };

  // Compute 2nd Semester Simulated Tarefa SP Score (Max 1.0 pt)
  const calcScore2Semestre = () => {
    const ratio = Math.min(1.0, simTarefaSp / 80.0);
    return parseFloat((ratio * 1.0).toFixed(2));
  };

  const currentSimScore = selectedSemester === '1' ? calcScore1Semestre() : calcScore2Semestre();

  // Filter platforms by cycle
  const getCyclePlatforms = () => {
    return PLATFORMS_CATALOG.filter(p => {
      if (selectedCiclo === 'iniciais') {
        return p.id === 'matific_iniciais' || p.id === 'elefante_letrado' || p.id === 'elefante_letrado_mun' || p.id === 'professor_tutor_iniciais';
      }
      if (selectedCiclo === 'finais') {
        return p.id === 'tarefa_sp' || p.id === 'redacao_paulista' || p.id === 'leia_sp' || p.id === 'matific_finais' || p.id === 'speak_ingles' || p.id === 'alura' || p.id === 'robotica_sptec' || p.id === 'professor_tutor_finais';
      }
      if (selectedCiclo === 'em') {
        return p.id === 'tarefa_sp' || p.id === 'redacao_paulista' || p.id === 'leia_sp' || p.id === 'khan_academy' || p.id === 'speak_ingles' || p.id === 'alura' || p.id === 'prepara_sp' || p.id === 'open_english' || p.id === 'projeto_empreendedorismo' || p.id === 'edu_profissional';
      }
      return p.category === 'plataformas_digitais' || p.id === 'super_bi' || p.id === 'prepara_sp';
    });
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Institucional */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-blue-700 font-semibold mb-1">
              <Network className="w-4 h-4 text-blue-700" />
              <span>Ecossistema Escola Total (SP Total) & SEDUC-SP</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Arquitetura Oficial, Manuais Técnicos & Regras de Cálculo
            </h2>
            <p className="text-xs text-slate-500 mt-1 max-w-3xl leading-relaxed">
              Consulte os três portais oficiais da SEDUC-SP, a engenharia de indicadores com o denominador da <strong>Semana Anterior da SED</strong> e simule o impacto das plataformas no <strong>Super BI</strong> segundo as regras oficiais do 1º e do 2º semestre.
            </p>
          </div>
        </div>
      </div>

      {/* Os 3 Endereços Oficiais Centrais da SEDUC-SP */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {ESCOLA_TOTAL_PORTALS.map((portal, idx) => (
          <div 
            key={idx}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:border-blue-400 transition-all flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">
                  {portal.tipo}
                </span>
                <a
                  href={portal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-blue-700 transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>

              <h3 className="text-sm font-bold text-slate-900">
                {portal.nome}
              </h3>

              <div className="text-xs text-slate-500 font-mono">
                {portal.url.replace('https://', '')}
              </div>

              <p className="text-xs text-slate-600 leading-relaxed pt-1">
                {portal.descricao}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-500 italic">
                {portal.destaque}
              </span>
              <a
                href={portal.url}
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1 shrink-0"
              >
                <span>Acessar</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Diagrama Interativo da Arquitetura: SED -> Sala do Futuro -> Escola Total */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-700" />
            <span>Como a Engrenagem Funciona na Gestão: Integração SED, Sala do Futuro e Escola Total</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Entenda por que o número que aparece no relatório nativo de um aplicativo difere do número consolidado no BI Escola Total.
          </p>
        </div>

        {/* Fluxo Visual em 3 Etapas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
          {/* Passo 1: SED */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold text-slate-700">Etapa 1: A Base Oficial</span>
              <span className="font-mono text-blue-700 font-bold">SED</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900">
              Matrículas Ativas (Semana Anterior)
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              O denominador oficial de <strong>todas</strong> as plataformas no Escola Total é extraído estritamente do censo de estudantes enturmados e ativos na Secretaria Escolar Digital (SED) no corte de <strong>D-1 semana</strong>.
            </p>
            <div className="text-[11px] text-blue-800 bg-blue-100/60 p-2 rounded border border-blue-200">
              Evita distorções por alunos transferidos ou remanejados durante a semana corrente.
            </div>
          </div>

          {/* Passo 2: Sala do Futuro */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold text-slate-700">Etapa 2: Hub Operacional</span>
              <span className="font-mono text-indigo-700 font-bold">Sala do Futuro</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900">
              Acesso Único & Login Integrado ao RA
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Substituiu a fragmentação antiga do CMSP. Professores e estudantes acessam todos os cards via login único da SED. Gestores contam com o recurso <strong>Visão Estudante</strong> para auditar as tarefas atribuídas.
            </p>
            <div className="text-[11px] text-indigo-800 bg-indigo-100/60 p-2 rounded border border-indigo-200">
              Registra acessos, minutos de tela e tarefas entregues em tempo real.
            </div>
          </div>

          {/* Passo 3: Escola Total / Super BI */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold text-slate-700">Etapa 3: Ponderação</span>
              <span className="font-mono text-amber-700 font-bold">Super BI</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900">
              Faróis, Pesos & Nota Global
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              O sistema cruza o numerador (atividades realizadas/minutos) com o denominador (matrículas SED) e acende os faróis verde, amarelo ou vermelho conforme as linhas de corte publicadas no Portal de Tutoriais.
            </p>
            <div className="text-[11px] text-amber-800 bg-amber-100/60 p-2 rounded border border-amber-200">
              Alimenta a nota global da escola e os relatórios da Diretoria de Ensino (URE).
            </div>
          </div>
        </div>

        {/* Alerta de Transparência sobre discrepância de números */}
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
          <div className="font-bold flex items-center gap-1.5 text-amber-950">
            <HelpCircle className="w-4 h-4 text-amber-600" />
            <span>Por que o relatório interno do aplicativo difere do Escola Total?</span>
          </div>
          <p className="leading-relaxed">
            Muitas ferramentas (como o painel interno do SPeak ou da Alura) calculam percentuais sobre o total de contas criadas desde o início do ano. Já o <strong>BI Escola Total</strong> cruza estritamente com as <strong>matrículas ativas enturmadas na SED na Semana Anterior</strong>. Portanto, o indicador oficial e auditável para a SEDUC é sempre o publicado no Escola Total.
          </p>
        </div>
      </div>

      {/* Simulador Interativo das Regras Semestrais do Super BI */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <Calculator className="w-4 h-4 text-blue-700" />
              <span>Simulador de Regras Técnicas do Super BI</span>
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Regra de Transição: 1º Semestre vs. 2º Semestre
            </h3>
          </div>

          {/* Comutador de Semestre */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setSelectedSemester('1')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                selectedSemester === '1' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              1º Semestre (Cesta de Plataformas - 0,75 pt)
            </button>
            <button
              onClick={() => setSelectedSemester('2')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                selectedSemester === '2' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              2º Semestre (Tarefa SP Isolada - 1,0 pt)
            </button>
          </div>
        </div>

        {/* Descrição da Regra Ativa */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed">
          {selectedSemester === '1' ? (
            <div>
              <strong className="text-slate-900 block mb-1">Regra do 1º Semestre:</strong>
              {SUPER_BI_ENGINE_RULES.regra1Semestre.descricao}
              <div className="mt-2 text-[11px] text-slate-600 flex flex-wrap gap-3 font-mono">
                <span>Matific/Khan: Peso 2,86</span>
                <span>·</span>
                <span>Redação Paulista: Peso 2,14</span>
                <span>·</span>
                <span>Leia SP: Peso 2,14</span>
                <span>·</span>
                <span>Alura: Peso 1,43</span>
              </div>
            </div>
          ) : (
            <div>
              <strong className="text-slate-900 block mb-1">Regra do 2º Semestre:</strong>
              {SUPER_BI_ENGINE_RULES.regra2Semestre.descricao}
            </div>
          )}
        </div>

        {/* Controles do Simulador */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
          {/* Sliders de Entrada */}
          <div className="lg:col-span-2 space-y-4">
            {selectedSemester === '2' ? (
              /* Modo 2º Semestre: Tarefa SP */
              <div className="border border-slate-200 rounded-lg p-4 bg-white space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900">Tarefa SP (Taxa de Entrega Semanal):</span>
                  <span className="font-mono font-bold text-amber-700 text-sm">{simTarefaSp}% (Meta: 80%)</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={simTarefaSp}
                  onChange={(e) => setSimTarefaSp(parseInt(e.target.value))}
                  className="w-full accent-amber-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>0%</span>
                  <span>Farol Verde: 80%</span>
                  <span>100%</span>
                </div>
              </div>
            ) : (
              /* Modo 1º Semestre: Cesta de Plataformas */
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Redação Paulista */}
                <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-800">Redação Paulista:</span>
                    <span className="font-mono font-bold text-blue-700">{simRedacao} red/aluno</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1.5"
                    step="0.05"
                    value={simRedacao}
                    onChange={(e) => setSimRedacao(parseFloat(e.target.value))}
                    className="w-full accent-blue-600"
                  />
                  <div className="text-[10px] text-slate-400 flex justify-between">
                    <span>Meta: 0,80 redação</span>
                    <span>Peso: 2,14</span>
                  </div>
                </div>

                {/* Leia SP */}
                <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-800">Leia SP:</span>
                    <span className="font-mono font-bold text-blue-700">{simLeiaSp} min/aluno</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="60"
                    step="1"
                    value={simLeiaSp}
                    onChange={(e) => setSimLeiaSp(parseInt(e.target.value))}
                    className="w-full accent-blue-600"
                  />
                  <div className="text-[10px] text-slate-400 flex justify-between">
                    <span>Meta: 25 min</span>
                    <span>Peso: 2,14</span>
                  </div>
                </div>

                {/* Matific */}
                <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-800">Matific (Anos Finais):</span>
                    <span className="font-mono font-bold text-orange-700">{simMatific} ativ/quinzena</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="8"
                    step="0.5"
                    value={simMatific}
                    onChange={(e) => setSimMatific(parseFloat(e.target.value))}
                    className="w-full accent-orange-600"
                  />
                  <div className="text-[10px] text-slate-400 flex justify-between">
                    <span>Meta: 4,0 ativ</span>
                    <span>Peso: 2,86</span>
                  </div>
                </div>

                {/* Start by Alura */}
                <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-800">Start by Alura:</span>
                    <span className="font-mono font-bold text-purple-700">Média {simAlura} pts</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    step="0.5"
                    value={simAlura}
                    onChange={(e) => setSimAlura(parseFloat(e.target.value))}
                    className="w-full accent-purple-600"
                  />
                  <div className="text-[10px] text-slate-400 flex justify-between">
                    <span>Meta: 6,0 pts</span>
                    <span>Peso: 1,43</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Resultado do Impacto no Super BI */}
          <div className="bg-slate-900 text-white rounded-xl p-5 flex flex-col justify-between">
            <div className="space-y-2">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
                Pontuação Calculada no Super BI
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-4xl font-extrabold font-mono text-emerald-400 tabular-nums">
                  +{currentSimScore}
                </span>
                <span className="text-sm text-slate-400">
                  / {selectedSemester === '1' ? '0,75 ponto máx.' : '1,00 ponto máx.'}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed pt-1">
                {selectedSemester === '1'
                  ? 'Representa o ganho consolidado da cesta de ferramentas digitais ponderadas.'
                  : 'No 2º semestre, a Tarefa SP garante até 1,0 ponto cheio isolado na nota global principal.'}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400">
              Base oficial: <em>tutorialescolatotal.educacao.sp.gov.br</em>
            </div>
          </div>
        </div>
      </div>

      {/* Raio-X Oficial e Filtro por Ciclo de Ensino */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Raio-X das Plataformas: Regras Oficiais, Faróis e Ciclos Exigidos
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Filtre por ciclo para verificar exatamente o que cada segmento escolar precisa cumprir.
            </p>
          </div>

          {/* Ciclo Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setSelectedCiclo('todos')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedCiclo === 'todos' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Todas
            </button>
            <button
              onClick={() => setSelectedCiclo('iniciais')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedCiclo === 'iniciais' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Anos Iniciais (1º-5º)
            </button>
            <button
              onClick={() => setSelectedCiclo('finais')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedCiclo === 'finais' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Anos Finais (6º-9º)
            </button>
            <button
              onClick={() => setSelectedCiclo('em')}
              className={`px-3 py-1 rounded-md transition-colors ${
                selectedCiclo === 'em' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Ensino Médio
            </button>
          </div>
        </div>

        {/* Tabela Oficial Fidedigna */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-200 divide-y divide-slate-200 rounded-lg overflow-hidden">
            <thead className="bg-slate-50 text-slate-700 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="p-3">Plataforma</th>
                <th className="p-3">Foco Pedagógico</th>
                <th className="p-3">Público-Alvo</th>
                <th className="p-3">Métrica / Regra Oficial no BI</th>
                <th className="p-3">Farol Verde</th>
                <th className="p-3 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {getCyclePlatforms().map((p) => {
                const record = platformRecords[p.id];
                const isLoaded = !!record;

                return (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-bold text-slate-900 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span 
                          className="w-2.5 h-2.5 rounded-full shrink-0" 
                          style={{ backgroundColor: p.accentColor }} 
                        />
                        <span>{p.name}</span>
                      </div>
                    </td>
                    <td className="p-3 text-slate-600 max-w-xs">
                      {p.focoPedagogico || p.description}
                    </td>
                    <td className="p-3 font-medium text-slate-800 whitespace-nowrap">
                      {p.publicoAlvo || p.applicableGrades}
                    </td>
                    <td className="p-3 text-slate-600 max-w-sm">
                      {p.regraCalculoBI || `${p.targetMetricName} (Meta: ${p.seducTarget}${p.targetMetricUnit})`}
                    </td>
                    <td className="p-3 font-semibold text-emerald-700 whitespace-nowrap">
                      {p.farolVerdeCriterio || `≥ ${p.seducTarget}${p.targetMetricUnit}`}
                    </td>
                    <td className="p-3 text-right whitespace-nowrap">
                      <button
                        onClick={() => onSelectPlatform(p.id)}
                        className="text-blue-700 hover:text-blue-800 font-semibold text-xs"
                      >
                        {isLoaded ? 'Ver Dados' : 'Subir Excel'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
