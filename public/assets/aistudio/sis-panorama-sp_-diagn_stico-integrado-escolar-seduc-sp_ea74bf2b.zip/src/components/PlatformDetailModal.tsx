import React from 'react';
import { PlatformConfig, PlatformDataRecord } from '../types';
import { 
  X, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  FileSpreadsheet, 
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';

interface PlatformDetailModalProps {
  platform: PlatformConfig | null;
  record?: PlatformDataRecord;
  onClose: () => void;
  onOpenUpload: (platformId: string) => void;
}

export const PlatformDetailModal: React.FC<PlatformDetailModalProps> = ({
  platform,
  record,
  onClose,
  onOpenUpload
}) => {
  if (!platform) return null;

  const isLoaded = !!record;
  const isAbove = record && record.currentValue >= platform.seducTarget;
  const isCritical = record && record.currentValue < platform.criticalThreshold;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full p-6 space-y-5 animate-in fade-in duration-150">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-lg flex items-center justify-center p-2 font-black border text-center"
              style={{ backgroundColor: platform.lightBg, borderColor: `${platform.accentColor}40`, color: platform.accentColor }}
            >
              <span className="text-xs">{platform.code}</span>
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>{platform.categoryLabel}</span>
                <span aria-hidden="true">·</span>
                <span>Público: {platform.applicableGrades}</span>
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                {platform.name}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Description */}
        <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
          {platform.description}
        </p>

        {/* Performance Metric & Targets */}
        <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-xs text-slate-500 block uppercase font-medium">
                {platform.targetMetricName}
              </span>
              <div className="text-2xl font-black font-mono text-slate-900 tabular-nums">
                {isLoaded ? `${record.currentValue}${platform.targetMetricUnit}` : 'Não Carregado'}
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-500 block">Meta / Farol Verde:</span>
              <span className="text-sm font-bold text-emerald-700 font-mono">
                {platform.farolVerdeCriterio || `≥ ${platform.seducTarget}${platform.targetMetricUnit}`}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          {isLoaded && (
            <div className="space-y-1">
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${isAbove ? 'bg-emerald-500' : (isCritical ? 'bg-rose-500' : 'bg-amber-500')}`}
                  style={{ width: `${Math.min(100, (record.currentValue / platform.seducTarget) * 100)}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>Limiar de Alerta: {platform.criticalThreshold}{platform.targetMetricUnit}</span>
                <span className={`font-semibold ${isAbove ? 'text-emerald-700' : (isCritical ? 'text-rose-700' : 'text-amber-700')}`}>
                  {isAbove ? 'Farol Verde (Meta Superada)' : (isCritical ? 'Farol Vermelho (Crítico)' : 'Farol Amarelo (Atenção)')}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Ficha Técnica Oficial Escola Total / Super BI */}
        <div className="border border-blue-100 bg-blue-50/50 rounded-xl p-4 space-y-2 text-xs">
          <div className="font-bold text-blue-950 flex items-center gap-1.5">
            <Info className="w-4 h-4 text-blue-700 shrink-0" />
            <span>Ficha Técnica Oficial (Escola Total / Super BI)</span>
          </div>

          {platform.focoPedagogico && (
            <div>
              <strong className="text-slate-800">Foco Pedagógico:</strong>{' '}
              <span className="text-slate-600">{platform.focoPedagogico}</span>
            </div>
          )}

          {platform.regraCalculoBI && (
            <div>
              <strong className="text-slate-800">Regra de Acompanhamento no BI:</strong>{' '}
              <span className="text-slate-600">{platform.regraCalculoBI}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-blue-200/60 text-[11px]">
            <div>
              <strong className="text-slate-800 block">Denominador Oficial:</strong>
              <span className="text-slate-600">
                {platform.denominadorDescricao || 'Matrículas ativas enturmadas na SED na Semana Anterior'}
              </span>
            </div>
            <div>
              <strong className="text-slate-800 block">Hub de Acesso:</strong>
              <span className="text-slate-600">
                {platform.portalOficial || 'Sala do Futuro (login único da SED)'}
              </span>
            </div>
          </div>
        </div>

        {/* File and Ingestion Status */}
        {isLoaded ? (
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Arquivo: <strong>{record.fileName}</strong></span>
              </div>
              <span>Sincronizado em: {record.uploadedAt}</span>
            </div>

            {/* Insights */}
            {record.keyInsights && record.keyInsights.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <span className="font-semibold text-slate-800 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  Evidências & Diagnósticos Registrados:
                </span>
                <ul className="space-y-1 text-slate-600 pl-4 list-disc">
                  {record.keyInsights.map((ins, i) => (
                    <li key={i}>{ins}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Critical Alerts */}
            {record.criticalAlerts && record.criticalAlerts.length > 0 && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  Pontos de Atenção para a Coordenação Pedagógica:
                </span>
                <ul className="pl-4 list-disc space-y-0.5">
                  {record.criticalAlerts.map((al, i) => (
                    <li key={i}>{al}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-4 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-xs text-slate-500">
            Nenhuma planilha enviada para este módulo ainda.
            <div className="mt-1 text-[11px] text-slate-400">
              Colunas esperadas no Excel exportado: <strong>{platform.sampleColumns.join(', ')}</strong>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Fechar
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenUpload(platform.id);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Subir Novo Arquivo para {platform.code}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
