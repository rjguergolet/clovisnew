import React from 'react';
import { DiagnosticPanorama, PlatformDataRecord } from '../types';
import { PLATFORMS_CATALOG } from '../data/platformsCatalog';
import { Printer, Download, ArrowLeft } from 'lucide-react';

interface PrintReportViewProps {
  panorama: DiagnosticPanorama;
  platformRecords: Record<string, PlatformDataRecord>;
  onBackToPanorama: () => void;
}

export const PrintReportView: React.FC<PrintReportViewProps> = ({
  panorama,
  platformRecords,
  onBackToPanorama
}) => {
  const { schoolProfile, scoreGeralEscola, classificacaoEscola, eixosScores, planoAcaoMMR, turmasRanking } = panorama;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Non-print toolbar */}
      <div className="no-print bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
        <button
          onClick={onBackToPanorama}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-blue-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Panorama Interativo</span>
        </button>

        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-500 hidden sm:inline">
            Dica: No diálogo de impressão, escolha "Salvar como PDF" com layout A4.
          </span>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir / Salvar PDF</span>
          </button>
        </div>
      </div>

      {/* Official Document Container (Printable) */}
      <div className="bg-white border border-slate-200 rounded-xl p-8 sm:p-12 shadow-sm max-w-4xl mx-auto space-y-8 text-slate-900 print:border-none print:shadow-none print:p-0">
        {/* Institutional Header */}
        <div className="border-b-2 border-slate-900 pb-4 text-center space-y-1">
          <div className="text-xs uppercase tracking-widest text-slate-600 font-semibold">
            Governo do Estado de São Paulo · Secretaria da Educação (SEDUC-SP)
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-950 uppercase">
            Dossiê de Diagnóstico Integrado Escolar & Panorama 360°
          </h1>
          <div className="text-xs text-slate-600 font-medium">
            Sistema Integrado de Acompanhamento das 41 Plataformas & Método MMR · Ano Letivo {schoolProfile.anoLetivo}
          </div>
        </div>

        {/* School Metadata Identification Box */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs bg-slate-50 p-4 rounded-lg border border-slate-200">
          <div>
            <span className="text-slate-500 block">Unidade Escolar:</span>
            <span className="font-bold text-slate-900 block">{schoolProfile.nome}</span>
          </div>
          <div>
            <span className="text-slate-500 block">CIE / Diretoria:</span>
            <span className="font-bold text-slate-900 block">{schoolProfile.codCIE} · {schoolProfile.diretoriaEnsino}</span>
          </div>
          <div>
            <span className="text-slate-500 block">Modelo de Ensino:</span>
            <span className="font-bold text-slate-900 block">{schoolProfile.modelo} (Tempo Integral)</span>
          </div>
          <div>
            <span className="text-slate-500 block">Data de Emissão:</span>
            <span className="font-bold text-slate-900 block">01/11/2026 · {schoolProfile.bimestreReferencia}</span>
          </div>
        </div>

        {/* Section 1: Executive Score */}
        <div className="space-y-3">
          <h2 className="text-sm font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1">
            1. Resumo Executivo & Índice Geral de Desempenho (IIDE)
          </h2>
          <div className="flex items-center justify-between bg-slate-100 p-4 rounded-lg">
            <div>
              <span className="text-xs text-slate-600 uppercase font-medium">Score Consolidado da Escola:</span>
              <div className="text-3xl font-black font-mono text-slate-950 tabular-nums">
                {scoreGeralEscola} / 100 pts
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-600 block">Enquadramento Pedagógico:</span>
              <span className="text-sm font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded inline-block mt-0.5">
                {classificacaoEscola}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs pt-2">
            <div className="p-2 border border-slate-200 rounded">
              <span className="text-slate-500 block text-[10px]">Avaliações</span>
              <span className="font-bold font-mono">{eixosScores.avaliacoes}%</span>
            </div>
            <div className="p-2 border border-slate-200 rounded">
              <span className="text-slate-500 block text-[10px]">Plataformas</span>
              <span className="font-bold font-mono">{eixosScores.plataformasDigitais}%</span>
            </div>
            <div className="p-2 border border-slate-200 rounded">
              <span className="text-slate-500 block text-[10px]">Frequência</span>
              <span className="font-bold font-mono">{eixosScores.frequencia}%</span>
            </div>
            <div className="p-2 border border-slate-200 rounded">
              <span className="text-slate-500 block text-[10px]">Gestão Docente</span>
              <span className="font-bold font-mono">{eixosScores.gestaoDocente}%</span>
            </div>
            <div className="p-2 border border-slate-200 rounded">
              <span className="text-slate-500 block text-[10px]">Modelo PEI</span>
              <span className="font-bold font-mono">{eixosScores.modeloPeiFuturo}%</span>
            </div>
            <div className="p-2 border border-slate-200 rounded">
              <span className="text-slate-500 block text-[10px]">Infraestrutura</span>
              <span className="font-bold font-mono">{eixosScores.infraestrutura}%</span>
            </div>
          </div>
        </div>

        {/* Section 2: Turmas Benchmark */}
        <div className="space-y-3 break-inside-avoid">
          <h2 className="text-sm font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1">
            2. Desempenho Comparativo por Turma
          </h2>
          <table className="w-full text-left text-xs border border-slate-200 divide-y divide-slate-200">
            <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
              <tr>
                <th className="p-2">Turma</th>
                <th className="p-2 text-right">Alunos</th>
                <th className="p-2 text-right">Aluno Presente</th>
                <th className="p-2 text-right">Tarefa SP</th>
                <th className="p-2 text-right">Redação SP</th>
                <th className="p-2 text-right">Prova Paulista</th>
                <th className="p-2 text-center">Situação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {turmasRanking.map(t => (
                <tr key={t.turma}>
                  <td className="p-2 font-semibold text-slate-900">{t.turma}</td>
                  <td className="p-2 text-right font-mono">{t.totalAlunos}</td>
                  <td className="p-2 text-right font-mono">{t.frequenciaMedia}%</td>
                  <td className="p-2 text-right font-mono">{t.tarefaSpAdesao}%</td>
                  <td className="p-2 text-right font-mono">{t.redacaoEntregas}%</td>
                  <td className="p-2 text-right font-mono font-bold">{t.provaPaulistaAcertos}%</td>
                  <td className="p-2 text-center text-[10px]">
                    {t.statusGeral === 'excelente' ? 'Consolidado' : (t.statusGeral === 'atencao' ? 'Atenção' : 'Intervenção')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Section 3: Priority Action Plan (MMR / 5W2H) */}
        <div className="space-y-3 break-inside-avoid">
          <h2 className="text-sm font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1">
            3. Plano de Ação MMR Priorizado (Método de Melhoria de Resultados)
          </h2>
          <div className="space-y-3 text-xs">
            {planoAcaoMMR.map((item, idx) => (
              <div key={item.id} className="border border-slate-200 p-3 rounded-lg bg-slate-50/50">
                <div className="flex items-center justify-between font-bold text-slate-900 mb-1">
                  <span>{idx + 1}. [{item.origem}] {item.problema}</span>
                  <span className="uppercase text-[10px] text-slate-600">Prazo: {item.prazo}</span>
                </div>
                <div className="text-slate-600 text-xs mb-1">
                  <strong>Ação (5W2H):</strong> {item.acaoProposta}
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between">
                  <span>Responsável: <strong>{item.responsavel}</strong></span>
                  <span>Meta: <strong>{item.indicadorMeta}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Signatures Footer */}
        <div className="pt-12 border-t border-slate-200 grid grid-cols-3 gap-8 text-center text-xs break-inside-avoid">
          <div className="space-y-1">
            <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">
              Prof. Rodrigo José Guergolet
            </div>
            <div className="text-slate-500 text-[10px]">Diretor de Escola · EE Prof. Clovis de Lucca</div>
          </div>

          <div className="space-y-1">
            <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">
              Coordenador Geral (CGPG)
            </div>
            <div className="text-slate-500 text-[10px]">Coordenação de Gestão Pedagógica Geral</div>
          </div>

          <div className="space-y-1">
            <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">
              Supervisor(a) de Ensino
            </div>
            <div className="text-slate-500 text-[10px]">Diretoria de Ensino Região São Bernardo do Campo</div>
          </div>
        </div>
      </div>
    </div>
  );
};
