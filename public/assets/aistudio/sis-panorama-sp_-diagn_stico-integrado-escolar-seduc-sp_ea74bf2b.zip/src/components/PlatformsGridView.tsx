import React, { useState } from 'react';
import { PlatformConfig, PlatformDataRecord } from '../types';
import { PLATFORMS_CATALOG, CATEGORY_LABELS } from '../data/platformsCatalog';
import { 
  Search, 
  Upload, 
  CheckCircle, 
  Clock, 
  FileSpreadsheet, 
  ExternalLink,
  ChevronRight,
  Filter
} from 'lucide-react';

interface PlatformsGridViewProps {
  platformRecords: Record<string, PlatformDataRecord>;
  onSelectPlatform: (platformId: string) => void;
  onUploadForPlatform: (platformId: string) => void;
}

export const PlatformsGridView: React.FC<PlatformsGridViewProps> = ({
  platformRecords,
  onSelectPlatform,
  onUploadForPlatform
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredPlatforms = PLATFORMS_CATALOG.filter(platform => {
    const matchesCategory = selectedCategory === 'all' || platform.category === selectedCategory;
    const matchesSearch = 
      platform.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      platform.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      platform.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      platform.categoryLabel.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header and Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Painel de Plataformas & Ingestão de Dados (41 Módulos SEDUC-SP)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Faça o upload dos relatórios em Excel (.xlsx), CSV ou PDF de cada plataforma para atualizar o diagnóstico em tempo real.
            </p>
          </div>

          <div className="relative w-full md:w-72 shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Buscar por plataforma ou código..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all text-slate-900"
            />
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Todas as Plataformas (41)
          </button>

          {Object.entries(CATEGORY_LABELS).map(([catKey, catInfo]) => {
            const count = PLATFORMS_CATALOG.filter(p => p.category === catKey).length;
            return (
              <button
                key={catKey}
                onClick={() => setSelectedCategory(catKey)}
                className={`px-3 py-1.5 font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedCategory === catKey
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {catInfo} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of 41 Platforms Matching the Image Layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {filteredPlatforms.map((platform) => {
          const record = platformRecords[platform.id];
          const isLoaded = !!record;
          const isAboveTarget = record && record.currentValue >= platform.seducTarget;
          const isCritical = record && record.currentValue < platform.criticalThreshold;

          return (
            <div
              key={platform.id}
              className="group bg-white rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all flex flex-col justify-between overflow-hidden relative"
            >
              {/* Card Header with Platform Visual Identity */}
              <div 
                onClick={() => onSelectPlatform(platform.id)}
                className="p-4 cursor-pointer flex-1"
              >
                {/* Category & Status Line */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                  <span className="truncate max-w-[130px]">{platform.categoryLabel}</span>
                  {isLoaded ? (
                    <span className="flex items-center gap-1 text-emerald-600 font-medium">
                      <CheckCircle className="w-3 h-3 shrink-0" />
                      <span>Sincronizado</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-slate-400">
                      <Clock className="w-3 h-3 shrink-0" />
                      <span>Pendente</span>
                    </span>
                  )}
                </div>

                {/* Iconic Platform Visual Tile */}
                <div 
                  className="w-full h-16 rounded-lg flex items-center justify-center p-2 mb-3 border text-center transition-transform group-hover:scale-[1.02]"
                  style={{ 
                    backgroundColor: platform.lightBg,
                    borderColor: `${platform.accentColor}30`
                  }}
                >
                  <div className="flex flex-col items-center">
                    <span 
                      className="text-sm font-black tracking-tight leading-tight line-clamp-1"
                      style={{ color: platform.accentColor }}
                    >
                      {platform.name}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">
                      {platform.code}
                    </span>
                  </div>
                </div>

                {/* Metric Summary */}
                {isLoaded ? (
                  <div className="space-y-1">
                    <div className="flex items-baseline justify-between">
                      <span className="text-xs text-slate-500 truncate">{platform.targetMetricName}:</span>
                      <span className="text-sm font-bold font-mono text-slate-900 tabular-nums">
                        {record.currentValue}{platform.targetMetricUnit}
                      </span>
                    </div>

                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${
                          isAboveTarget ? 'bg-emerald-500' : (isCritical ? 'bg-rose-500' : 'bg-amber-500')
                        }`}
                        style={{ width: `${Math.min(100, (record.currentValue / platform.seducTarget) * 100)}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                      <span className="truncate max-w-[120px]">Farol Verde: {platform.farolVerdeCriterio || `≥ ${platform.seducTarget}${platform.targetMetricUnit}`}</span>
                      <span className={`font-semibold shrink-0 ${
                        isAboveTarget ? 'text-emerald-700' : (isCritical ? 'text-rose-700' : 'text-amber-700')
                      }`}>
                        {isAboveTarget ? 'Verde' : (isCritical ? 'Vermelho' : 'Amarelo')}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="py-1 text-xs text-slate-500 space-y-0.5">
                    <div className="font-semibold text-slate-700 truncate">{platform.targetMetricName}</div>
                    <div className="text-[10px] text-slate-400">Farol: {platform.farolVerdeCriterio || `≥ ${platform.seducTarget}${platform.targetMetricUnit}`}</div>
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="px-3 py-2 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  onClick={() => onSelectPlatform(platform.id)}
                  className="text-slate-600 hover:text-blue-700 font-medium flex items-center gap-1 transition-colors"
                >
                  <span>Detalhes</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onUploadForPlatform(platform.id)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-blue-700 hover:text-white hover:bg-blue-700 rounded transition-colors"
                >
                  <Upload className="w-3 h-3" />
                  <span>Subir Excel</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
