import React, { useState, useRef } from 'react';
import { HistoricalSnapshot, DiagnosticPanorama, PlatformDataRecord, TurmaPerformance, ActionPlanItem, SchoolProfile } from '../types';
import { StorageService } from '../services/storageService';
import { 
  History, 
  Save, 
  Download, 
  Upload, 
  Trash2, 
  Calendar, 
  TrendingUp, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ArrowRight,
  ShieldCheck,
  FileJson,
  Layers,
  Sparkles
} from 'lucide-react';

interface HistoryTimelineViewProps {
  currentPanorama: DiagnosticPanorama;
  currentRecords: Record<string, PlatformDataRecord>;
  currentTurmas: TurmaPerformance[];
  currentActionPlan: ActionPlanItem[];
  currentProfile: SchoolProfile;
  snapshots: HistoricalSnapshot[];
  onSnapshotsUpdated: (snapshots: HistoricalSnapshot[]) => void;
  onRestoreSnapshot: (snapshot: HistoricalSnapshot) => void;
  onFullDataImported: (data: {
    profile: SchoolProfile;
    records: Record<string, PlatformDataRecord>;
    turmas: TurmaPerformance[];
    actionPlan: ActionPlanItem[];
    snapshots: HistoricalSnapshot[];
  }) => void;
  onClearAllData: () => void;
}

export const HistoryTimelineView: React.FC<HistoryTimelineViewProps> = ({
  currentPanorama,
  currentRecords,
  currentTurmas,
  currentActionPlan,
  currentProfile,
  snapshots,
  onSnapshotsUpdated,
  onRestoreSnapshot,
  onFullDataImported,
  onClearAllData
}) => {
  const [snapshotTitle, setSnapshotTitle] = useState(
    `${currentProfile.bimestreReferencia || '1º Bimestre'} / ${currentProfile.anoLetivo || 2026}`
  );
  const [snapshotPeriodo, setSnapshotPeriodo] = useState<string>(currentProfile.bimestreReferencia || '1º Bimestre');
  const [snapshotObs, setSnapshotObs] = useState('');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [comparingSnapshots, setComparingSnapshots] = useState<{ a: HistoricalSnapshot; b: HistoricalSnapshot } | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSaveCurrentSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    const newSnapshot: HistoricalSnapshot = {
      id: `snap_${Date.now()}`,
      title: snapshotTitle,
      periodo: snapshotPeriodo,
      savedAt: new Date().toLocaleString('pt-BR'),
      scoreGeral: currentPanorama.scoreGeralEscola,
      classificacao: currentPanorama.classificacaoEscola,
      platformRecords: { ...currentRecords },
      turmas: [...currentTurmas],
      actionPlan: [...currentActionPlan],
      schoolProfile: { ...currentProfile },
      observacoes: snapshotObs
    };

    const updated = StorageService.saveSnapshot(newSnapshot);
    onSnapshotsUpdated(updated);
    setSnapshotObs('');
    setSuccessMsg(`Snapshot histórico "${snapshotTitle}" gravado com sucesso!`);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const handleDeleteSnapshot = (id: string) => {
    if (confirm('Deseja realmente excluir este snapshot do histórico?')) {
      const updated = StorageService.deleteSnapshot(id);
      onSnapshotsUpdated(updated);
    }
  };

  const handleExportBackup = () => {
    StorageService.exportBackupFile();
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      try {
        const result = await StorageService.importBackupFile(e.target.files[0]);
        onFullDataImported(result);
        setSuccessMsg('Backup importado com sucesso! Todos os dados e o histórico foram restaurados.');
        setTimeout(() => setSuccessMsg(null), 4000);
      } catch (err: any) {
        alert('Erro ao importar backup: arquivo JSON inválido.');
      }
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Banner de Explicação: Como funciona a gravação sem banco de dados */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs text-blue-700 font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Armazenamento Local Seguro & Histórico Permanente (Zero Banco de Dados)</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Histórico & Linha do Tempo da Escola
            </h2>
            <p className="text-xs text-slate-600 max-w-3xl leading-relaxed">
              <strong>Sim, é 100% possível gravar e acompanhar o histórico sem precisar de banco de dados ou servidor!</strong>{' '}
              O sistema utiliza a tecnologia de armazenamento seguro do próprio navegador (Local Storage). Além disso, você pode criar 
              <strong> Snapshots Bimestrais</strong> para comparar o avanço das turmas ao longo dos bimestres e <strong>baixar um arquivo de backup (.json)</strong>{' '}
              para guardar no seu computador ou abrir em qualquer outro equipamento da escola.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleImportBackup}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            >
              <Upload className="w-3.5 h-3.5 text-slate-600" />
              <span>Restaurar Backup (.json)</span>
            </button>

            <button
              onClick={handleExportBackup}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Backup Completo</span>
            </button>
          </div>
        </div>

        {successMsg && (
          <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}
      </div>

      {/* Seção 1: Gravar Snapshot do Período Atual */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <h3 className="text-base font-bold text-slate-900 mb-1 flex items-center gap-2">
          <Save className="w-4 h-4 text-blue-700" />
          <span>Gravar Estado Atual como Ponto na Linha do Tempo</span>
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Congele e salve o panorama com todas as planilhas e indicadores deste momento para comparar com os próximos bimestres.
        </p>

        <form onSubmit={handleSaveCurrentSnapshot} className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Título do Snapshot:
            </label>
            <input
              type="text"
              value={snapshotTitle}
              onChange={(e) => setSnapshotTitle(e.target.value)}
              placeholder="Ex: 1º Bimestre 2026 - Pós Prova Paulista"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Período de Referência:
            </label>
            <select
              value={snapshotPeriodo}
              onChange={(e) => setSnapshotPeriodo(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
            >
              <option value="1º Bimestre">1º Bimestre</option>
              <option value="2º Bimestre">2º Bimestre</option>
              <option value="3º Bimestre">3º Bimestre</option>
              <option value="4º Bimestre">4º Bimestre</option>
              <option value="Consolidado 1º Semestre">Consolidado 1º Semestre</option>
              <option value="Consolidado Anual">Consolidado Anual</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Observações / Contexto:
            </label>
            <input
              type="text"
              value={snapshotObs}
              onChange={(e) => setSnapshotObs(e.target.value)}
              placeholder="Ex: Dados apresentados no Conselho de Escola e ATPC Geral"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
            />
          </div>

          <div className="md:col-span-3 flex items-center justify-between pt-2">
            <span className="text-[11px] text-slate-500">
              Score atual a ser gravado: <strong>{currentPanorama.scoreGeralEscola} pts</strong> ({currentPanorama.classificacaoEscola}) · {Object.keys(currentRecords).length} plataformas sincronizadas.
            </span>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Salvar Ponto Histórico</span>
            </button>
          </div>
        </form>
      </div>

      {/* Seção 2: Linha do Tempo de Snapshots Gravados */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <History className="w-4 h-4 text-slate-700" />
              <span>Linha do Tempo de Avaliações Salvas ({snapshots.length})</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Histórico salvo localmente no seu computador. Clique para visualizar ou restaurar como diagnóstico ativo.
            </p>
          </div>

          {snapshots.length > 0 && (
            <button
              onClick={onClearAllData}
              className="text-xs text-rose-600 hover:text-rose-700 hover:underline flex items-center gap-1 font-medium"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar Todos os Dados</span>
            </button>
          )}
        </div>

        {snapshots.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
            <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-700">Nenhum ponto histórico gravado ainda.</p>
            <p className="mt-1">Suba os dados deste bimestre e clique no botão acima para registrar o primeiro marco da linha do tempo.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {snapshots.map((snap, idx) => {
              const platformCount = Object.keys(snap.platformRecords).length;

              return (
                <div
                  key={snap.id}
                  className="border border-slate-200 rounded-xl p-4 hover:border-blue-400 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-bold text-blue-700">{snap.periodo}</span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        Salvo em {snap.savedAt}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900">
                      {snap.title}
                    </h4>

                    {snap.observacoes && (
                      <p className="text-xs text-slate-500 italic">
                        "{snap.observacoes}"
                      </p>
                    )}

                    <div className="flex items-center gap-3 text-xs text-slate-600 pt-0.5">
                      <span>Plataformas: <strong>{platformCount}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Turmas: <strong>{snap.turmas.length}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Ações MMR: <strong>{snap.actionPlan.length}</strong></span>
                    </div>
                  </div>

                  {/* Score & Actions */}
                  <div className="flex items-center gap-4 self-end sm:self-center shrink-0">
                    <div className="text-right">
                      <span className="text-xs text-slate-400 block font-medium">Score do Período</span>
                      <div className="text-xl font-black font-mono text-slate-900 tabular-nums">
                        {snap.scoreGeral} <span className="text-xs font-normal text-slate-400">/ 100</span>
                      </div>
                      <span className="text-[11px] font-semibold text-emerald-700">
                        {snap.classificacao}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 border-l border-slate-100 pl-3">
                      <button
                        onClick={() => onRestoreSnapshot(snap)}
                        title="Carregar este snapshot na tela de panorama principal"
                        className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                      >
                        Carregar
                      </button>

                      <button
                        onClick={() => handleDeleteSnapshot(snap.id)}
                        title="Excluir este snapshot"
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
