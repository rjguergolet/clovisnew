import React, { useState } from 'react';
import { SchoolProfile } from '../types';
import { X, Building2, Save } from 'lucide-react';

interface SchoolConfigModalProps {
  isOpen: boolean;
  profile: SchoolProfile;
  onClose: () => void;
  onSave: (updated: SchoolProfile) => void;
}

export const SchoolConfigModal: React.FC<SchoolConfigModalProps> = ({
  isOpen,
  profile,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState<SchoolProfile>({ ...profile });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 space-y-4 animate-in fade-in duration-150">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-700" />
            <h3 className="text-base font-bold text-slate-900">
              Configurações da Unidade Escolar
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Nome Oficial da Escola:
            </label>
            <input
              type="text"
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              placeholder="Ex: EE Professora Esther Carpinelli Pagano"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Código CIE:
              </label>
              <input
                type="text"
                value={formData.codCIE}
                onChange={(e) => setFormData({ ...formData, codCIE: e.target.value })}
                placeholder="Ex: 034.819"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Diretoria de Ensino:
              </label>
              <input
                type="text"
                value={formData.diretoriaEnsino}
                onChange={(e) => setFormData({ ...formData, diretoriaEnsino: e.target.value })}
                placeholder="Ex: Diretoria de Ensino Leste 3"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Município:
              </label>
              <input
                type="text"
                value={formData.municipio}
                onChange={(e) => setFormData({ ...formData, municipio: e.target.value })}
                placeholder="Ex: São Paulo - SP"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Modelo Pedagógico:
              </label>
              <select
                value={formData.modelo}
                onChange={(e) => setFormData({ ...formData, modelo: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
              >
                <option value="PEI_9H">PEI - Programa Ensino Integral (9 Horas)</option>
                <option value="PEI_7H">PEI - Programa Ensino Integral (7 Horas)</option>
                <option value="REGULAR">Ensino Regular</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Bimestre de Referência:
              </label>
              <select
                value={formData.bimestreReferencia}
                onChange={(e) => setFormData({ ...formData, bimestreReferencia: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
              >
                <option value="1º Bimestre">1º Bimestre</option>
                <option value="2º Bimestre">2º Bimestre</option>
                <option value="3º Bimestre">3º Bimestre</option>
                <option value="4º Bimestre">4º Bimestre</option>
                <option value="Consolidado Anual">Consolidado Anual</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Ano Letivo:
              </label>
              <input
                type="number"
                value={formData.anoLetivo}
                onChange={(e) => setFormData({ ...formData, anoLetivo: parseInt(e.target.value) || 2026 })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900 font-mono"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Salvar Dados da Escola</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
