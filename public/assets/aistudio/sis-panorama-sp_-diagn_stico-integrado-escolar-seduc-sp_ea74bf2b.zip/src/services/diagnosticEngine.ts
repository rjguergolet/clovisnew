import { DiagnosticPanorama, PlatformDataRecord, SchoolProfile, TurmaPerformance, ActionPlanItem } from '../types';
import { PLATFORMS_CATALOG } from '../data/platformsCatalog';

export function computeSchoolPanorama(
  schoolProfile: SchoolProfile,
  platformRecords: Record<string, PlatformDataRecord>,
  turmas: TurmaPerformance[],
  customActionPlan: ActionPlanItem[]
): DiagnosticPanorama {
  const allPlatforms = PLATFORMS_CATALOG;
  const totalPlatforms = allPlatforms.length;
  
  // Categorize scores
  const categoryScores: Record<string, number[]> = {
    avaliacoes: [],
    plataformas_digitais: [],
    frequencia_busca_ativa: [],
    gestao_docente: [],
    modelo_pei_futuro: [],
    infraestrutura: []
  };

  let loadedPlatformsCount = 0;
  const destaquesPositivos: string[] = [];
  const vulnerabilidadesCriticas: string[] = [];

  allPlatforms.forEach(p => {
    const record = platformRecords[p.id];
    if (record) {
      loadedPlatformsCount++;
      let normalizedScore = 0;
      if (p.targetMetricUnit === 'livros' || p.targetMetricUnit === 'episódios' || p.targetMetricUnit === 'projetos' || p.targetMetricUnit === 'obras' || p.targetMetricUnit === 'pts' || p.targetMetricUnit === 'min') {
        normalizedScore = Math.min(100, (record.currentValue / p.seducTarget) * 100);
      } else {
        normalizedScore = Math.min(100, (record.currentValue / p.seducTarget) * 100);
      }

      if (categoryScores[p.category]) {
        categoryScores[p.category].push(normalizedScore);
      }

      if (record.currentValue >= p.seducTarget * 1.02) {
        destaquesPositivos.push(`${p.name}: atingiu ${record.currentValue}${p.targetMetricUnit} (superando a meta SEDUC de ${p.seducTarget}${p.targetMetricUnit}).`);
      } else if (record.currentValue < p.criticalThreshold) {
        vulnerabilidadesCriticas.push(`${p.name}: atingiu ${record.currentValue}${p.targetMetricUnit}, abaixo do limite crítico (${p.criticalThreshold}${p.targetMetricUnit}).`);
      }
    }
  });

  // If no platforms are loaded yet, return clean zeroed state
  if (loadedPlatformsCount === 0) {
    return {
      schoolProfile,
      totalPlatforms,
      loadedPlatformsCount: 0,
      scoreGeralEscola: 0,
      classificacaoEscola: 'Aguardando Dados',
      eixosScores: {
        avaliacoes: 0,
        plataformasDigitais: 0,
        frequencia: 0,
        gestaoDocente: 0,
        modeloPeiFuturo: 0,
        infraestrutura: 0
      },
      destaquesPositivos: [],
      vulnerabilidadesCriticas: [],
      correlacoesChave: [],
      turmasRanking: turmas,
      planoAcaoMMR: customActionPlan
    };
  }

  const avg = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

  const eixosScores = {
    avaliacoes: Math.round(avg(categoryScores.avaliacoes)),
    plataformasDigitais: Math.round(avg(categoryScores.plataformas_digitais)),
    frequencia: Math.round(avg(categoryScores.frequencia_busca_ativa)),
    gestaoDocente: Math.round(avg(categoryScores.gestao_docente)),
    modeloPeiFuturo: Math.round(avg(categoryScores.modelo_pei_futuro)),
    infraestrutura: Math.round(avg(categoryScores.infraestrutura))
  };

  // Compute active weights based only on loaded axes
  let weightedSum = 0;
  let totalWeights = 0;

  if (categoryScores.avaliacoes.length > 0) {
    weightedSum += eixosScores.avaliacoes * 0.30;
    totalWeights += 0.30;
  }
  if (categoryScores.plataformas_digitais.length > 0) {
    weightedSum += eixosScores.plataformasDigitais * 0.25;
    totalWeights += 0.25;
  }
  if (categoryScores.frequencia_busca_ativa.length > 0) {
    weightedSum += eixosScores.frequencia * 0.20;
    totalWeights += 0.20;
  }
  if (categoryScores.gestao_docente.length > 0) {
    weightedSum += eixosScores.gestaoDocente * 0.10;
    totalWeights += 0.10;
  }
  if (categoryScores.modelo_pei_futuro.length > 0) {
    weightedSum += eixosScores.modeloPeiFuturo * 0.10;
    totalWeights += 0.10;
  }
  if (categoryScores.infraestrutura.length > 0) {
    weightedSum += eixosScores.infraestrutura * 0.05;
    totalWeights += 0.05;
  }

  const scoreGeralEscola = totalWeights > 0 
    ? parseFloat((weightedSum / totalWeights).toFixed(1)) 
    : 0;

  let classificacaoEscola: DiagnosticPanorama['classificacaoEscola'] = 'Consolidado';
  if (scoreGeralEscola >= 88) {
    classificacaoEscola = 'Excelência PEI';
  } else if (scoreGeralEscola >= 75) {
    classificacaoEscola = 'Consolidado';
  } else if (scoreGeralEscola >= 60) {
    classificacaoEscola = 'Em Desenvolvimento';
  } else {
    classificacaoEscola = 'Atenção Prioritária';
  }

  // Dynamic pedagogical correlations
  const correlacoesChave = [];

  const tarefaSpRec = platformRecords['tarefa_sp'];
  const provaP2Rec = platformRecords['prova_paulista_2b'] || platformRecords['prova_paulista_1b'];
  if (tarefaSpRec && provaP2Rec) {
    correlacoesChave.push({
      titulo: 'Engajamento em Tarefa SP vs Rendimento na Prova Paulista',
      descricao: `Adesão de ${tarefaSpRec.currentValue}% nas tarefas semanais refletiu em média de ${provaP2Rec.currentValue}% de acertos nas avaliações bimestrais.`,
      grau: (tarefaSpRec.currentValue >= 80 ? 'forte' : 'moderada') as 'forte' | 'moderada',
      impacto: 'Impacto direto no IDESP da unidade escolar'
    });
  }

  const freqRec = platformRecords['aluno_presente'];
  if (freqRec) {
    correlacoesChave.push({
      titulo: 'Aluno Presente & Monitoramento de Evasão',
      descricao: `Frequência média da unidade em ${freqRec.currentValue}%. Estudantes com presença abaixo de 80% necessitam de acolhimento prioritário pela Busca Ativa.`,
      grau: (freqRec.currentValue < 85 ? 'forte' : 'moderada') as 'forte' | 'moderada',
      impacto: 'Foco prioritário para equipe de tutoria e gestão'
    });
  }

  const redacaoRec = platformRecords['redacao_paulista'];
  if (redacaoRec) {
    correlacoesChave.push({
      titulo: 'Redação Paulista & Competências Textuais',
      descricao: `${redacaoRec.currentValue}% de entregas de redações computadas com auxílio de inteligência artificial e devolutiva pedagógica.`,
      grau: 'forte' as 'forte',
      impacto: 'Alavanca proficiência leitora e escritora'
    });
  }

  return {
    schoolProfile,
    totalPlatforms,
    loadedPlatformsCount,
    scoreGeralEscola,
    classificacaoEscola,
    eixosScores,
    destaquesPositivos: destaquesPositivos.slice(0, 6),
    vulnerabilidadesCriticas: vulnerabilidadesCriticas.slice(0, 6),
    correlacoesChave,
    turmasRanking: turmas,
    planoAcaoMMR: customActionPlan
  };
}
