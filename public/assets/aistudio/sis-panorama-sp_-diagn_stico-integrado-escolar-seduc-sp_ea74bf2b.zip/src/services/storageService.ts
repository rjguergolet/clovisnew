import { 
  SchoolProfile, 
  PlatformDataRecord, 
  TurmaPerformance, 
  ActionPlanItem, 
  HistoricalSnapshot 
} from '../types';
import { 
  CLOVIS_DE_LUCCA_PROFILE, 
  CLOVIS_DE_LUCCA_TURMAS, 
  getClovisDeLuccaRealRecords, 
  CLOVIS_DE_LUCCA_MMR_ACTIONS 
} from '../data/clovisDeLuccaRealData';

const STORAGE_KEYS = {
  PROFILE: 'SEDUC_CLOVIS_PROFILE_V2',
  RECORDS: 'SEDUC_CLOVIS_RECORDS_V2',
  TURMAS: 'SEDUC_CLOVIS_TURMAS_V2',
  ACTION_PLAN: 'SEDUC_CLOVIS_ACTION_PLAN_V2',
  SNAPSHOTS: 'SEDUC_CLOVIS_SNAPSHOTS_V2'
};

export const DEFAULT_SCHOOL_PROFILE: SchoolProfile = CLOVIS_DE_LUCCA_PROFILE;

export const StorageService = {
  // --- Profile ---
  loadProfile(): SchoolProfile {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error('Error loading school profile:', e);
    }
    return DEFAULT_SCHOOL_PROFILE;
  },

  saveProfile(profile: SchoolProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.error('Error saving school profile:', e);
    }
  },

  // --- Platform Records ---
  loadRecords(): Record<string, PlatformDataRecord> {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.RECORDS);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error('Error loading platform records:', e);
    }
    return getClovisDeLuccaRealRecords();
  },

  saveRecords(records: Record<string, PlatformDataRecord>): void {
    try {
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(records));
    } catch (e) {
      console.error('Error saving platform records:', e);
    }
  },

  // --- Turmas ---
  loadTurmas(): TurmaPerformance[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.TURMAS);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error('Error loading turmas:', e);
    }
    return CLOVIS_DE_LUCCA_TURMAS;
  },

  saveTurmas(turmas: TurmaPerformance[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.TURMAS, JSON.stringify(turmas));
    } catch (e) {
      console.error('Error saving turmas:', e);
    }
  },

  // --- Action Plan ---
  loadActionPlan(): ActionPlanItem[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.ACTION_PLAN);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error('Error loading action plan:', e);
    }
    return CLOVIS_DE_LUCCA_MMR_ACTIONS;
  },

  saveActionPlan(plan: ActionPlanItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTION_PLAN, JSON.stringify(plan));
    } catch (e) {
      console.error('Error saving action plan:', e);
    }
  },

  // --- Historical Snapshots ---
  loadSnapshots(): HistoricalSnapshot[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SNAPSHOTS);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error('Error loading historical snapshots:', e);
    }
    // Default real historical line from user's files:
    return [
      {
        id: 'snap_pp3_real',
        title: '3º Bimestre 2026 - Super BI 7.5 & PP3 (54.6%)',
        periodo: '3º Bimestre',
        savedAt: '01/11/2026 13:40',
        scoreGeral: 75.0,
        classificacao: 'Consolidado',
        platformRecords: getClovisDeLuccaRealRecords(),
        turmas: CLOVIS_DE_LUCCA_TURMAS,
        actionPlan: CLOVIS_DE_LUCCA_MMR_ACTIONS,
        schoolProfile: CLOVIS_DE_LUCCA_PROFILE,
        observacoes: 'Consolidação de 10 semanas (26/07 a 03/10). Salto de Matemática para 49.8% e nota final do Super BI em 7.5.'
      },
      {
        id: 'snap_pp2_real',
        title: '2º Bimestre 2026 - Prova Paulista 2B',
        periodo: '2º Bimestre',
        savedAt: '15/07/2026 11:30',
        scoreGeral: 68.0,
        classificacao: 'Em Desenvolvimento',
        platformRecords: {
          ...getClovisDeLuccaRealRecords(),
          prova_paulista_2b: {
            ...getClovisDeLuccaRealRecords().prova_paulista_2b,
            currentValue: 48.0
          }
        },
        turmas: CLOVIS_DE_LUCCA_TURMAS,
        actionPlan: CLOVIS_DE_LUCCA_MMR_ACTIONS,
        schoolProfile: { ...CLOVIS_DE_LUCCA_PROFILE, bimestreReferencia: '2º Bimestre' },
        observacoes: 'Queda sazonal de acertos na Prova Paulista para 48.0%. Alerta em Matemática (37.8%) que motivou plano de ação das salas ambiente.'
      },
      {
        id: 'snap_pp1_real',
        title: '1º Bimestre 2026 - Prova Paulista 1B',
        periodo: '1º Bimestre',
        savedAt: '25/04/2026 16:00',
        scoreGeral: 71.5,
        classificacao: 'Consolidado',
        platformRecords: {
          ...getClovisDeLuccaRealRecords(),
          prova_paulista_1b: {
            ...getClovisDeLuccaRealRecords().prova_paulista_1b,
            currentValue: 53.2
          }
        },
        turmas: CLOVIS_DE_LUCCA_TURMAS,
        actionPlan: CLOVIS_DE_LUCCA_MMR_ACTIONS,
        schoolProfile: { ...CLOVIS_DE_LUCCA_PROFILE, bimestreReferencia: '1º Bimestre' },
        observacoes: 'Aplicação inicial da Prova Paulista com 96% de participação e 53.2% de acertos gerais.'
      }
    ];
  },

  saveSnapshot(snapshot: HistoricalSnapshot): HistoricalSnapshot[] {
    const list = this.loadSnapshots();
    const updated = [snapshot, ...list.filter(s => s.id !== snapshot.id)];
    try {
      localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(updated));
    } catch (e) {
      console.error('Error saving snapshot:', e);
    }
    return updated;
  },

  deleteSnapshot(id: string): HistoricalSnapshot[] {
    const list = this.loadSnapshots();
    const updated = list.filter(s => s.id !== id);
    try {
      localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(updated));
    } catch (e) {
      console.error('Error deleting snapshot:', e);
    }
    return updated;
  },

  // --- Full Backup Export (JSON File Download) ---
  exportBackupFile(fileName?: string): void {
    const backupData = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      schoolProfile: this.loadProfile(),
      platformRecords: this.loadRecords(),
      turmas: this.loadTurmas(),
      actionPlan: this.loadActionPlan(),
      snapshots: this.loadSnapshots()
    };

    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const profile = this.loadProfile();
    const safeSchoolName = (profile.nome || 'escola').replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    link.href = url;
    link.download = fileName || `backup_seduc_${safeSchoolName}_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  // --- Restore from Backup File ---
  async importBackupFile(file: File): Promise<{
    profile: SchoolProfile;
    records: Record<string, PlatformDataRecord>;
    turmas: TurmaPerformance[];
    actionPlan: ActionPlanItem[];
    snapshots: HistoricalSnapshot[];
  }> {
    const text = await file.text();
    const parsed = JSON.parse(text);

    const profile: SchoolProfile = parsed.schoolProfile || DEFAULT_SCHOOL_PROFILE;
    const records: Record<string, PlatformDataRecord> = parsed.platformRecords || {};
    const turmas: TurmaPerformance[] = parsed.turmas || [];
    const actionPlan: ActionPlanItem[] = parsed.actionPlan || [];
    const snapshots: HistoricalSnapshot[] = parsed.snapshots || [];

    this.saveProfile(profile);
    this.saveRecords(records);
    this.saveTurmas(turmas);
    this.saveActionPlan(actionPlan);
    localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(snapshots));

    return { profile, records, turmas, actionPlan, snapshots };
  },

  // Reset to default Clovis de Lucca real data
  resetToClovisDeLucca(): {
    profile: SchoolProfile;
    records: Record<string, PlatformDataRecord>;
    turmas: TurmaPerformance[];
    actionPlan: ActionPlanItem[];
    snapshots: HistoricalSnapshot[];
  } {
    const profile = CLOVIS_DE_LUCCA_PROFILE;
    const records = getClovisDeLuccaRealRecords();
    const turmas = CLOVIS_DE_LUCCA_TURMAS;
    const actionPlan = CLOVIS_DE_LUCCA_MMR_ACTIONS;
    this.saveProfile(profile);
    this.saveRecords(records);
    this.saveTurmas(turmas);
    this.saveActionPlan(actionPlan);
    localStorage.removeItem(STORAGE_KEYS.SNAPSHOTS);
    const snapshots = this.loadSnapshots();
    return { profile, records, turmas, actionPlan, snapshots };
  },

  // --- Clear all data ---
  clearAll(): void {
    Object.values(STORAGE_KEYS).forEach(k => {
      localStorage.removeItem(k);
    });
  }
};
