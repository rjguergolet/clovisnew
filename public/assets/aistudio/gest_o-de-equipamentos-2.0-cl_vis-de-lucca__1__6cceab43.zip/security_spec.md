# Security Specification for Firestore Rules

## 1. Data Invariants
- `equipamentos`:
  - Document ID must be a valid alphanumeric/hyphen string (`isValidId`).
  - Name is required, string, size between 1 and 200 chars.
  - Categoria must be one of: `['Impressão 3D', 'Ferramentas', 'Audiovisual', 'Eletrônicos', 'Informática', 'Robótica', 'Outros']`.
  - Estado de conservação must be one of: `['Novo', 'Bom', 'Precisa de Reparo', 'Inoperante']`.
  - Quantidade must be a number >= 0.
  - Read & write restricted to authenticated users.

- `emprestimos`:
  - Document ID must be a valid alphanumeric/hyphen string (`isValidId`).
  - Equipamento ID is required, string <= 128 chars.
  - Solicitante is required, string, 1 to 200 chars.
  - DataRetirada and DataDevolucao are required, string <= 20 chars.
  - Status must be `Pendente` or `Devolvido`.
  - Read & write restricted to authenticated users.

## 2. The Dirty Dozen Payloads (Designed to be Rejected)
1. **Unauthenticated Read on Equipamentos**: Any unauthenticated client trying to read or list items in `/equipamentos`.
2. **Unauthenticated Write on Equipamentos**: An unauthenticated user creating `/equipamentos/item1`.
3. **Invalid ID Injection**: Document ID with path traversal or illegal characters `/equipamentos/item..#$`.
4. **Oversized String in Equipamento**: `nome` exceeding 200 characters or containing malicious script payload.
5. **Invalid Categoria in Equipamento**: `categoria: "Armas"`.
6. **Invalid Estado in Equipamento**: `estadoConservacao: "Destruído"`.
7. **Negative Quantity**: `quantidade: -10`.
8. **Missing Required Fields on Equipamento**: Creating equipment without `nome` or `categoria`.
9. **Unauthenticated Read on Emprestimos**: Any unauthenticated read to `/emprestimos`.
10. **Emprestimo Invalid Status**: `status: "PerdidoForever"`.
11. **Emprestimo Missing Solicitante**: Emprestimo without `solicitante`.
12. **Oversized Notes Payload**: `observacoes` exceeding 1000 characters.
