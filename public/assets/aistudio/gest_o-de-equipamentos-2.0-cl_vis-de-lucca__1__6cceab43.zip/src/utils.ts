/**
 * Utilitários gerais para o Sistema de Gestão de Equipamentos e Empréstimos
 */

export function formatDateBR(dateStr?: string | null): string {
  if (!dateStr) return 'N/A';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const [year, month, day] = parts;
  return `${day}/${month}/${year}`;
}

export function isEmprestimoAtrasado(dataDevolucaoPrevista?: string | null, status?: string): boolean {
  if (status === 'Devolvido') return false;
  if (!dataDevolucaoPrevista) return false;
  const today = new Date().toISOString().split('T')[0];
  return dataDevolucaoPrevista < today;
}

export function getStatusBadgeConfig(status?: string, dataDevolucao?: string) {
  if (status === 'Devolvido') {
    return {
      label: 'Devolvido',
      className: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
    };
  }
  if (isEmprestimoAtrasado(dataDevolucao, status)) {
    return {
      label: 'Atrasado',
      className: 'bg-rose-500/10 text-rose-400 border-rose-500/30'
    };
  }
  return {
    label: 'Pendente',
    className: 'bg-amber-500/10 text-amber-400 border-amber-500/30'
  };
}
