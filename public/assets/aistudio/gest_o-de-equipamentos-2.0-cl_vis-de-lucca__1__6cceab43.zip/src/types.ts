export type UserRole = 
  | 'padrao' 
  | 'adm' 
  | 'adm_total'
  | 'PROFESSOR'
  | 'CGPG'
  | 'SECRETARIA'
  | 'VICE_DIRETOR'
  | 'PROFESSOR_PAAC'
  | 'DIRETOR'
  | 'professor'
  | 'cgpg'
  | 'secretaria'
  | 'vice_diretor'
  | 'professor_paac'
  | 'diretor'
  | string;

export interface UsuarioDoc {
  id?: string;
  uid: string;
  usuario?: string;
  email: string;
  nome?: string;
  perfil: UserRole | string;
  status: 'ativo' | 'inativo' | string;
  createdAt?: any;
  updatedAt?: any;
  createdBy?: string;
}

export interface Equipamento {
  id?: string;
  nome: string;
  patrimonio?: string | null;
  categoria: string;
  estadoConservacao: 'Novo' | 'Bom' | 'Precisa de Reparo' | 'Inoperante' | string;
  quantidade: number;
  localizacao?: string | null;
  observacoes?: string | null;
  fabricante?: string | null;
  modelo?: string | null;
  numeroSerie?: string | null;
  statusEquipamento?: string | null;
  avaliacaoTecnica?: string | null;
  importedAt?: string | null;
  // Campos para Uso Permanente / Atribuição Fixa
  usoPermanente?: boolean | null;
  responsavelPermanente?: string | null;
  localPermanente?: string | null;
  motivoUsoPermanente?: string | null;
  createdAt?: any;
  updatedAt?: any;
}

export interface KitItem {
  equipamentoId?: string;
  nome: string;
  patrimonio?: string | null;
  categoria?: string;
  quantidade: number;
}

export interface Kit {
  id?: string;
  nome: string;
  descricao?: string | null;
  categoria?: string;
  totalItens: number;
  status?: 'Ativo' | 'Inativo';
  itens: KitItem[];
  createdAt?: any;
  updatedAt?: any;
}

export interface AulaPeriod {
  id: string; // e.g. 'M1', 'M2', ..., 'M7', 'T1', ..., 'T7'
  turno: 'Manhã' | 'Tarde';
  numero: number; // 1 to 7
  label: string; // '1ª Aula'
  horario: string; // '07:00 - 07:45'
  descricaoCompleta: string; // 'Manhã - 1ª Aula (07:00 - 07:45)'
}

export interface Emprestimo {
  id?: string;
  tipoEmprestimo?: 'individual' | 'kit' | 'lote' | string;
  equipamentoId: string;
  equipamentoNome: string;
  kitId?: string | null;
  kitNome?: string | null;
  itensEmprestados?: KitItem[] | null;
  quantidadeTotal?: number;
  solicitante: string;
  contato?: string | null;
  turmaOuSala?: string | null;
  dataAgendamento?: string; // YYYY-MM-DD
  dataRetirada: string;
  dataRetiradaReal?: string | null;
  retirado?: boolean | null;
  dataDevolucao: string;
  dataDevolucaoReal?: string | null;
  turno?: 'Manhã' | 'Tarde' | 'Integral' | 'Ambos' | string;
  aulas?: string[]; // IDs das aulas: ['M1', 'M2', 'M3'] etc
  status: 'Pendente' | 'Devolvido' | string;
  observacoes?: string | null;
  // Campos de Avaria na Devolução
  temAvaria?: boolean | null;
  avariaDescricao?: string | null;
  avariaRegistradaPor?: string | null;
  avariaData?: string | null;
  equipamentoEstadoDevolucao?: 'Novo' | 'Bom' | 'Precisa de Reparo' | 'Inoperante' | string | null;
  selectedEquipamentos?: KitItem[] | null;
  // Campos de Recorrência (Uso Fixo)
  recorrente?: boolean | null;
  recorrenciaId?: string | null;
  diasSemana?: number[] | null; // 0=Dom, 1=Seg, 2=Ter, 3=Qua, 4=Qui, 5=Sex, 6=Sab
  diasSemanaNomes?: string[] | null; // ['Segunda', 'Quarta']
  dataFimRecorrencia?: string | null; // YYYY-MM-DD
  recorrenciaDescricao?: string | null;
  createdAt?: any;
  updatedAt?: any;
}

