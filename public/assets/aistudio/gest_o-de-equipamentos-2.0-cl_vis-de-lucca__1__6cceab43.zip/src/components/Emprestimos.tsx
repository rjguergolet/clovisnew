import React, { useState, useEffect, useMemo } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc,
  updateDoc, 
  deleteDoc,
  doc, 
  serverTimestamp,
  query, 
  orderBy, 
  where,
  limit,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { UserRole, Emprestimo, Equipamento, Kit, KitItem } from '../types';
import { PERMISSIONS, isEquipamentoAptoParaEmprestimo } from '../lib/userRoles';
import { 
  AULAS_MANHA, 
  AULAS_TARDE, 
  ALL_AULAS, 
  formatAulasSummary, 
  determineTurnoFromAulas,
  DIAS_SEMANA_OPCOES,
  gerarDatasRecorrentes
} from '../lib/schoolSchedule';
import MultiEquipamentoSelector from './MultiEquipamentoSelector';
import RecorrenciaModal from './RecorrenciaModal';
import DetalhesAgendamentoModal from './DetalhesAgendamentoModal';
import DevolucaoAvariaModal from './DevolucaoAvariaModal';
import PainelEmprestadosAgora from './PainelEmprestadosAgora';
import AgendamentoRapidoModal from './AgendamentoRapidoModal';
import { 
  validateAgendamento, 
  getEquipamentoIndisponibilidadeMap 
} from '../lib/loanConflictChecker';
import { 
  ArrowRightLeft, 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  User, 
  Calendar, 
  Package, 
  Phone, 
  Loader2, 
  X, 
  CheckCheck,
  Undo2,
  CalendarDays,
  Sparkles,
  Boxes,
  School,
  AlertTriangle,
  Repeat,
  CheckSquare,
  Check,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowDownWideNarrow,
  ArrowUpNarrowWide,
  Eye,
  History,
  Sun,
  Filter,
  RefreshCw
} from 'lucide-react';

interface EmprestimosProps {
  userRole?: UserRole;
  initialEquipamento?: any;
  onClearInitialEquipamento?: () => void;
  currentUserName?: string;
}

export default function Emprestimos({ 
  userRole = 'padrao', 
  initialEquipamento = null, 
  onClearInitialEquipamento,
  currentUserName = ''
}: EmprestimosProps) {
  const [emprestimos, setEmprestimos] = useState<Emprestimo[]>([]);
  const [equipamentos, setEquipamentos] = useState<Equipamento[]>([]);
  const [kits, setKits] = useState<Kit[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'TODOS' | 'AGENDADOS' | 'RETIRADOS' | 'DEVOLVIDOS' | 'ATRASADOS'>('TODOS');
  const [tipoFilter, setTipoFilter] = useState<'TODOS' | 'individual' | 'kit'>('TODOS');
  const [turnoFilter, setTurnoFilter] = useState<'TODOS' | 'manha' | 'tarde'>('TODOS');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('asc'); // 'asc' = Mais antigo primeiro (padrão)
  
  // Abas: 'painel_dia' (Painel do Dia / Emprestados Hoje) vs 'todos_agendamentos' (Tabela e Calendário) vs 'historico' (Devolvidos)
  const [viewMode, setViewMode] = useState<'painel_dia' | 'todos_agendamentos' | 'historico'>('painel_dia');

  // Modal de Agendamento Rápido Expresso
  const [isRapidoModalOpen, setIsRapidoModalOpen] = useState(false);

  // Filtro de Data para Agendamentos Ativos (Hoje por padrão, opção de ver outros dias ou todos)
  const [dateScope, setDateScope] = useState<'hoje' | 'amanha' | 'data' | 'todos'>('hoje');
  
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const [selectedCustomDate, setSelectedCustomDate] = useState<string>(todayStr);
  const [showAtrasadosOverlay, setShowAtrasadosOverlay] = useState(false);

  // Limite de carregamento preguiçoso (lazy loading) do histórico de devolvidos
  const [historicoLimit, setHistoricoLimit] = useState<number>(20);

  // Modais de Criação / Edição / Detalhes / Devolução
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isRecorrenciaModalOpen, setIsRecorrenciaModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Emprestimo | null>(null);
  const [salvando, setSalvando] = useState(false);

  // Modal de Detalhes dos Equipamentos (aberto ao clicar no agendamento)
  const [selectedLoanForDetails, setSelectedLoanForDetails] = useState<Emprestimo | null>(null);

  // Modal de Devolução com Checagem e Registro de Avarias
  const [itemParaDevolucao, setItemParaDevolucao] = useState<Emprestimo | null>(null);
  const [loadingDevolucao, setLoadingDevolucao] = useState(false);

  // Multi-Seleção na Tabela de Empréstimos (Ações em Lote)
  const [selectedLoanIds, setSelectedLoanIds] = useState<string[]>([]);
  const [batchProcessing, setBatchProcessing] = useState(false);

  // Modal de Exclusão
  const [itemToDelete, setItemToDelete] = useState<Emprestimo | null>(null);
  const [excluindo, setExcluindo] = useState(false);

  // Permissões de Acesso por Perfil
  const canDelete = PERMISSIONS.canDeleteEmprestimo(userRole);
  const canManageRecurring = PERMISSIONS.canManageRecurringLoans(userRole);
  const canChangeStatus = PERMISSIONS.canChangeEmprestimoStatus(userRole);
  const canEdit = PERMISSIONS.canEditEmprestimo(userRole);

  const defaultEndDate = new Date();
  defaultEndDate.setMonth(defaultEndDate.getMonth() + 3);
  const defaultEndDateStr = defaultEndDate.toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    tipoEmprestimo: 'lote' as 'individual' | 'kit' | 'lote',
    equipamentoId: '',
    equipamentoNome: '',
    kitId: '',
    kitNome: '',
    selectedEquipamentos: [] as KitItem[],
    solicitante: '',
    turmaOuSala: '',
    contato: '',
    dataRetirada: todayStr,
    dataDevolucao: todayStr,
    dataAgendamento: todayStr,
    aulas: ['M1', 'M2'] as string[],
    status: 'Pendente' as 'Pendente' | 'Devolvido',
    retirado: false,
    observacoes: '',
    isRecorrente: false,
    diasSemana: [1, 3] as number[],
    dataFimRecorrencia: defaultEndDateStr
  });

  // Carregar Equipamentos para o inventário
  useEffect(() => {
    const qEq = query(collection(db, 'equipamentos'), orderBy('nome', 'asc'));
    const unsubEq = onSnapshot(qEq, (snapshot) => {
      const docs = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as Equipamento[];
      setEquipamentos(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'equipamentos');
    });

    return () => unsubEq();
  }, []);

  // Carregar Kits em tempo real
  useEffect(() => {
    const qKits = query(collection(db, 'kits'), orderBy('nome', 'asc'));
    const unsubKits = onSnapshot(qKits, (snapshot) => {
      const docs = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as Kit[];
      setKits(docs);
    }, () => {});

    return () => unsubKits();
  }, []);

  // Carregamento Sob Demanda e Otimizado do Banco de Dados:
  // - Modo 'ativos': Carrega apenas agendamentos pendentes/ativos do banco
  // - Modo 'historico': Carrega apenas os últimos 20 devolvidos (lazy loading com limite sob demanda)
  useEffect(() => {
    setLoading(true);

    let qEmp;
    if (viewMode === 'historico') {
      qEmp = query(
        collection(db, 'emprestimos'), 
        where('status', '==', 'Devolvido'),
        limit(historicoLimit)
      );
    } else {
      qEmp = query(collection(db, 'emprestimos'), where('status', '==', 'Pendente'));
    }

    const unsubEmp = onSnapshot(qEmp, (snapshot) => {
      const docs = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as Emprestimo[];
      setEmprestimos(docs);
      setLoading(false);
    }, (error) => {
      setLoading(false);
      handleFirestoreError(error, OperationType.LIST, 'emprestimos');
    });

    return () => unsubEmp();
  }, [viewMode, historicoLimit]);

  // Carrega em tempo real empréstimos devolvidos hoje para o painel diário de controle rápido
  const [devolvidosHojeList, setDevolvidosHojeList] = useState<Emprestimo[]>([]);

  useEffect(() => {
    const qDevHoje = query(
      collection(db, 'emprestimos'),
      where('status', '==', 'Devolvido'),
      where('dataDevolucaoReal', '==', todayStr)
    );
    const unsubDev = onSnapshot(qDevHoje, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Emprestimo[];
      setDevolvidosHojeList(docs);
    }, () => {});

    return () => unsubDev();
  }, [todayStr]);

  const emprestimosParaPainel = useMemo(() => {
    const map = new Map<string, Emprestimo>();
    emprestimos.forEach(e => { if (e.id) map.set(e.id, e); });
    devolvidosHojeList.forEach(e => { if (e.id) map.set(e.id, e); });
    return Array.from(map.values());
  }, [emprestimos, devolvidosHojeList]);

  // Se vier um equipamento ou kit pré-selecionado da aba de Equipamentos
  useEffect(() => {
    if (initialEquipamento) {
      setIsRapidoModalOpen(true);
    }
  }, [initialEquipamento]);

  // Lista de equipamentos válidos e disponíveis para empréstimo (Ativos, Operacionais e sem uso permanente)
  const equipamentosAptos = useMemo(() => {
    return equipamentos.filter(eq => isEquipamentoAptoParaEmprestimo(eq) && !eq.usoPermanente);
  }, [equipamentos]);

  const handleOpenAddModal = (presetEq: any = null) => {
    setIsRapidoModalOpen(true);
  };

  const handleConfirmRapido = async (payload: any) => {
    // Validação estrita contra itens inativos, uso permanente e horários conflitantes
    const validacao = validateAgendamento({
      tipoEmprestimo: payload.tipoEmprestimo,
      equipamentoId: payload.equipamentoId,
      kitId: payload.kitId,
      itens: payload.itensEmprestados,
      data: payload.dataRetirada,
      aulas: payload.aulas,
      isRecorrente: payload.isRecorrente,
      diasSemana: payload.diasSemana,
      dataFimRecorrencia: payload.dataFimRecorrencia,
      equipamentos,
      kits,
      emprestimos
    });

    if (!validacao.isValid) {
      alert(validacao.errorMessage);
      return;
    }

    setSalvando(true);
    try {
      if (payload.isRecorrente) {
        if (!payload.diasSemana || payload.diasSemana.length === 0) {
          alert('Selecione ao menos um dia da semana para o agendamento recorrente.');
          setSalvando(false);
          return;
        }

        const datas = gerarDatasRecorrentes(payload.dataRetirada, payload.dataFimRecorrencia, payload.diasSemana);
        if (datas.length === 0) {
          alert('Nenhuma data encontrada no intervalo para os dias da semana escolhidos.');
          setSalvando(false);
          return;
        }

        const recorrenciaId = `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const diasNomes = payload.diasSemana.map((d: number) => {
          const opt = DIAS_SEMANA_OPCOES.find(o => o.id === d);
          return opt ? opt.short : String(d);
        });
        const descRecorrencia = `Uso Fixo: ${diasNomes.join('/')} • ${formatAulasSummary(payload.aulas)} até ${payload.dataFimRecorrencia.split('-').reverse().join('/')}`;

        const batchSize = 350;
        for (let i = 0; i < datas.length; i += batchSize) {
          const chunk = datas.slice(i, i + batchSize);
          const batch = writeBatch(db);

          chunk.forEach((dataAgendada: string) => {
            const newDocRef = doc(collection(db, 'emprestimos'));
            batch.set(newDocRef, {
              ...payload,
              turno: determineTurnoFromAulas(payload.aulas),
              dataRetirada: dataAgendada,
              dataDevolucao: dataAgendada,
              dataAgendamento: dataAgendada,
              recorrente: true,
              recorrenciaId,
              diasSemanaNomes: diasNomes,
              recorrenciaDescricao: descRecorrencia,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
          });

          await batch.commit();
        }
        alert(`Sucesso! ${datas.length} agendamentos recorrentes foram gerados.`);
      } else {
        const turnoDeterminado = determineTurnoFromAulas(payload.aulas);
        const docPayload = {
          ...payload,
          turno: turnoDeterminado,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };
        await addDoc(collection(db, 'emprestimos'), docPayload);
      }

      setIsRapidoModalOpen(false);
      if (onClearInitialEquipamento) onClearInitialEquipamento();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'emprestimos');
    } finally {
      setSalvando(false);
    }
  };

  const handleOpenAddModalForKit = (kit: Kit) => {
    setEditingItem(null);
    setFormData({
      tipoEmprestimo: 'kit',
      equipamentoId: kit.id || 'kit-' + Date.now(),
      equipamentoNome: `[KIT] ${kit.nome} (${kit.totalItens} itens)`,
      kitId: kit.id || '',
      kitNome: kit.nome,
      selectedEquipamentos: kit.itens || [],
      solicitante: '',
      turmaOuSala: '',
      contato: '',
      dataRetirada: todayStr,
      dataDevolucao: todayStr,
      dataAgendamento: todayStr,
      aulas: ['M1', 'M2'],
      status: 'Pendente',
      retirado: false,
      observacoes: `Kit composto por: ${kit.itens?.map(i => `${i.quantidade}x ${i.nome}`).join(', ')}`,
      isRecorrente: false,
      diasSemana: [1, 3],
      dataFimRecorrencia: defaultEndDateStr
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (item: Emprestimo) => {
    if (!canEdit) {
      // Perfil sem permissão de edição (ex: Professor)
      setSelectedLoanForDetails(item);
      return;
    }

    setEditingItem(item);
    const validTipo: 'individual' | 'kit' | 'lote' = 
      item.tipoEmprestimo === 'kit' || item.tipoEmprestimo === 'lote' 
        ? (item.tipoEmprestimo as 'kit' | 'lote')
        : (item.kitId ? 'kit' : 'lote');
    const validStatus: 'Pendente' | 'Devolvido' = 
      item.status === 'Devolvido' ? 'Devolvido' : 'Pendente';

    let itemEquipamentos: KitItem[] = [];
    if (item.itensEmprestados && Array.isArray(item.itensEmprestados) && item.itensEmprestados.length > 0) {
      itemEquipamentos = item.itensEmprestados;
    } else if (item.equipamentoId) {
      itemEquipamentos = [{
        equipamentoId: item.equipamentoId,
        nome: item.equipamentoNome || 'Equipamento',
        quantidade: item.quantidadeTotal || 1
      }];
    }

    setFormData({
      tipoEmprestimo: validTipo,
      equipamentoId: item.equipamentoId || '',
      equipamentoNome: item.equipamentoNome || '',
      kitId: item.kitId || '',
      kitNome: item.kitNome || '',
      selectedEquipamentos: itemEquipamentos,
      solicitante: item.solicitante || '',
      turmaOuSala: item.turmaOuSala || '',
      contato: item.contato || '',
      dataRetirada: item.dataRetirada || todayStr,
      dataDevolucao: item.dataDevolucao || todayStr,
      dataAgendamento: item.dataAgendamento || item.dataRetirada || todayStr,
      aulas: item.aulas && Array.isArray(item.aulas) ? item.aulas : [],
      status: validStatus,
      retirado: Boolean(item.retirado || item.status === 'Devolvido'),
      observacoes: item.observacoes || '',
      isRecorrente: Boolean(item.recorrente),
      diasSemana: (item.diasSemana && item.diasSemana.length > 0) ? item.diasSemana : [1, 3],
      dataFimRecorrencia: item.dataFimRecorrencia || defaultEndDateStr
    });
    setIsModalOpen(true);
  };

  const handleEquipamentoSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedId = e.target.value;
    const eq = equipamentos.find(item => item.id === selectedId);
    
    if (eq && !isEquipamentoAptoParaEmprestimo(eq)) {
      alert(`Atenção: O equipamento selecionado está com status '${eq.statusEquipamento || eq.estadoConservacao}' e não pode ser emprestado.`);
      return;
    }

    setFormData(prev => ({
      ...prev,
      equipamentoId: selectedId,
      equipamentoNome: eq ? `${eq.nome}${eq.patrimonio ? ` (Patr: ${eq.patrimonio})` : ''}` : '',
      selectedEquipamentos: eq ? [{
        equipamentoId: eq.id || '',
        nome: eq.nome,
        patrimonio: eq.patrimonio || null,
        categoria: eq.categoria || 'Geral',
        quantidade: 1
      }] : []
    }));
  };

  const handleKitSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedKitId = e.target.value;
    const selectedKit = kits.find(k => k.id === selectedKitId);
    if (!selectedKit) return;

    setFormData(prev => ({
      ...prev,
      kitId: selectedKit.id || '',
      kitNome: selectedKit.nome,
      equipamentoId: selectedKit.id || 'kit',
      equipamentoNome: `[KIT] ${selectedKit.nome} (${selectedKit.totalItens} itens)`,
      selectedEquipamentos: selectedKit.itens || [],
      observacoes: prev.observacoes || `Kit: ${selectedKit.itens?.map(i => `${i.quantidade}x ${i.nome}`).join(', ')}`
    }));
  };

  const handleToggleAula = (aulaId: string) => {
    setFormData(prev => {
      const current = prev.aulas || [];
      const exists = current.includes(aulaId);
      const updated = exists 
        ? current.filter(id => id !== aulaId)
        : [...current, aulaId];
      return { ...prev, aulas: updated };
    });
  };

  const handleSelectAllMorning = () => {
    const morningIds = AULAS_MANHA.map(a => a.id);
    setFormData(prev => {
      const otherAulas = (prev.aulas || []).filter(id => !morningIds.includes(id));
      return { ...prev, aulas: [...otherAulas, ...morningIds] };
    });
  };

  const handleSelectAllAfternoon = () => {
    const afternoonIds = AULAS_TARDE.map(a => a.id);
    setFormData(prev => {
      const otherAulas = (prev.aulas || []).filter(id => !afternoonIds.includes(id));
      return { ...prev, aulas: [...otherAulas, ...afternoonIds] };
    });
  };

  const handleClearAulas = () => {
    setFormData(prev => ({ ...prev, aulas: [] }));
  };

  const toggleDiaSemanaForm = (id: number) => {
    setFormData(prev => {
      const exists = prev.diasSemana.includes(id);
      const updated = exists 
        ? prev.diasSemana.filter(d => d !== id)
        : [...prev.diasSemana, id].sort((a, b) => a - b);
      return { ...prev, diasSemana: updated };
    });
  };

  const datasRecorrentesGeradas = useMemo(() => {
    if (!formData.isRecorrente) return [];
    return gerarDatasRecorrentes(formData.dataRetirada, formData.dataFimRecorrencia, formData.diasSemana);
  }, [formData.isRecorrente, formData.dataRetirada, formData.dataFimRecorrencia, formData.diasSemana]);

  // Mapa de indisponibilidade em tempo real para o formulário de agendamento/edição
  const indisponibilidadeMapForm = useMemo(() => {
    if (!formData.dataRetirada) return new Map();
    return getEquipamentoIndisponibilidadeMap(
      formData.dataRetirada,
      formData.aulas || [],
      emprestimos,
      kits,
      editingItem?.id
    );
  }, [formData.dataRetirada, formData.aulas, emprestimos, kits, editingItem]);

  // Ações em Lote com Checkboxes na Tabela
  const handleToggleSelectLoan = (id: string) => {
    setSelectedLoanIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllLoans = (loansToSelect: Emprestimo[]) => {
    const validIds = loansToSelect.map(l => l.id).filter(Boolean) as string[];
    const allSelected = validIds.every(id => selectedLoanIds.includes(id));
    if (allSelected) {
      setSelectedLoanIds(prev => prev.filter(id => !validIds.includes(id)));
    } else {
      setSelectedLoanIds(Array.from(new Set([...selectedLoanIds, ...validIds])));
    }
  };

  const handleClearLoanSelection = () => {
    setSelectedLoanIds([]);
  };

  // Alternar Retirada (Marcado como Retirado / Aguardando)
  const handleToggleRetirada = async (item: Emprestimo) => {
    if (!item.id || !canChangeStatus) return;
    const novoRetirado = !Boolean(item.retirado);
    try {
      const docRef = doc(db, 'emprestimos', item.id);
      await updateDoc(docRef, {
        retirado: novoRetirado,
        dataRetiradaReal: novoRetirado ? todayStr : null,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `emprestimos/${item.id}`);
    }
  };

  // Abrir Modal de Devolução & Registro de Avarias
  const handleOpenDevolucaoModal = (item: Emprestimo) => {
    if (!canChangeStatus) return;
    setItemParaDevolucao(item);
  };

  // Confirmar Devolução e Registro de Avarias no Firestore
  const handleConfirmDevolucaoComAvaria = async (
    item: Emprestimo, 
    avariaData: { 
      houveAvaria: boolean; 
      avariaDescricao: string; 
      estadoConservacao: 'Precisa de Reparo' | 'Inoperante'; 
      atualizarInventario: boolean 
    }
  ) => {
    if (!item.id || !canChangeStatus) return;
    setLoadingDevolucao(true);
    try {
      const docRef = doc(db, 'emprestimos', item.id);
      
      // 1. Atualizar o registro do empréstimo
      const updates: any = {
        status: 'Devolvido',
        retirado: true,
        dataDevolucaoReal: todayStr,
        temAvaria: avariaData.houveAvaria,
        avariaDescricao: avariaData.houveAvaria ? avariaData.avariaDescricao : null,
        avariaData: avariaData.houveAvaria ? todayStr : null,
        avariaRegistradaPor: avariaData.houveAvaria ? (userRole || 'Operador') : null,
        equipamentoEstadoDevolucao: avariaData.houveAvaria ? avariaData.estadoConservacao : null,
        updatedAt: serverTimestamp()
      };
      await updateDoc(docRef, updates);

      // 2. Se houve avaria e o usuário marcou para atualizar o inventário
      if (avariaData.houveAvaria && avariaData.atualizarInventario) {
        if (item.equipamentoId && item.equipamentoId !== 'kit' && item.equipamentoId !== 'lote') {
          const eqRef = doc(db, 'equipamentos', item.equipamentoId);
          await updateDoc(eqRef, {
            estadoConservacao: avariaData.estadoConservacao,
            statusEquipamento: 'Manutenção',
            avaliacaoTecnica: `Avaria registrada na devolução em ${todayStr.split('-').reverse().join('/')}: ${avariaData.avariaDescricao}`,
            updatedAt: serverTimestamp()
          });
        }
      }

      setItemParaDevolucao(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `emprestimos/${item.id}`);
    } finally {
      setLoadingDevolucao(false);
    }
  };

  // Botão rápido de avanço no ciclo (Retirada -> Devolução -> Reabrir)
  const handleAvancarCiclo = async (item: Emprestimo) => {
    if (!item.id || !canChangeStatus) return;
    const isDevolvido = item.status === 'Devolvido';
    const isRetirado = Boolean(item.retirado);

    if (!isRetirado && !isDevolvido) {
      // Passo 1: Marcar Retirada
      await handleToggleRetirada(item);
    } else if (isRetirado && !isDevolvido) {
      // Passo 2: Abrir modal de devolução para checar avarias
      handleOpenDevolucaoModal(item);
    } else {
      // Passo 3: Reabrir empréstimo
      try {
        const docRef = doc(db, 'emprestimos', item.id);
        await updateDoc(docRef, {
          status: 'Pendente',
          dataDevolucaoReal: null,
          updatedAt: serverTimestamp()
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `emprestimos/${item.id}`);
      }
    }
  };

  // Ações em Lote para Retirada e Devolução
  const handleBatchMarcarRetirada = async (retirado: boolean = true) => {
    if (selectedLoanIds.length === 0 || !canChangeStatus) return;
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      selectedLoanIds.forEach(id => {
        const docRef = doc(db, 'emprestimos', id);
        batch.update(docRef, {
          retirado: retirado,
          dataRetiradaReal: retirado ? todayStr : null,
          updatedAt: serverTimestamp()
        });
      });
      await batch.commit();
      setSelectedLoanIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'emprestimos');
    } finally {
      setBatchProcessing(false);
    }
  };

  const handleBatchMarcarDevolvido = async (novoStatus: 'Devolvido' | 'Pendente' = 'Devolvido') => {
    if (selectedLoanIds.length === 0 || !canChangeStatus) return;
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      selectedLoanIds.forEach(id => {
        const docRef = doc(db, 'emprestimos', id);
        batch.update(docRef, {
          status: novoStatus,
          dataDevolucaoReal: novoStatus === 'Devolvido' ? todayStr : null,
          retirado: novoStatus === 'Devolvido' ? true : undefined,
          updatedAt: serverTimestamp()
        });
      });
      await batch.commit();
      setSelectedLoanIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'emprestimos');
    } finally {
      setBatchProcessing(false);
    }
  };

  const handleBatchExcluirEmprestimos = async () => {
    if (selectedLoanIds.length === 0 || !canDelete) return;
    if (!window.confirm(`Tem certeza que deseja excluir ${selectedLoanIds.length} agendamentos/empréstimos selecionados?`)) {
      return;
    }
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      selectedLoanIds.forEach(id => {
        const docRef = doc(db, 'emprestimos', id);
        batch.delete(docRef);
      });
      await batch.commit();
      setSelectedLoanIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'emprestimos');
    } finally {
      setBatchProcessing(false);
    }
  };

  // Submissão do Formulário de Criação/Edição
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.solicitante.trim() || !formData.dataRetirada) {
      alert('Preencha os campos obrigatórios (Solicitante e Data de Retirada).');
      return;
    }

    let finalEquipamentoId = formData.equipamentoId;
    let finalEquipamentoNome = formData.equipamentoNome;
    let finalItensEmprestados: KitItem[] | null = null;
    let finalQuantidadeTotal = 1;

    if (formData.tipoEmprestimo === 'kit') {
      if (!formData.kitId) {
        alert('Selecione um Kit de Equipamentos.');
        return;
      }
      const selectedKitObj = kits.find(k => k.id === formData.kitId);
      finalEquipamentoId = formData.kitId || 'kit';
      finalEquipamentoNome = `[KIT] ${selectedKitObj?.nome || formData.kitNome} (${selectedKitObj?.totalItens || 1} itens)`;
      finalItensEmprestados = selectedKitObj?.itens || null;
      finalQuantidadeTotal = selectedKitObj?.totalItens || 1;
    } else if (formData.tipoEmprestimo === 'lote') {
      if (formData.selectedEquipamentos.length === 0) {
        alert('Selecione pelo menos 1 equipamento pelas caixas de seleção.');
        return;
      }
      finalItensEmprestados = formData.selectedEquipamentos;
      finalQuantidadeTotal = formData.selectedEquipamentos.reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);
      finalEquipamentoId = formData.selectedEquipamentos[0].equipamentoId || 'lote';

      if (formData.selectedEquipamentos.length === 1) {
        const single = formData.selectedEquipamentos[0];
        finalEquipamentoNome = `${single.quantidade > 1 ? `${single.quantidade}x ` : ''}${single.nome}${single.patrimonio ? ` (Patr: ${single.patrimonio})` : ''}`;
      } else {
        const itemNames = formData.selectedEquipamentos.map(i => `${i.quantidade}x ${i.nome}`).join(', ');
        finalEquipamentoNome = `${finalQuantidadeTotal} Itens: ${itemNames}`;
      }
    } else {
      if (!formData.equipamentoId) {
        alert('Selecione um equipamento do inventário.');
        return;
      }

      const selectedEq = equipamentos.find(eq => eq.id === formData.equipamentoId);
      if (selectedEq && !isEquipamentoAptoParaEmprestimo(selectedEq)) {
        alert(`Não é permitido emprestar o equipamento "${selectedEq.nome}" porque ele não está com status Ativo.`);
        return;
      }

      finalEquipamentoId = formData.equipamentoId;
      finalEquipamentoNome = formData.equipamentoNome;
      finalItensEmprestados = selectedEq ? [{
        equipamentoId: selectedEq.id || '',
        nome: selectedEq.nome,
        patrimonio: selectedEq.patrimonio || null,
        categoria: selectedEq.categoria || 'Geral',
        quantidade: 1
      }] : null;
      finalQuantidadeTotal = 1;
    }

    // Validação estrita de conflito de horários e itens inaptos/de uso permanente
    const validacao = validateAgendamento({
      tipoEmprestimo: formData.tipoEmprestimo,
      equipamentoId: formData.equipamentoId,
      kitId: formData.kitId,
      itens: formData.tipoEmprestimo === 'lote' ? formData.selectedEquipamentos : finalItensEmprestados,
      data: formData.dataRetirada,
      aulas: formData.aulas,
      isRecorrente: formData.isRecorrente,
      diasSemana: formData.diasSemana,
      dataFimRecorrencia: formData.dataFimRecorrencia,
      equipamentos,
      kits,
      emprestimos,
      ignoreEmprestimoId: editingItem?.id
    });

    if (!validacao.isValid) {
      alert(validacao.errorMessage);
      return;
    }

    const turnoDeterminado = determineTurnoFromAulas(formData.aulas);

    setSalvando(true);
    try {
      if (formData.isRecorrente && !editingItem) {
        if (formData.diasSemana.length === 0) {
          alert('Selecione ao menos um dia da semana para o agendamento recorrente.');
          setSalvando(false);
          return;
        }

        const datas = gerarDatasRecorrentes(formData.dataRetirada, formData.dataFimRecorrencia, formData.diasSemana);
        if (datas.length === 0) {
          alert('Nenhuma data encontrada no intervalo selecionado para os dias da semana escolhidos.');
          setSalvando(false);
          return;
        }

        const recorrenciaId = `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const diasNomes = formData.diasSemana.map(d => {
          const opt = DIAS_SEMANA_OPCOES.find(o => o.id === d);
          return opt ? opt.short : String(d);
        });
        const descRecorrencia = `Uso Fixo: ${diasNomes.join('/')} • ${formatAulasSummary(formData.aulas)} até ${formData.dataFimRecorrencia.split('-').reverse().join('/')}`;

        const batchSize = 350;
        for (let i = 0; i < datas.length; i += batchSize) {
          const chunk = datas.slice(i, i + batchSize);
          const batch = writeBatch(db);
          chunk.forEach(dataAgendada => {
            const newDocRef = doc(collection(db, 'emprestimos'));
            batch.set(newDocRef, {
              tipoEmprestimo: formData.tipoEmprestimo,
              equipamentoId: finalEquipamentoId,
              equipamentoNome: finalEquipamentoNome,
              kitId: formData.tipoEmprestimo === 'kit' ? formData.kitId : null,
              kitNome: formData.tipoEmprestimo === 'kit' ? formData.kitNome : null,
              itensEmprestados: finalItensEmprestados,
              quantidadeTotal: finalQuantidadeTotal,
              solicitante: formData.solicitante.trim(),
              turmaOuSala: formData.turmaOuSala.trim() || null,
              contato: formData.contato.trim() || null,
              dataRetirada: dataAgendada,
              dataDevolucao: dataAgendada,
              dataAgendamento: dataAgendada,
              aulas: formData.aulas,
              turno: turnoDeterminado,
              status: 'Pendente',
              retirado: false,
              observacoes: formData.observacoes.trim() ? `[Recorrente] ${formData.observacoes.trim()}` : `[Uso Fixo Recorrente - ${formData.solicitante.trim()}]`,
              recorrente: true,
              recorrenciaId: recorrenciaId,
              diasSemana: formData.diasSemana,
              diasSemanaNomes: diasNomes,
              dataFimRecorrencia: formData.dataFimRecorrencia,
              recorrenciaDescricao: descRecorrencia,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
          });
          await batch.commit();
        }

        alert(`Sucesso! ${datas.length} agendamentos recorrentes foram gerados no calendário até ${formData.dataFimRecorrencia.split('-').reverse().join('/')}.`);
      } else {
        const payload: any = {
          tipoEmprestimo: formData.tipoEmprestimo,
          equipamentoId: finalEquipamentoId,
          equipamentoNome: finalEquipamentoNome,
          kitId: formData.tipoEmprestimo === 'kit' ? formData.kitId : null,
          kitNome: formData.tipoEmprestimo === 'kit' ? formData.kitNome : null,
          itensEmprestados: finalItensEmprestados,
          quantidadeTotal: finalQuantidadeTotal,
          solicitante: formData.solicitante.trim(),
          turmaOuSala: formData.turmaOuSala.trim() || null,
          contato: formData.contato.trim() || null,
          dataRetirada: formData.dataRetirada,
          dataDevolucao: formData.dataDevolucao || formData.dataRetirada,
          dataAgendamento: formData.dataAgendamento || formData.dataRetirada,
          aulas: formData.aulas,
          turno: turnoDeterminado,
          status: formData.status || 'Pendente',
          retirado: Boolean(formData.retirado || formData.status === 'Devolvido'),
          dataRetiradaReal: formData.retirado ? todayStr : null,
          dataDevolucaoReal: formData.status === 'Devolvido' ? todayStr : null,
          observacoes: formData.observacoes.trim() || null,
          updatedAt: serverTimestamp()
        };

        if (editingItem && editingItem.id) {
          const docRef = doc(db, 'emprestimos', editingItem.id);
          await updateDoc(docRef, payload);
        } else {
          payload.createdAt = serverTimestamp();
          await addDoc(collection(db, 'emprestimos'), payload);
        }
      }

      setIsModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, 'emprestimos');
    } finally {
      setSalvando(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete || !itemToDelete.id || !canDelete) return;
    setExcluindo(true);
    try {
      await deleteDoc(doc(db, 'emprestimos', itemToDelete.id));
      setItemToDelete(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `emprestimos/${itemToDelete.id}`);
    } finally {
      setExcluindo(false);
    }
  };

  const formatDateBR = (dateStr?: string | null) => {
    if (!dateStr) return '';
    if (dateStr.includes('/')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  const isAtrasado = (item: Emprestimo): boolean => {
    if (item.status === 'Devolvido') return false;
    if (!item.dataDevolucao) return false;
    return item.dataDevolucao < todayStr;
  };

  const renderStatusBadge = (item: Emprestimo) => {
    return (
      <div className="flex flex-wrap items-center gap-1.5">
        {item.status === 'Devolvido' ? (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Devolvido
          </span>
        ) : isAtrasado(item) ? (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30">
            <AlertCircle className="w-3.5 h-3.5" />
            Atrasado
          </span>
        ) : item.retirado ? (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/40">
            <ArrowDownToLine className="w-3.5 h-3.5 text-cyan-400" />
            Em Uso (Retirado)
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Clock className="w-3.5 h-3.5" />
            Agendado
          </span>
        )}

        {item.temAvaria && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            Avaria Registrada
          </span>
        )}
      </div>
    );
  };

  const parseDateToNumber = (dateStr?: string | null): number => {
    if (!dateStr) return 0;
    const s = String(dateStr).trim();
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(s)) {
      const [day, month, year] = s.split('/');
      return new Date(Number(year), Number(month) - 1, Number(day)).getTime();
    }
    if (/^\d{4}-\d{1,2}-\d{1,2}/.test(s)) {
      const [year, month, day] = s.split('-');
      return new Date(Number(year), Number(month) - 1, Number(day)).getTime();
    }
    const parsed = Date.parse(s);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Contagem de atrasados para o alerta na visão de hoje
  const totalAtrasadosGerais = useMemo(() => {
    if (viewMode === 'historico') return 0;
    return emprestimos.filter(i => isAtrasado(i)).length;
  }, [emprestimos, viewMode, todayStr]);

  // Filtragem e ordenação
  const filteredEmprestimos = useMemo(() => {
    const list = emprestimos.filter(item => {
      // 1. Separação Estrita entre Ativos e Histórico
      if (viewMode !== 'historico' && item.status === 'Devolvido') return false;
      if (viewMode === 'historico' && item.status !== 'Devolvido') return false;

      // 2. Filtro de Data para Agendamentos Ativos
      if (viewMode !== 'historico') {
        const itemDate = item.dataAgendamento || item.dataRetirada || item.dataDevolucao;

        if (showAtrasadosOverlay) {
          if (!isAtrasado(item)) return false;
        } else if (dateScope === 'hoje') {
          // Exibe os do dia de hoje (ou os que estejam atrasados se não devolvidos)
          if (itemDate !== todayStr && !isAtrasado(item)) return false;
        } else if (dateScope === 'amanha') {
          if (itemDate !== tomorrowStr) return false;
        } else if (dateScope === 'data') {
          if (itemDate !== selectedCustomDate) return false;
        }
        // Se 'todos', exibe todos os pendentes sem filtrar data
      }

      // 3. Busca por texto
      const matchesSearch = 
        (item.solicitante || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.equipamentoNome || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.turmaOuSala || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.contato || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.observacoes || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.avariaDescricao || '').toLowerCase().includes(searchTerm.toLowerCase());

      // 4. Filtro de Status
      let matchesStatus = true;
      if (statusFilter === 'AGENDADOS') {
        matchesStatus = item.status === 'Pendente' && !item.retirado && !isAtrasado(item);
      } else if (statusFilter === 'RETIRADOS') {
        matchesStatus = item.status === 'Pendente' && Boolean(item.retirado) && !isAtrasado(item);
      } else if (statusFilter === 'DEVOLVIDOS') {
        matchesStatus = item.status === 'Devolvido';
      } else if (statusFilter === 'ATRASADOS') {
        matchesStatus = isAtrasado(item);
      }

      // 5. Filtro de Tipo
      let matchesTipo = true;
      if (tipoFilter === 'individual') {
        matchesTipo = item.tipoEmprestimo !== 'kit' && !item.kitId;
      } else if (tipoFilter === 'kit') {
        matchesTipo = item.tipoEmprestimo === 'kit' || Boolean(item.kitId);
      }

      // 6. Filtro de Turno
      let matchesTurno = true;
      if (turnoFilter === 'manha') {
        matchesTurno = (item.turno || '').includes('manhã') || (item.aulas || []).some(a => a.startsWith('M'));
      } else if (turnoFilter === 'tarde') {
        matchesTurno = (item.turno || '').includes('tarde') || (item.aulas || []).some(a => a.startsWith('T'));
      }

      return matchesSearch && matchesStatus && matchesTipo && matchesTurno;
    });

    // Ordenação cronológica
    return list.sort((a, b) => {
      const primaryDateA = a.dataAgendamento || a.dataRetirada || a.dataDevolucao || a.dataDevolucaoReal || '';
      const primaryDateB = b.dataAgendamento || b.dataRetirada || b.dataDevolucao || b.dataDevolucaoReal || '';

      const timeA = parseDateToNumber(primaryDateA);
      const timeB = parseDateToNumber(primaryDateB);

      if (timeA !== timeB) {
        return sortOrder === 'desc' ? timeB - timeA : timeA - timeB;
      }

      const getLessonRank = (item: Emprestimo) => {
        if (!item.aulas || item.aulas.length === 0) return 0;
        const lastAula = [...item.aulas].sort().reverse()[0] || '';
        const num = parseInt(lastAula.replace(/\D/g, ''), 10) || 0;
        if (lastAula.startsWith('T')) return 100 + num;
        if (lastAula.startsWith('M')) return 50 + num;
        return num;
      };

      const rankA = getLessonRank(a);
      const rankB = getLessonRank(b);
      if (rankA !== rankB) {
        return sortOrder === 'desc' ? rankB - rankA : rankA - rankB;
      }

      const createdA = (a.createdAt as any)?.seconds 
        ? (a.createdAt as any).seconds * 1000 
        : (a.createdAt ? new Date(a.createdAt).getTime() : 0);
      const createdB = (b.createdAt as any)?.seconds 
        ? (b.createdAt as any).seconds * 1000 
        : (b.createdAt ? new Date(b.createdAt).getTime() : 0);

      return sortOrder === 'desc' ? createdB - createdA : createdA - createdB;
    });
  }, [emprestimos, viewMode, dateScope, selectedCustomDate, showAtrasadosOverlay, searchTerm, statusFilter, tipoFilter, turnoFilter, sortOrder, todayStr, tomorrowStr]);

  // Métricas
  const totalPendentes = emprestimos.filter(i => i.status === 'Pendente' && !isAtrasado(i)).length;
  const totalRetirados = emprestimos.filter(i => i.status === 'Pendente' && Boolean(i.retirado) && !isAtrasado(i)).length;
  const totalComAvaria = emprestimos.filter(i => i.temAvaria).length;

  return (
    <div className="space-y-6">
      {/* Barra de Navegação Principal: 3 Visões Claras e Otimizadas */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-sm">
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 w-fit flex-wrap gap-1">
          <button
            type="button"
            onClick={() => {
              setViewMode('painel_dia');
              setShowAtrasadosOverlay(false);
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              viewMode === 'painel_dia' 
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-extrabold' 
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>⚡ Emprestados Hoje (Painel Rápido)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('todos_agendamentos');
              setShowAtrasadosOverlay(false);
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              viewMode === 'todos_agendamentos' 
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-extrabold' 
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>📋 Todos os Agendamentos & Calendário</span>
          </button>
          
          <button
            type="button"
            onClick={() => {
              setViewMode('historico');
              setShowAtrasadosOverlay(false);
            }}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              viewMode === 'historico' 
                ? 'bg-slate-800 text-white shadow-md border border-slate-700 font-extrabold' 
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5 text-cyan-400" />
            <span>📜 Histórico (Devolvidos)</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {canManageRecurring && (
            <button
              type="button"
              onClick={() => setIsRecorrenciaModalOpen(true)}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 font-bold text-xs shadow-sm transition-all cursor-pointer"
              title="Gestão de séries fixas e agendamento recorrente"
            >
              <Repeat className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden sm:inline">Uso Fixo / Recorrente</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleOpenAddModal()}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>+ Novo Agendamento Rápido</span>
          </button>
        </div>
      </div>

      {viewMode === 'painel_dia' ? (
        <PainelEmprestadosAgora
          emprestimos={emprestimosParaPainel}
          todayStr={todayStr}
          canChangeStatus={canChangeStatus}
          onMarcarRetirada={handleToggleRetirada}
          onAbrirDevolucao={handleOpenDevolucaoModal}
          onVerDetalhes={setSelectedLoanForDetails}
          onNovoAgendamento={() => setIsRapidoModalOpen(true)}
        />
      ) : (
        <>
          {/* Cards de Indicadores de Empréstimos */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-sm">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  {viewMode === 'historico' ? 'Histórico Carregado' : 'Agendamentos Ativos'}
                </p>
                <p className="text-2xl sm:text-3xl font-bold text-white mt-1">{filteredEmprestimos.length}</p>
              </div>
              <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20">
                <ArrowRightLeft className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-sm">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Em Uso (Retirados)</p>
                <p className="text-2xl sm:text-3xl font-bold text-cyan-400 mt-1">{totalRetirados}</p>
              </div>
              <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20">
                <ArrowDownToLine className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-sm">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Aguardando Retirada</p>
                <p className="text-2xl sm:text-3xl font-bold text-amber-400 mt-1">{totalPendentes}</p>
              </div>
              <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
                <Clock className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-sm">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  {viewMode === 'historico' ? 'Avarias Registradas' : 'Atrasados'}
                </p>
                <p className={`text-2xl sm:text-3xl font-bold mt-1 ${
                  viewMode === 'historico' 
                    ? totalComAvaria > 0 ? 'text-rose-400' : 'text-emerald-400'
                    : totalAtrasadosGerais > 0 ? 'text-rose-400' : 'text-slate-400'
                }`}>
                  {viewMode === 'historico' ? totalComAvaria : totalAtrasadosGerais}
                </p>
              </div>
              <div className={`p-3 rounded-xl border ${
                (viewMode !== 'historico' && totalAtrasadosGerais > 0) || (viewMode === 'historico' && totalComAvaria > 0)
                  ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              }`}>
                {(viewMode !== 'historico' && totalAtrasadosGerais > 0) || (viewMode === 'historico' && totalComAvaria > 0) ? (
                  <AlertTriangle className="w-6 h-6" />
                ) : (
                  <CheckCircle2 className="w-6 h-6" />
                )}
              </div>
            </div>
          </div>

          {/* Painel Principal de Filtros & Ações */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
            
            {/* Cabeçalho e Seletor de Datas */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ArrowRightLeft className="w-5 h-5 text-cyan-400" />
                  {viewMode === 'historico' ? 'Histórico de Empréstimos Devolvidos' : 'Tabela de Agendamentos & Calendário'}
                </h2>
                <p className="text-xs text-slate-400">
                  {viewMode === 'historico' 
                    ? 'Registro auditável de devoluções com verificação de avarias' 
                    : 'Apenas agendamentos pendentes por dia. Clique em qualquer agendamento para ver os itens'}
                </p>
              </div>

              {/* Seletor de Datas Inteligente (Ativo na aba de Agendamentos) */}
              {viewMode !== 'historico' && (
                <div className="flex flex-wrap items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setDateScope('hoje');
                      setShowAtrasadosOverlay(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      dateScope === 'hoje' && !showAtrasadosOverlay
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span>Hoje ({todayStr.split('-').reverse().slice(0, 2).join('/')})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setDateScope('amanha');
                      setShowAtrasadosOverlay(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      dateScope === 'amanha' && !showAtrasadosOverlay
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <CalendarDays className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Amanhã</span>
                  </button>

                  <div className="flex items-center gap-1 pl-1">
                    <input
                      type="date"
                      value={selectedCustomDate}
                      onChange={(e) => {
                        setSelectedCustomDate(e.target.value);
                        setDateScope('data');
                        setShowAtrasadosOverlay(false);
                      }}
                      className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-400 cursor-pointer"
                      title="Escolher uma data específica para visualizar agendamentos"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setDateScope('todos');
                      setShowAtrasadosOverlay(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      dateScope === 'todos' && !showAtrasadosOverlay
                        ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Ver Todos os Dias
                  </button>
                </div>
              )}
            </div>

            {/* Alerta de Atrasados Pendentes de Dias Anteriores */}
            {viewMode !== 'historico' && totalAtrasadosGerais > 0 && dateScope === 'hoje' && (
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    Existem <strong>{totalAtrasadosGerais}</strong> agendamento(s) de datas anteriores ainda pendentes de devolução.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAtrasadosOverlay(!showAtrasadosOverlay)}
                  className="px-3 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold transition-colors cursor-pointer"
                >
                  {showAtrasadosOverlay ? 'Voltar para os de Hoje' : 'Exibir Atrasados Agora'}
                </button>
              </div>
            )}

        {/* Filtros Secundários de Busca, Turno, Tipo e Ordem */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2 border-t border-slate-800/80">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar professor, equipamento, turma..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="TODOS">Todos os Status</option>
              <option value="AGENDADOS">Agendados (Aguardando)</option>
              <option value="RETIRADOS">Em Uso (Retirados)</option>
              <option value="ATRASADOS">Atrasados</option>
              <option value="DEVOLVIDOS">Devolvidos</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Tipo:</span>
            <select
              value={tipoFilter}
              onChange={(e) => setTipoFilter(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="TODOS">Todos os Tipos</option>
              <option value="individual">Equipamento Individual</option>
              <option value="kit">Kits de Equipamentos</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Turno:</span>
            <select
              value={turnoFilter}
              onChange={(e) => setTurnoFilter(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="TODOS">Todos os Turnos</option>
              <option value="manha">Manhã (1ª a 7ª Aula)</option>
              <option value="tarde">Tarde (1ª a 7ª Aula)</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Ordem:</span>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as 'desc' | 'asc')}
              className="w-full px-3 py-2 bg-slate-950 border border-cyan-500/30 rounded-xl text-xs font-semibold text-cyan-300 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 cursor-pointer"
            >
              <option value="asc">Mais antigo primeiro (↑)</option>
              <option value="desc">Mais novo ao mais velho (↓)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Barra de Ações em Lote */}
      {selectedLoanIds.length > 0 && (
        <div className="sticky top-4 z-30 p-4 rounded-2xl bg-cyan-950/90 border border-cyan-500/40 shadow-xl backdrop-blur-md flex flex-wrap items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500 text-slate-950 font-bold">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">
                {selectedLoanIds.length} {selectedLoanIds.length === 1 ? 'agendamento selecionado' : 'agendamentos selecionados'}
              </p>
              <p className="text-xs text-cyan-200">
                Execute ações em lote sobre os registros selecionados
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {canChangeStatus && (
              <>
                <button
                  onClick={() => handleBatchMarcarRetirada(true)}
                  disabled={batchProcessing}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {batchProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ArrowDownToLine className="w-3.5 h-3.5" />}
                  <span>Marcar Retirada</span>
                </button>

                <button
                  onClick={() => handleBatchMarcarDevolvido('Devolvido')}
                  disabled={batchProcessing}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-md shadow-emerald-500/20 transition-all cursor-pointer disabled:opacity-50"
                >
                  {batchProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCheck className="w-3.5 h-3.5 stroke-[2.5]" />}
                  <span>Marcar Devolução</span>
                </button>
              </>
            )}

            {canDelete && (
              <button
                onClick={handleBatchExcluirEmprestimos}
                disabled={batchProcessing}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir Selecionados</span>
              </button>
            )}

            <button
              onClick={handleClearLoanSelection}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-all cursor-pointer"
            >
              Desmarcar
            </button>
          </div>
        </div>
      )}

      {/* Tabela de Agendamentos e Empréstimos */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-12 flex flex-col items-center justify-center text-slate-400 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            <p className="text-sm font-medium">
              {viewMode !== 'historico' ? 'Carregando agendamentos ativos...' : 'Carregando histórico de devolvidos...'}
            </p>
          </div>
        ) : filteredEmprestimos.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <ArrowRightLeft className="w-12 h-12 mx-auto text-slate-600 stroke-[1.5]" />
            <p className="text-base font-semibold text-slate-300">
              {viewMode !== 'historico' 
                ? dateScope === 'hoje' 
                  ? 'Nenhum agendamento ativo registrado para hoje.' 
                  : 'Nenhum agendamento ativo encontrado para o período selecionado.'
                : 'Nenhum empréstimo devolvido encontrado no histórico.'}
            </p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {viewMode !== 'historico' && dateScope === 'hoje' && (
                <span>Você pode alternar as opções acima para visualizar outros dias ou cadastrar um novo agendamento.</span>
              )}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-950/60 text-slate-400 text-xs uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-3 py-3.5 text-center w-10">
                    <input
                      type="checkbox"
                      title="Selecionar / Desmarcar todos os registros visíveis"
                      checked={
                        filteredEmprestimos.length > 0 &&
                        filteredEmprestimos.every(item => item.id && selectedLoanIds.includes(item.id))
                      }
                      onChange={() => handleSelectAllLoans(filteredEmprestimos)}
                      className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-cyan-400 focus:ring-offset-slate-900 cursor-pointer"
                    />
                  </th>
                  <th className="px-4 py-3.5">Status & Etapa</th>
                  <th className="px-4 py-3.5">Equipamento(s) Solicitado(s)</th>
                  <th className="px-4 py-3.5">Professor & Turma</th>
                  <th className="px-4 py-3.5">Data & Aulas</th>
                  <th className="px-4 py-3.5">
                    {canChangeStatus ? 'Retirada / Devolução' : 'Status'}
                  </th>
                  <th className="px-5 py-3.5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredEmprestimos.map((item) => {
                  const atraso = isAtrasado(item);
                  const isKit = item.tipoEmprestimo === 'kit' || Boolean(item.kitId);
                  const isLote = item.tipoEmprestimo === 'lote' || (item.itensEmprestados && item.itensEmprestados.length > 1);
                  const isChecked = item.id ? selectedLoanIds.includes(item.id) : false;
                  const aulasSummary = formatAulasSummary(item.aulas || []);
                  const isRetirado = Boolean(item.retirado || item.status === 'Devolvido');
                  const isDevolvido = item.status === 'Devolvido';

                  return (
                    <tr 
                      key={item.id} 
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isChecked ? 'bg-cyan-950/30' : atraso ? 'bg-rose-950/10' : ''
                      }`}
                    >
                      <td className="px-3 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => item.id && handleToggleSelectLoan(item.id)}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-cyan-400 focus:ring-offset-slate-900 cursor-pointer"
                        />
                      </td>

                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="space-y-1">
                          {renderStatusBadge(item)}
                          {item.recorrente && (
                            <div className="flex items-center gap-1 text-[10px] font-bold text-purple-300">
                              <Repeat className="w-3 h-3 text-purple-400" />
                              <span>Fixo Semanal</span>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Coluna de Equipamentos: Clicar abre a janela com a lista completa */}
                      <td 
                        className="px-4 py-4 font-medium text-white cursor-pointer group"
                        onClick={() => setSelectedLoanForDetails(item)}
                        title="Clique para abrir os detalhes e equipamentos deste agendamento"
                      >
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2 rounded-lg border mt-0.5 group-hover:scale-105 transition-transform ${
                            isKit 
                              ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400' 
                              : isLote
                              ? 'bg-purple-500/10 border-purple-500/30 text-purple-400'
                              : 'bg-slate-800 border-slate-700 text-blue-400'
                          }`}>
                            {isKit ? <Boxes className="w-4 h-4" /> : isLote ? <CheckSquare className="w-4 h-4" /> : <Package className="w-4 h-4" />}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-100 flex items-center gap-2 group-hover:text-cyan-300 transition-colors">
                              <span>{item.equipamentoNome || item.kitNome || 'Item não especificado'}</span>
                              {isKit && (
                                <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                                  KIT
                                </span>
                              )}
                              {isLote && !isKit && (
                                <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                                  MÚLTIPLOS ITENS
                                </span>
                              )}
                            </div>
                            
                            {item.itensEmprestados && item.itensEmprestados.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1">
                                {item.itensEmprestados.slice(0, 3).map((it, idx) => (
                                  <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300">
                                    {it.quantidade}x {it.nome}
                                  </span>
                                ))}
                                {item.itensEmprestados.length > 3 && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-300 font-bold">
                                    +{item.itensEmprestados.length - 3} mais
                                  </span>
                                )}
                              </div>
                            )}

                            {item.observacoes && (
                              <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                                {item.observacoes}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-4">
                        <div className="text-slate-100 font-medium flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          {item.solicitante}
                        </div>
                        {item.turmaOuSala && (
                          <div className="text-xs text-cyan-300 flex items-center gap-1 mt-0.5">
                            <School className="w-3 h-3 text-cyan-400" />
                            {item.turmaOuSala}
                          </div>
                        )}
                        {item.contato && !item.turmaOuSala && (
                          <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-slate-500" />
                            {item.contato}
                          </div>
                        )}
                      </td>

                      <td className="px-4 py-4 text-xs text-slate-300">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 font-medium text-slate-200">
                            <CalendarDays className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            <span>{formatDateBR(item.dataAgendamento || item.dataRetirada)}</span>
                          </div>

                          {(item.dataDevolucaoReal || item.dataDevolucao) && (
                            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium">
                              <span className="text-slate-500">Devol:</span>
                              <span>{formatDateBR(item.dataDevolucaoReal || item.dataDevolucao)}</span>
                            </div>
                          )}

                          <div className="pt-0.5">
                            <span className="inline-block px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-[11px] text-cyan-300 font-mono">
                              {aulasSummary}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Coluna de Ações de Retirada & Devolução */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        {canChangeStatus ? (
                          <div className="flex items-center gap-2">
                            <div className="inline-flex rounded-xl bg-slate-950 p-1 border border-slate-800 shadow-inner">
                              <button
                                type="button"
                                onClick={() => handleToggleRetirada(item)}
                                title={isRetirado ? "Retirada confirmada" : "Confirmar Retirada"}
                                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                  isRetirado
                                    ? 'bg-cyan-500 text-slate-950 shadow-sm font-extrabold'
                                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                                }`}
                              >
                                <ArrowDownToLine className="w-3.5 h-3.5" />
                                <span>Retirada</span>
                                {isRetirado && <Check className="w-3 h-3 stroke-[3]" />}
                              </button>

                              <button
                                type="button"
                                onClick={() => isDevolvido ? handleAvancarCiclo(item) : handleOpenDevolucaoModal(item)}
                                title={isDevolvido ? "Devolvido (clique para reabrir)" : "Registrar Devolução e Checar Avarias"}
                                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                  isDevolvido
                                    ? 'bg-emerald-500 text-slate-950 shadow-sm font-extrabold'
                                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                                }`}
                              >
                                <ArrowUpFromLine className="w-3.5 h-3.5" />
                                <span>Devolução</span>
                                {isDevolvido && <Check className="w-3 h-3 stroke-[3]" />}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-col gap-1 items-start">
                            {isDevolvido ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                                <CheckCheck className="w-3.5 h-3.5 text-emerald-400 stroke-[2.5]" />
                                <span>Devolvido</span>
                              </span>
                            ) : isRetirado ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold">
                                <ArrowDownToLine className="w-3.5 h-3.5 text-cyan-400" />
                                <span>Em uso (Retirado)</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700/80 text-slate-300 text-xs font-medium">
                                <Clock className="w-3.5 h-3.5 text-amber-400" />
                                <span>Aguardando Retirada</span>
                              </span>
                            )}
                          </div>
                        )}
                      </td>

                      {/* Coluna de Ações: Botão Ver Detalhes (todos) e Botão Editar (Apenas Administradores - Oculto para Professor) */}
                      <td className="px-5 py-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setSelectedLoanForDetails(item)}
                            title="Ver Equipamentos e Detalhes"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => handleOpenEditModal(item)}
                              title="Editar Agendamento"
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => setItemToDelete(item)}
                              title="Excluir Registro"
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Rodapé do Histórico com Paginação Preguiçosa (Lazy Loading) */}
        {viewMode === 'historico' && !loading && (
          <div className="p-4 bg-slate-950/70 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
            <div>
              <span>Exibindo os <strong>{filteredEmprestimos.length}</strong> empréstimos devolvidos mais recentes.</span>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setHistoricoLimit(prev => prev + 20)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                <span>Carregar mais 20 empréstimos (+20)</span>
              </button>

              <button
                type="button"
                onClick={() => setHistoricoLimit(1000)}
                className="px-3.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold transition-colors cursor-pointer"
              >
                Carregar Todos os Devolvidos
              </button>
            </div>
          </div>
        )}
      </div>
      </>
      )}

      {/* Modal de Criação / Edição de Empréstimo */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5 text-cyan-400" />
                {editingItem ? 'Editar Agendamento de Empréstimo' : 'Novo Agendamento / Empréstimo de Equipamentos'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-6 space-y-5 max-h-[85vh] overflow-y-auto">
              
              {/* Modo de Escolha de Equipamento */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Como deseja selecionar os equipamentos? *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setFormData(prev => ({
                        ...prev,
                        tipoEmprestimo: 'lote'
                      }));
                    }}
                    className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      formData.tipoEmprestimo === 'lote'
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-500/10 ring-1 ring-cyan-500/40'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <CheckSquare className="w-4 h-4 text-cyan-400" />
                    <span>Caixas de Seleção (Vários)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setFormData(prev => ({
                        ...prev,
                        tipoEmprestimo: 'individual',
                        kitId: '',
                        kitNome: '',
                        equipamentoId: prev.equipamentoId || equipamentosAptos[0]?.id || '',
                        equipamentoNome: prev.equipamentoNome || (equipamentosAptos[0] ? `${equipamentosAptos[0].nome}${equipamentosAptos[0].patrimonio ? ` (Patr: ${equipamentosAptos[0].patrimonio})` : ''}` : '')
                      }));
                    }}
                    className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      formData.tipoEmprestimo === 'individual'
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-500/10 ring-1 ring-cyan-500/40'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Package className="w-4 h-4 text-blue-400" />
                    <span>Equipamento Único</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const firstKit = kits[0];
                      setFormData(prev => ({
                        ...prev,
                        tipoEmprestimo: 'kit',
                        kitId: firstKit ? firstKit.id : '',
                        kitNome: firstKit ? firstKit.nome : '',
                        equipamentoId: firstKit ? firstKit.id : 'kit',
                        equipamentoNome: firstKit ? `[KIT] ${firstKit.nome} (${firstKit.totalItens} itens)` : '',
                        selectedEquipamentos: firstKit ? firstKit.itens : []
                      }));
                    }}
                    className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      formData.tipoEmprestimo === 'kit'
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-500/10 ring-1 ring-cyan-500/40'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Boxes className="w-4 h-4 text-cyan-400" />
                    <span>Kit Pronto</span>
                  </button>
                </div>
              </div>

              {/* Seletor dinâmico */}
              {formData.tipoEmprestimo === 'lote' ? (
                <div>
                  <MultiEquipamentoSelector
                    equipamentos={equipamentosAptos}
                    selectedItems={formData.selectedEquipamentos}
                    indisponibilidadeMap={indisponibilidadeMapForm}
                    onChange={(updated) => setFormData(prev => ({ ...prev, selectedEquipamentos: updated }))}
                  />
                </div>
              ) : formData.tipoEmprestimo === 'kit' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Selecione o Kit Desejado *
                  </label>
                  {kits.length === 0 ? (
                    <p className="text-xs text-amber-400 p-3 bg-amber-500/10 rounded-xl border border-amber-500/20">
                      Nenhum kit cadastrado no sistema ainda.
                    </p>
                  ) : (
                    <select
                      value={formData.kitId}
                      onChange={handleKitSelectChange}
                      required
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                    >
                      <option value="">-- Escolha um Kit --</option>
                      {kits.map(k => {
                        const hasConflictItem = k.itens?.some(it => it.equipamentoId && indisponibilidadeMapForm.has(it.equipamentoId));
                        return (
                          <option key={k.id} value={k.id} disabled={hasConflictItem}>
                            {hasConflictItem ? '🚫 [INDISPONÍVEL] ' : ''}{k.nome} ({k.totalItens} itens) - {k.categoria || 'Geral'} {hasConflictItem ? '(Contém item ocupado)' : ''}
                          </option>
                        );
                      })}
                    </select>
                  )}
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Selecione o Equipamento *
                  </label>
                  <select
                    value={formData.equipamentoId}
                    onChange={handleEquipamentoSelectChange}
                    required
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  >
                    <option value="">-- Escolha um Equipamento --</option>
                    {equipamentosAptos.map(eq => {
                      const indisponivel = eq.id ? indisponibilidadeMapForm.get(eq.id) : undefined;
                      return (
                        <option key={eq.id} value={eq.id} disabled={Boolean(indisponivel)}>
                          {indisponivel ? '🚫 [INDISPONÍVEL] ' : ''}{eq.nome} {eq.patrimonio ? `(Patr: ${eq.patrimonio})` : ''} - {eq.categoria || 'Geral'} {indisponivel ? `(Agendado com ${indisponivel.conflito.solicitante})` : ''}
                        </option>
                      );
                    })}
                  </select>
                  {formData.equipamentoId && indisponibilidadeMapForm.has(formData.equipamentoId) && (
                    <div className="mt-2 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>
                        Este equipamento já possui agendamento com <strong>{indisponibilidadeMapForm.get(formData.equipamentoId)?.conflito.solicitante}</strong> neste mesmo horário. Escolha outro item disponível.
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Informações do Solicitante */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Professor / Solicitante *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Nome do Professor"
                    value={formData.solicitante}
                    onChange={(e) => setFormData({ ...formData, solicitante: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Turma / Sala de Aula
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: 3º Ano A, Lab 02"
                    value={formData.turmaOuSala}
                    onChange={(e) => setFormData({ ...formData, turmaOuSala: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Contato / Ramal
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: (11) 99999-9999"
                    value={formData.contato}
                    onChange={(e) => setFormData({ ...formData, contato: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>
              </div>

              {/* Data e Aulas */}
              <div className="space-y-3 p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                      Data de Retirada e Devolução *
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.dataRetirada}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        dataRetirada: e.target.value,
                        dataDevolucao: e.target.value,
                        dataAgendamento: e.target.value
                      })}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                    />
                  </div>

                  <div className="flex items-end gap-2">
                    <button
                      type="button"
                      onClick={handleSelectAllMorning}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs text-amber-300 font-semibold transition-colors cursor-pointer"
                    >
                      Toda a Manhã (M1-M7)
                    </button>
                    <button
                      type="button"
                      onClick={handleSelectAllAfternoon}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs text-cyan-300 font-semibold transition-colors cursor-pointer"
                    >
                      Toda a Tarde (T1-T7)
                    </button>
                    <button
                      type="button"
                      onClick={handleClearAulas}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs text-slate-400 transition-colors cursor-pointer"
                    >
                      Limpar
                    </button>
                  </div>
                </div>

                {/* Grade de Aulas */}
                <div className="pt-2">
                  <span className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Marque as aulas desejadas:
                  </span>
                  <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
                    {ALL_AULAS.map((aula) => {
                      const isSelected = formData.aulas.includes(aula.id);
                      return (
                        <button
                          key={aula.id}
                          type="button"
                          onClick={() => handleToggleAula(aula.id)}
                          className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-500 border-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                          }`}
                        >
                          <div className="text-xs">{aula.id}</div>
                          <div className="text-[9px] opacity-80">{aula.horario.split(' - ')[0]}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Recorrência (se for criação e tiver permissão) */}
              {!editingItem && canManageRecurring && (
                <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <label 
                      className="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-purple-200 select-none"
                      onClick={() => setFormData({ ...formData, isRecorrente: !formData.isRecorrente })}
                    >
                      {formData.isRecorrente ? (
                        <CheckSquare className="w-4 h-4 text-purple-400" />
                      ) : (
                        <div className="w-4 h-4 rounded border border-purple-500/40 bg-slate-950"></div>
                      )}
                      <span>Repetir este agendamento semanalmente (Recorrência)</span>
                    </label>
                  </div>

                  {formData.isRecorrente && (
                    <div className="space-y-3 pt-2 border-t border-purple-500/20">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                          Dias da Semana para Repetir:
                        </label>
                        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                          {DIAS_SEMANA_OPCOES.map((dia) => {
                            const isSelected = formData.diasSemana.includes(dia.id);
                            return (
                              <button
                                type="button"
                                key={dia.id}
                                onClick={() => toggleDiaSemanaForm(dia.id)}
                                className={`p-2 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                                  isSelected
                                    ? 'bg-purple-500/30 border-purple-500 text-purple-200 shadow-sm'
                                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                                }`}
                              >
                                {dia.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Data de Término da Recorrência *
                        </label>
                        <input
                          type="date"
                          required={formData.isRecorrente}
                          min={formData.dataRetirada}
                          value={formData.dataFimRecorrencia}
                          onChange={(e) => setFormData({ ...formData, dataFimRecorrencia: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Observações */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Observações / Finalidade Pedagógica
                </label>
                <textarea
                  rows={2}
                  placeholder="Ex: Apresentação de seminário com projetor e caixa de som."
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400 resize-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-sm font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={salvando}
                  className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-sm font-bold shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {salvando && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>{editingItem ? 'Salvar Alterações' : formData.isRecorrente ? `Confirmar ${datasRecorrentesGeradas.length} Agendamentos` : 'Confirmar Agendamento'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DE DETALHES DO AGENDAMENTO (EQUIPAMENTOS COMPLETOS) */}
      <DetalhesAgendamentoModal
        isOpen={Boolean(selectedLoanForDetails)}
        onClose={() => setSelectedLoanForDetails(null)}
        emprestimo={selectedLoanForDetails}
        equipamentos={equipamentos}
        canChangeStatus={canChangeStatus}
        onOpenDevolucao={(item) => handleOpenDevolucaoModal(item)}
        onToggleRetirada={(item) => handleToggleRetirada(item)}
      />

      {/* MODAL DE DEVOLUÇÃO COM REGISTRO DE AVARIAS */}
      <DevolucaoAvariaModal
        isOpen={Boolean(itemParaDevolucao)}
        onClose={() => setItemParaDevolucao(null)}
        emprestimo={itemParaDevolucao}
        onConfirm={handleConfirmDevolucaoComAvaria}
        loading={loadingDevolucao}
      />

      {/* MODAL DEDICADO DE RECORRÊNCIA / SÉRIES FIXAS */}
      {isRecorrenciaModalOpen && (
        <RecorrenciaModal
          isOpen={isRecorrenciaModalOpen}
          onClose={() => setIsRecorrenciaModalOpen(false)}
          userRole={userRole}
          equipamentos={equipamentos}
          kits={kits}
          emprestimos={emprestimos}
        />
      )}

      {/* Modal de Confirmação de Exclusão */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-xl border border-rose-500/20">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-white">Excluir Registro de Empréstimo?</h3>
                <p className="text-xs text-slate-400">Esta ação apagará permanentemente este agendamento.</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-300 space-y-1">
              <p><strong className="text-white">{itemToDelete.equipamentoNome || itemToDelete.kitNome}</strong></p>
              <p className="text-xs text-slate-400">Solicitante: {itemToDelete.solicitante}</p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm font-medium transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={excluindo}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-sm font-bold shadow-lg shadow-rose-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {excluindo && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Excluir</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE AGENDAMENTO RÁPIDO & INTELIGENTE */}
      <AgendamentoRapidoModal
        isOpen={isRapidoModalOpen}
        onClose={() => {
          setIsRapidoModalOpen(false);
          if (onClearInitialEquipamento) onClearInitialEquipamento();
        }}
        equipamentos={equipamentos}
        kits={kits}
        emprestimos={emprestimos}
        currentUserName={currentUserName}
        initialEquipamento={initialEquipamento}
        onConfirm={handleConfirmRapido}
        loading={salvando}
      />
    </div>
  );
}
