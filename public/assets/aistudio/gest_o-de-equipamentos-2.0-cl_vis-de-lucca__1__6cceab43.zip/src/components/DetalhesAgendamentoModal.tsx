import React from 'react';
import { Emprestimo, Equipamento, KitItem } from '../types';
import { formatAulasSummary, AULAS_MANHA, AULAS_TARDE } from '../lib/schoolSchedule';
import { 
  X, 
  Package, 
  Boxes, 
  CheckSquare, 
  CalendarDays, 
  Clock, 
  User, 
  School, 
  Phone, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowDownToLine, 
  ArrowUpFromLine, 
  Check, 
  FileText,
  MapPin,
  Tag
} from 'lucide-react';

interface DetalhesAgendamentoModalProps {
  isOpen: boolean;
  onClose: () => void;
  emprestimo: Emprestimo | null;
  equipamentos: Equipamento[];
  canChangeStatus?: boolean;
  onOpenDevolucao?: (emprestimo: Emprestimo) => void;
  onToggleRetirada?: (emprestimo: Emprestimo) => void;
}

export default function DetalhesAgendamentoModal({
  isOpen,
  onClose,
  emprestimo,
  equipamentos,
  canChangeStatus = false,
  onOpenDevolucao,
  onToggleRetirada
}: DetalhesAgendamentoModalProps) {
  if (!isOpen || !emprestimo) return null;

  const formatDateBR = (dateStr?: string | null) => {
    if (!dateStr) return 'Não informada';
    if (dateStr.includes('/')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  const isKit = emprestimo.tipoEmprestimo === 'kit' || Boolean(emprestimo.kitId);
  const isLote = emprestimo.tipoEmprestimo === 'lote' || (emprestimo.itensEmprestados && emprestimo.itensEmprestados.length > 1);
  const isRetirado = Boolean(emprestimo.retirado || emprestimo.status === 'Devolvido');
  const isDevolvido = emprestimo.status === 'Devolvido';

  // Obter lista de itens detalhados
  const itens: KitItem[] = emprestimo.itensEmprestados && emprestimo.itensEmprestados.length > 0
    ? emprestimo.itensEmprestados
    : [{
        equipamentoId: emprestimo.equipamentoId || '',
        nome: emprestimo.equipamentoNome || 'Equipamento',
        quantidade: emprestimo.quantidadeTotal || 1,
        categoria: 'Geral',
        patrimonio: null
      }];

  // Buscar detalhes complementares do inventário
  const getEquipamentoDetalhes = (eqId?: string) => {
    if (!eqId) return null;
    return equipamentos.find(e => e.id === eqId);
  };

  // Mapear detalhes de cada aula
  const getAulaInfo = (aulaCode: string) => {
    const all = [...AULAS_MANHA, ...AULAS_TARDE];
    const found = all.find(a => a.id === aulaCode);
    return found ? `${found.label} (${found.horario})` : aulaCode;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header do Modal */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl border ${
              isKit 
                ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400' 
                : isLote
                ? 'bg-purple-500/10 border-purple-500/30 text-purple-400'
                : 'bg-blue-500/10 border-blue-500/30 text-blue-400'
            }`}>
              {isKit ? <Boxes className="w-5 h-5" /> : isLote ? <CheckSquare className="w-5 h-5" /> : <Package className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                Detalhes do Agendamento & Equipamentos
              </h3>
              <p className="text-xs text-slate-400">
                {isKit ? 'Kit Completo de Equipamentos' : isLote ? 'Conjunto de Múltiplos Equipamentos' : 'Equipamento Individual'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Conteúdo */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">

          {/* Status Geral e Prazos */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Status Geral</span>
              <div className="pt-0.5">
                {isDevolvido ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Devolvido
                  </span>
                ) : isRetirado ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold">
                    <ArrowDownToLine className="w-3.5 h-3.5 text-cyan-400" />
                    Em Uso (Retirado)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    Aguardando Retirada
                  </span>
                )}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Data de Uso</span>
              <div className="flex items-center gap-1.5 text-sm font-bold text-white pt-0.5">
                <CalendarDays className="w-4 h-4 text-cyan-400" />
                <span>{formatDateBR(emprestimo.dataAgendamento || emprestimo.dataRetirada)}</span>
              </div>
              {emprestimo.dataDevolucaoReal && (
                <p className="text-[11px] text-emerald-400 font-medium">
                  Devolvido em: {formatDateBR(emprestimo.dataDevolucaoReal)}
                </p>
              )}
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Turno & Aulas</span>
              <p className="text-xs font-bold text-cyan-300 capitalize">
                {emprestimo.turno || 'Não informado'}
              </p>
              <p className="text-xs text-slate-300 font-mono">
                {formatAulasSummary(emprestimo.aulas || [])}
              </p>
            </div>
          </div>

          {/* Alerta de Avaria (Se houver) */}
          {emprestimo.temAvaria && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-200 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>Registro de Avaria / Dano no Equipamento</span>
              </div>
              <p className="text-xs text-rose-100 bg-rose-950/60 p-3 rounded-xl border border-rose-500/20 whitespace-pre-wrap">
                {emprestimo.avariaDescricao || 'Avaria não descrita em detalhes.'}
              </p>
              <div className="flex flex-wrap items-center justify-between text-[11px] text-rose-300/80 pt-1">
                <span>Registrado por: <strong>{emprestimo.avariaRegistradaPor || 'Operador'}</strong></span>
                {emprestimo.avariaData && <span>Data do Registro: {formatDateBR(emprestimo.avariaData)}</span>}
                {emprestimo.equipamentoEstadoDevolucao && (
                  <span>Novo Estado: <strong className="text-rose-200">{emprestimo.equipamentoEstadoDevolucao}</strong></span>
                )}
              </div>
            </div>
          )}

          {/* Tabela de Equipamentos do Agendamento */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Package className="w-4 h-4 text-cyan-400" />
                Equipamentos Solicitados ({itens.length} {itens.length === 1 ? 'item' : 'itens'})
              </h4>
              <span className="text-xs text-slate-400">
                Total de peças: <strong>{emprestimo.quantidadeTotal || itens.reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0)}</strong>
              </span>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden divide-y divide-slate-800/80">
              {itens.map((item, idx) => {
                const eqCadastrado = getEquipamentoDetalhes(item.equipamentoId);

                return (
                  <div key={idx} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-900/50 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-cyan-400 mt-0.5">
                        <Package className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-white text-sm flex items-center gap-2">
                          <span>{item.nome}</span>
                          <span className="text-xs px-2 py-0.5 rounded-md bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-bold">
                            {item.quantidade}x
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                          {item.patrimonio && (
                            <span className="flex items-center gap-1 text-slate-300">
                              <Tag className="w-3 h-3 text-slate-500" />
                              Patrimônio: <strong>{item.patrimonio}</strong>
                            </span>
                          )}
                          {item.categoria && (
                            <span className="text-slate-400">
                              Categoria: {item.categoria}
                            </span>
                          )}
                          {eqCadastrado?.localizacao && (
                            <span className="flex items-center gap-1 text-slate-400">
                              <MapPin className="w-3 h-3 text-slate-500" />
                              {eqCadastrado.localizacao}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="sm:text-right">
                      <span className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-lg border ${
                        eqCadastrado?.estadoConservacao === 'Novo' || eqCadastrado?.estadoConservacao === 'Bom'
                          ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                          : eqCadastrado?.estadoConservacao === 'Precisa de Reparo'
                          ? 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}>
                        Estado: {eqCadastrado?.estadoConservacao || 'Operacional'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Dados do Solicitante e Turma */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-cyan-400" />
              Dados do Solicitante / Professor
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-slate-400">Professor / Solicitante:</span>
                <p className="font-bold text-white text-sm mt-0.5">{emprestimo.solicitante}</p>
              </div>

              {emprestimo.turmaOuSala && (
                <div>
                  <span className="text-slate-400">Turma / Sala de Aula:</span>
                  <p className="font-bold text-cyan-300 text-sm mt-0.5 flex items-center gap-1">
                    <School className="w-3.5 h-3.5 text-cyan-400" />
                    {emprestimo.turmaOuSala}
                  </p>
                </div>
              )}

              {emprestimo.contato && (
                <div>
                  <span className="text-slate-400">Contato / Ramal:</span>
                  <p className="font-bold text-slate-200 text-sm mt-0.5 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    {emprestimo.contato}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Detalhes dos Horários das Aulas */}
          {emprestimo.aulas && emprestimo.aulas.length > 0 && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                Horários das Aulas Agendadas
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                {emprestimo.aulas.map((aulaCode) => (
                  <div key={aulaCode} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-cyan-300">{aulaCode}</span>
                    <span className="text-slate-300">{getAulaInfo(aulaCode)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Observações e Finalidade */}
          {emprestimo.observacoes && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                Observações / Finalidade Pedagógica
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                {emprestimo.observacoes}
              </p>
            </div>
          )}
        </div>

        {/* Rodapé / Ações */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            {canChangeStatus && !isDevolvido && onOpenDevolucao && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenDevolucao(emprestimo);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-md shadow-emerald-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowUpFromLine className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Registrar Devolução / Avaria</span>
              </button>
            )}

            {canChangeStatus && !isRetirado && onToggleRetirada && (
              <button
                type="button"
                onClick={() => {
                  onToggleRetirada(emprestimo);
                  onClose();
                }}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md shadow-cyan-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowDownToLine className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Confirmar Retirada</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
          >
            Fechar Janela
          </button>
        </div>
      </div>
    </div>
  );
}
