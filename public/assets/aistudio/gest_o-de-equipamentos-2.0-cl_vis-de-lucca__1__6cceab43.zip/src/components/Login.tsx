import React, { useState } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  serverTimestamp 
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import firebaseConfig from '../../firebase-applet-config.json';
import { 
  SUPER_ADMIN_DEFAULT_PASSWORD,
  isSuperAdminEmail,
  cleanUsername,
  usernameToAuthEmail
} from '../lib/userRoles';
import { 
  Lock, 
  User as UserIcon, 
  Eye, 
  EyeOff, 
  Package, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  ArrowRight,
  Database,
  ShieldCheck,
  UserPlus
} from 'lucide-react';

export default function Login() {
  const [usernameInput, setUsernameInput] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isResetMode, setIsResetMode] = useState(false);

  // Traduz mensagens de erro do Firebase Auth
  const formatFirebaseAuthError = (errorCode: string) => {
    switch (errorCode) {
      case 'auth/invalid-email':
        return 'Nome de usuário inválido.';
      case 'auth/user-not-found':
        return 'Usuário não encontrado. Se for o primeiro acesso, clique em "Cadastrar Novo Usuário".';
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
      case 'auth/invalid-login-credentials':
        return 'Senha incorreta para este usuário. Verifique e tente novamente.';
      case 'auth/email-already-in-use':
        return 'Este usuário já está cadastrado no sistema.';
      case 'auth/weak-password':
        return 'A senha deve conter no mínimo 6 caracteres.';
      case 'auth/too-many-requests':
        return 'Muitas tentativas sem sucesso. Aguarde alguns instantes e tente novamente.';
      case 'auth/network-request-failed':
        return 'Falha de conexão com o servidor. Verifique sua internet.';
      default:
        return `Erro de autenticação (${errorCode}). Tente novamente.`;
    }
  };

  // Garante que o documento do usuário exista e esteja sincronizado no Firestore
  const ensureUserDocExists = async (
    uid: string, 
    userEmail: string, 
    usernameVal: string, 
    customPerfil?: string, 
    customNome?: string
  ) => {
    try {
      const userRef = doc(db, 'usuarios', uid);
      const snap = await getDoc(userRef);
      const isSuper = isSuperAdminEmail(userEmail) || isSuperAdminEmail(usernameVal);

      const effectivePerfil = isSuper ? 'adm_total' : (customPerfil || 'padrao');
      const effectiveNome = customNome || (isSuper ? 'Rodrigo Guergolet' : usernameVal);

      if (!snap.exists()) {
        await setDoc(userRef, {
          uid,
          usuario: cleanUsername(usernameVal),
          email: userEmail.toLowerCase(),
          nome: effectiveNome,
          perfil: effectivePerfil,
          status: 'ativo',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      } else if (isSuper && snap.data()?.perfil !== 'adm_total') {
        await setDoc(userRef, {
          perfil: 'adm_total',
          updatedAt: serverTimestamp()
        }, { merge: true });
      }
    } catch (err) {
      console.warn('Aviso ao sincronizar documento de usuário no Firestore:', err);
    }
  };

  // Localiza e-mail associado ao nome de usuário
  const resolveEmailForUsername = async (rawInput: string): Promise<{ email: string; username: string }> => {
    const trimmed = rawInput.trim();
    const cleanUser = cleanUsername(trimmed);

    // Se o usuário digitou diretamente um email
    if (trimmed.includes('@')) {
      return { email: trimmed.toLowerCase(), username: cleanUsername(trimmed.split('@')[0]) };
    }

    // Busca no Firestore se já existe um usuário cadastrado com esse username
    try {
      const usersRef = collection(db, 'usuarios');
      const q = query(usersRef, where('usuario', '==', cleanUser));
      const snap = await getDocs(q);

      if (!snap.empty) {
        const foundDoc = snap.docs[0].data();
        if (foundDoc.email) {
          return { email: foundDoc.email.toLowerCase(), username: cleanUser };
        }
      }
    } catch (e) {
      console.warn('Busca de usuário por username:', e);
    }

    // Padrão de conversão de username para autenticação
    const generatedEmail = usernameToAuthEmail(cleanUser);
    return { email: generatedEmail, username: cleanUser };
  };

  // Executa autenticação ou auto-criação se for primeira inicialização
  const handleAuth = async (rawUsername: string, pass: string) => {
    const { email: authEmail, username: cleanUser } = await resolveEmailForUsername(rawUsername);
    const isSuper = isSuperAdminEmail(cleanUser) || isSuperAdminEmail(authEmail);

    try {
      // 1. Tentar Login
      const cred = await signInWithEmailAndPassword(auth, authEmail, pass);
      await ensureUserDocExists(cred.user.uid, authEmail, cleanUser);
      return cred;
    } catch (signInErr: any) {
      // 2. Se for super admin ou primeiro acesso e o usuário não existe no Auth, cria automaticamente
      if (
        (isSuper || isRegistering) &&
        (signInErr.code === 'auth/user-not-found' ||
         signInErr.code === 'auth/invalid-credential' ||
         signInErr.code === 'auth/invalid-login-credentials')
      ) {
        try {
          const newCred = await createUserWithEmailAndPassword(auth, authEmail, pass);
          await ensureUserDocExists(
            newCred.user.uid, 
            authEmail, 
            cleanUser, 
            isSuper ? 'adm_total' : 'padrao',
            isSuper ? 'Rodrigo Guergolet' : cleanUser
          );
          return newCred;
        } catch (createErr: any) {
          if (createErr.code === 'auth/email-already-in-use') {
            throw new Error('Usuário existente. A senha informada está incorreta.');
          }
          throw createErr;
        }
      }
      throw signInErr;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanInput = usernameInput.trim();

    if (!cleanInput || (!isResetMode && !password)) {
      setErrorMsg('Por favor, preencha o nome de usuário e a senha.');
      return;
    }

    setLoading(true);

    try {
      if (isResetMode) {
        const { email: targetEmail } = await resolveEmailForUsername(cleanInput);
        await sendPasswordResetEmail(auth, targetEmail);
        setSuccessMsg(`Instruções de recuperação enviadas para o e-mail cadastrado de "${cleanInput}".`);
        setIsResetMode(false);
      } else if (isRegistering) {
        const { email: targetEmail, username: cleanUser } = await resolveEmailForUsername(cleanInput);
        const cred = await createUserWithEmailAndPassword(auth, targetEmail, password);
        await ensureUserDocExists(cred.user.uid, targetEmail, cleanUser);
        setSuccessMsg('Usuário criado com sucesso! Conectando ao sistema...');
      } else {
        await handleAuth(cleanInput, password);
      }
    } catch (err: any) {
      console.error('Erro de autenticação:', err);
      setErrorMsg(err.message || formatFirebaseAuthError(err.code));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 text-slate-100 relative">
      {/* Background Iluminação Suave */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 backdrop-blur-xl space-y-6">
        
        {/* Cabeçalho do Card */}
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/20 mb-3 ring-4 ring-slate-800">
            <Package className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Gestão de Equipamentos
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Controle de inventário físico e fluxo de empréstimos
          </p>
        </div>

        {/* Mensagens de Alerta */}
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Formulário de Login por Usuário */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Usuário
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <UserIcon className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value)}
                placeholder="Digite seu nome de usuário (ex: rodrigo.guergolet)"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                autoCapitalize="none"
                autoCorrect="off"
                autoComplete="username"
              />
            </div>
          </div>

          {!isResetMode && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  Senha
                </label>
                {!isRegistering && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsResetMode(true);
                      setErrorMsg('');
                      setSuccessMsg('');
                    }}
                    className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    Esqueceu a senha?
                  </button>
                )}
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer mt-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Autenticando...</span>
              </>
            ) : isResetMode ? (
              <>
                <span>Recuperar Acesso</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : isRegistering ? (
              <>
                <span>Cadastrar Usuário e Entrar</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>Entrar no Sistema</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Alternar entre Entrar e Cadastrar */}
        {!isResetMode && (
          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={() => {
                setIsRegistering(!isRegistering);
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className="text-xs text-slate-400 hover:text-cyan-400 transition-colors inline-flex items-center gap-1.5"
            >
              {isRegistering ? (
                <>
                  <span>Já possui um usuário cadastrado?</span>
                  <span className="font-semibold text-cyan-400 underline">Fazer Login</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Primeiro acesso ou novo cadastro?</span>
                  <span className="font-semibold text-cyan-400 underline">Criar Conta</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Rodapé: Status do Firebase e Voltar se no Reset */}
        <div className="pt-3 border-t border-slate-800/80 space-y-2">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-[11px]">
            <div className="flex items-center gap-2 text-slate-300">
              <Database className="w-4 h-4 text-cyan-400 shrink-0" />
              <div>
                <span className="font-semibold text-white">Firebase:</span>{' '}
                <span className="text-emerald-400 font-mono">Conectado</span>
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">
              {firebaseConfig.projectId}
            </span>
          </div>

          {isResetMode && (
            <button
              type="button"
              onClick={() => {
                setIsResetMode(false);
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className="w-full text-center text-xs text-slate-400 hover:text-white transition-colors"
            >
              ← Voltar para o Login
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
