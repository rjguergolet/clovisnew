import React, { useState, useMemo } from 'react';
import { Emprestimo } from '../types';
import { formatAulasSummary } from '../lib/schoolSchedule';
import { 
  ArrowDownToLine, 
  ArrowUpFromLine, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Search, 
  X, 
  Boxes, 
  Package, 
  CheckSquare, 
  User, 
  School, 
  Plus, 
  Eye, 
  CalendarDays,
  Sparkles,
  Phone,
  Laptop,
  CheckCheck
} from 'lucide-react';

interface PainelEmprestadosAgoraProps {
  emprestimos: Emprestimo[];
  todayStr: string;
  canChangeStatus: boolean;
  onMarcarRetirada: (loan: Emprestimo) => void;
  onAbrirDevolucao: (loan: Emprestimo) => void;
  onVerDetalhes: (loan: Emprestimo) => void;
  onNovoAgendamento: () => void;
}

export default function PainelEmprestadosAgora({
  emprestimos,
  todayStr,
  canChangeStatus,
  onMarcarRetirada,
  onAbrirDevolucao,
  onVerDetalhes,
  onNovoAgendamento
}: PainelEmprestadosAgoraProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filtroSecao, setFiltroSecao] = useState<'todos' | 'em_uso' | 'aguardando' | 'atrasados'>('todos');

  // Classificação dos empréstimos para a rotina diária
  const { emUsoAgora, aguardandoRetiradaHoje, atrasados, devolvidosHoje } = useMemo(() => {
    const emUso: Emprestimo[] = [];
    const aguardando: Emprestimo[] = [];
    const atras: Emprestimo[] = [];
    const devolvidos: Emprestimo[] = [];

    emprestimos.forEach(item => {
      const dataItem = item.dataAgendamento || item.dataRetirada || item.dataDevolucao;

      if (item.status === 'Devolvido') {
        if (item.dataDevolucaoReal === todayStr || dataItem === todayStr) {
          devolvidos.push(item);
        }
        return;
      }

      // Se ainda está pendente de devolução:
      const dataDevol = item.dataDevolucao || item.dataRetirada;
      const isAtrasado = dataDevol && dataDevol < todayStr;

      if (isAtrasado) {
        atras.push(item);
      } else if (item.retirado) {
        // Está retirado com o professor agora
        emUso.push(item);
      } else if (dataItem === todayStr) {
        // Agendado para hoje e aguardando retirada
        aguardando.push(item);
      }
    });

    return {
      emUsoAgora: emUso,
      aguardandoRetiradaHoje: aguardando,
      atrasados: atras,
      devolvidosHoje: devolvidos
    };
  }, [emprestimos, todayStr]);

  // Filtragem por busca
  const filtrarLista = (lista: Emprestimo[]) => {
    if (!searchTerm.trim()) return lista;
    const term = searchTerm.toLowerCase();
    return lista.filter(item => {
      const eqNome = (item.equipamentoNome || item.kitNome || '').toLowerCase();
      const prof = (item.solicitante || '').toLowerCase();
      const sala = (item.turmaOuSala || '').toLowerCase();
      const obs = (item.observacoes || '').toLowerCase();
      const itensFilhos = (item.itensEmprestados || []).some(i => i.nome.toLowerCase().includes(term));
      return eqNome.includes(term) || prof.includes(term) || sala.includes(term) || obs.includes(term) || itensFilhos;
    });
  };

  const emUsoFiltrados = filtrarLista(emUsoAgora);
  const aguardandoFiltrados = filtrarLista(aguardandoRetiradaHoje);
  const atrasadosFiltrados = filtrarLista(atrasados);

  const totalAtivosHoje = emUsoAgora.length + aguardandoRetiradaHoje.length + atrasados.length;

  const formatDateBR = (dateStr?: string | null) => {
    if (!dateStr) return '';
    if (dateStr.includes('/')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Barra de Resumo Rápido & Botão de Agendamento */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Card 1: Em Uso Agora */}
        <div 
          onClick={() => setFiltroSecao(filtroSecao === 'em_uso' ? 'todos' : 'em_uso')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-sm ${
            filtroSecao === 'em_uso'
              ? 'bg-cyan-950/40 border-cyan-400 ring-2 ring-cyan-400/30'
              : 'bg-slate-900/90 border-slate-800 hover:border-cyan-500/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Em Uso Agora</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <ArrowDownToLine className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-white">{emUsoAgora.length}</span>
            <span className="text-xs text-cyan-300 font-medium">retirado(s)</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Equipamentos nas salas agora</p>
        </div>

        {/* Card 2: Aguardando Retirada */}
        <div 
          onClick={() => setFiltroSecao(filtroSecao === 'aguardando' ? 'todos' : 'aguardando')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-sm ${
            filtroSecao === 'aguardando'
              ? 'bg-amber-950/40 border-amber-400 ring-2 ring-amber-400/30'
              : 'bg-slate-900/90 border-slate-800 hover:border-amber-500/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Para Entregar Hoje</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-amber-300">{aguardandoRetiradaHoje.length}</span>
            <span className="text-xs text-amber-400 font-medium">agendado(s)</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Aguardando professor buscar</p>
        </div>

        {/* Card 3: Atrasados */}
        <div 
          onClick={() => setFiltroSecao(filtroSecao === 'atrasados' ? 'todos' : 'atrasados')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-sm ${
            filtroSecao === 'atrasados'
              ? 'bg-rose-950/40 border-rose-400 ring-2 ring-rose-400/30'
              : atrasados.length > 0 
              ? 'bg-rose-950/20 border-rose-500/40 hover:border-rose-400' 
              : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Atrasados</span>
            <div className={`p-2 rounded-xl border ${
              atrasados.length > 0 
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' 
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl sm:text-3xl font-bold ${atrasados.length > 0 ? 'text-rose-400' : 'text-slate-400'}`}>
              {atrasados.length}
            </span>
            <span className="text-xs text-slate-400 font-medium">pendente(s)</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">De dias anteriores não devolvidos</p>
        </div>

        {/* Card 4: Devolvidos Hoje */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Devolvidos Hoje</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-400">{devolvidosHoje.length}</span>
            <span className="text-xs text-emerald-300 font-medium">finalizado(s)</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Já retornaram ao armário</p>
        </div>

      </div>

      {/* Barra de Ação Rápida e Filtros de Busca */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Laptop className="w-5 h-5 text-cyan-400" />
              Equipamentos Emprestados Hoje ({formatDateBR(todayStr)})
            </h2>
            <p className="text-xs text-slate-400">
              Controle rápido de entrega e devolução para a rotina diária da escola
            </p>
          </div>

          <button
            type="button"
            onClick={onNovoAgendamento}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/25 transition-all cursor-pointer transform hover:-translate-y-0.5"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Novo Agendamento Rápido</span>
          </button>
        </div>

        {/* Campo de Pesquisa Instantânea */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1 border-t border-slate-800/80">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar quem está com qual equipamento, professor, sala..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-9 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filtro Rápido de Abas Internas */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto">
            <button
              onClick={() => setFiltroSecao('todos')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                filtroSecao === 'todos' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Todos ({totalAtivosHoje})
            </button>
            <button
              onClick={() => setFiltroSecao('em_uso')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
                filtroSecao === 'em_uso' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
              Em Uso ({emUsoAgora.length})
            </button>
            <button
              onClick={() => setFiltroSecao('aguardando')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
                filtroSecao === 'aguardando' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              Para Entregar ({aguardandoRetiradaHoje.length})
            </button>
            {atrasados.length > 0 && (
              <button
                onClick={() => setFiltroSecao('atrasados')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
                  filtroSecao === 'atrasados' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'text-rose-400 hover:text-rose-300'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-400"></span>
                Atrasados ({atrasados.length})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* QUADRO 1: ATRASADOS DE DIAS ANTERIORES (SE HOUVER) */}
      {(filtroSecao === 'todos' || filtroSecao === 'atrasados') && atrasadosFiltrados.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>Equipamentos com Devolução Atrasada ({atrasadosFiltrados.length})</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {atrasadosFiltrados.map((item) => (
              <div 
                key={item.id}
                className="bg-gradient-to-r from-rose-950/40 via-slate-900/90 to-slate-900/90 border border-rose-500/40 rounded-2xl p-4 shadow-md space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 text-[10px] font-bold uppercase border border-rose-500/40">
                        Atrasado
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        Devolução prevista: {formatDateBR(item.dataDevolucao)}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-white mt-1">
                      {item.equipamentoNome || item.kitNome}
                    </h4>
                  </div>

                  <button
                    onClick={() => onVerDetalhes(item)}
                    title="Ver Detalhes"
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-1.5 text-slate-200">
                    <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-semibold truncate">{item.solicitante}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-cyan-300">
                    <School className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span className="truncate">{item.turmaOuSala || 'Sala não inf.'}</span>
                  </div>
                </div>

                {canChangeStatus && (
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => onAbrirDevolucao(item)}
                      className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                    >
                      <CheckCheck className="w-4 h-4 stroke-[2.5]" />
                      <span>Registrar Devolução Agora</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* QUADRO 2: EQUIPAMENTOS EM USO AGORA (RETIRADOS) */}
      {(filtroSecao === 'todos' || filtroSecao === 'em_uso') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-base">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
              <span>Emprestados Agora nas Aulas ({emUsoFiltrados.length})</span>
            </div>
            <span className="text-xs text-slate-400">Equipamentos já retirados pelo professor</span>
          </div>

          {emUsoFiltrados.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
              <Laptop className="w-10 h-10 mx-auto text-slate-600" />
              <p className="text-sm font-semibold text-slate-300">
                Nenhum equipamento em uso no momento.
              </p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Todos os equipamentos agendados ainda não foram retirados ou já foram devolvidos ao almoxarifado.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {emUsoFiltrados.map((item) => {
                const isKit = item.tipoEmprestimo === 'kit' || Boolean(item.kitId);
                const isLote = item.tipoEmprestimo === 'lote' || (item.itensEmprestados && item.itensEmprestados.length > 1);
                const aulasTxt = formatAulasSummary(item.aulas || []);

                return (
                  <div 
                    key={item.id}
                    className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-4 shadow-sm space-y-3 transition-all flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      {/* Topo do Card: Badge + Nome do Equipamento */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2.5 rounded-xl border mt-0.5 ${
                            isKit 
                              ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400' 
                              : isLote
                              ? 'bg-purple-500/10 border-purple-500/30 text-purple-400'
                              : 'bg-slate-800 border-slate-700 text-blue-400'
                          }`}>
                            {isKit ? <Boxes className="w-5 h-5" /> : isLote ? <CheckSquare className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                          </div>

                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                                <ArrowDownToLine className="w-3 h-3 text-cyan-400" />
                                Em Uso
                              </span>
                              {isKit && (
                                <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 text-[10px] font-bold border border-cyan-800">
                                  KIT
                                </span>
                              )}
                              {isLote && (
                                <span className="px-1.5 py-0.5 rounded bg-purple-950 text-purple-400 text-[10px] font-bold border border-purple-800">
                                  {item.quantidadeTotal || item.itensEmprestados?.length || 'Lote'} ITENS
                                </span>
                              )}
                            </div>

                            <h4 
                              onClick={() => onVerDetalhes(item)}
                              className="font-bold text-white text-base mt-1 hover:text-cyan-300 transition-colors cursor-pointer line-clamp-1"
                              title={item.equipamentoNome || item.kitNome || ''}
                            >
                              {item.equipamentoNome || item.kitNome}
                            </h4>
                          </div>
                        </div>

                        <button
                          onClick={() => onVerDetalhes(item)}
                          title="Ver lista de equipamentos"
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Mini lista de itens se for kit ou múltiplos */}
                      {item.itensEmprestados && item.itensEmprestados.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {item.itensEmprestados.slice(0, 3).map((it, idx) => (
                            <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-slate-300">
                              {it.quantidade}x {it.nome}
                            </span>
                          ))}
                          {item.itensEmprestados.length > 3 && (
                            <span className="text-[10px] px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-800 text-cyan-300 font-semibold">
                              +{item.itensEmprestados.length - 3} mais
                            </span>
                          )}
                        </div>
                      )}

                      {/* Informações do Professor e Turma */}
                      <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Professor:</span>
                          <span className="font-bold text-white flex items-center gap-1 truncate max-w-[170px]">
                            <User className="w-3.5 h-3.5 text-cyan-400" />
                            {item.solicitante}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Turma / Sala:</span>
                          <span className="font-semibold text-cyan-300 flex items-center gap-1 truncate max-w-[170px]">
                            <School className="w-3.5 h-3.5 text-cyan-400" />
                            {item.turmaOuSala || 'Não informada'}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800">
                          <span className="text-slate-400">Aulas / Turno:</span>
                          <span className="font-mono text-[11px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            {aulasTxt}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Botão de Devolução Rápida */}
                    {canChangeStatus ? (
                      <button
                        onClick={() => onAbrirDevolucao(item)}
                        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
                      >
                        <ArrowUpFromLine className="w-4 h-4 stroke-[2.5]" />
                        <span>Registrar Devolução</span>
                      </button>
                    ) : (
                      <div className="text-center text-xs text-slate-500 py-1">
                        Devolução gerenciada pela equipe escolar
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* QUADRO 3: AGENDADOS PARA HOJE (AGUARDANDO RETIRADA) */}
      {(filtroSecao === 'todos' || filtroSecao === 'aguardando') && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
              <Clock className="w-5 h-5 text-amber-400" />
              <span>Para Entregar Hoje ({aguardandoFiltrados.length})</span>
            </div>
            <span className="text-xs text-slate-400">Professores que agendaram para hoje e ainda vão retirar</span>
          </div>

          {aguardandoFiltrados.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500/60" />
              <p className="text-sm font-semibold text-slate-300">
                Nenhum agendamento pendente de retirada para hoje.
              </p>
              <p className="text-xs text-slate-500">
                Todos os itens reservados para hoje já foram retirados ou não há novos agendamentos.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {aguardandoFiltrados.map((item) => {
                const isKit = item.tipoEmprestimo === 'kit' || Boolean(item.kitId);
                const isLote = item.tipoEmprestimo === 'lote' || (item.itensEmprestados && item.itensEmprestados.length > 1);
                const aulasTxt = formatAulasSummary(item.aulas || []);

                return (
                  <div 
                    key={item.id}
                    className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 shadow-sm space-y-3 transition-all flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2.5 rounded-xl border mt-0.5 ${
                            isKit 
                              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' 
                              : isLote
                              ? 'bg-purple-500/10 border-purple-500/30 text-purple-400'
                              : 'bg-slate-800 border-slate-700 text-amber-400'
                          }`}>
                            {isKit ? <Boxes className="w-5 h-5" /> : isLote ? <CheckSquare className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                          </div>

                          <div>
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                              <Clock className="w-3 h-3 text-amber-400" />
                              Aguardando Retirada
                            </span>

                            <h4 
                              onClick={() => onVerDetalhes(item)}
                              className="font-bold text-white text-base mt-1 hover:text-amber-300 transition-colors cursor-pointer line-clamp-1"
                            >
                              {item.equipamentoNome || item.kitNome}
                            </h4>
                          </div>
                        </div>

                        <button
                          onClick={() => onVerDetalhes(item)}
                          title="Ver lista de equipamentos"
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Informações do Professor e Turma */}
                      <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Professor:</span>
                          <span className="font-bold text-white flex items-center gap-1 truncate max-w-[170px]">
                            <User className="w-3.5 h-3.5 text-amber-400" />
                            {item.solicitante}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Turma / Sala:</span>
                          <span className="font-semibold text-slate-200 flex items-center gap-1 truncate max-w-[170px]">
                            <School className="w-3.5 h-3.5 text-slate-400" />
                            {item.turmaOuSala || 'Não informada'}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800">
                          <span className="text-slate-400">Horário Previsto:</span>
                          <span className="font-mono text-[11px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            {aulasTxt}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Botão de Retirada / Entregar */}
                    {canChangeStatus ? (
                      <button
                        onClick={() => onMarcarRetirada(item)}
                        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
                      >
                        <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
                        <span>Entregar ao Professor (Marcar Retirada)</span>
                      </button>
                    ) : (
                      <div className="text-center text-xs text-slate-500 py-1">
                        Aguarde a liberação pela equipe escolar
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
