import React, { useState } from 'react';
import { Emprestimo } from '../types';
import { 
  X, 
  ArrowUpFromLine, 
  AlertTriangle, 
  CheckCircle2, 
  Wrench, 
  Loader2, 
  CheckSquare, 
  Square,
  Package,
  Boxes,
  Info
} from 'lucide-react';

interface DevolucaoAvariaModalProps {
  isOpen: boolean;
  onClose: () => void;
  emprestimo: Emprestimo | null;
  onConfirm: (
    emprestimo: Emprestimo, 
    avariaData: { 
      houveAvaria: boolean; 
      avariaDescricao: string; 
      estadoConservacao: 'Precisa de Reparo' | 'Inoperante'; 
      atualizarInventario: boolean 
    }
  ) => Promise<void>;
  loading?: boolean;
}

export default function DevolucaoAvariaModal({
  isOpen,
  onClose,
  emprestimo,
  onConfirm,
  loading = false
}: DevolucaoAvariaModalProps) {
  if (!isOpen || !emprestimo) return null;

  const [houveAvaria, setHouveAvaria] = useState(Boolean(emprestimo.temAvaria));
  const [avariaDescricao, setAvariaDescricao] = useState(emprestimo.avariaDescricao || '');
  const [estadoConservacao, setEstadoConservacao] = useState<'Precisa de Reparo' | 'Inoperante'>('Precisa de Reparo');
  const [atualizarInventario, setAtualizarInventario] = useState(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (houveAvaria && !avariaDescricao.trim()) {
      alert('Por favor, informe a descrição da avaria identificada.');
      return;
    }

    await onConfirm(emprestimo, {
      houveAvaria,
      avariaDescricao: avariaDescricao.trim(),
      estadoConservacao,
      atualizarInventario
    });
  };

  const isKit = emprestimo.tipoEmprestimo === 'kit' || Boolean(emprestimo.kitId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header do Modal */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <ArrowUpFromLine className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                Registrar Devolução & Checagem
              </h3>
              <p className="text-xs text-slate-400">
                Confirmação de recebimento no almoxarifado
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={loading}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulário de Devolução */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Card Resumo do Empréstimo */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              {isKit ? <Boxes className="w-4 h-4 text-cyan-400" /> : <Package className="w-4 h-4 text-blue-400" />}
              <span>{emprestimo.equipamentoNome || emprestimo.kitNome || 'Equipamento'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 pt-1">
              <div>
                Solicitante: <strong className="text-slate-200">{emprestimo.solicitante}</strong>
              </div>
              {emprestimo.turmaOuSala && (
                <div>
                  Turma: <strong className="text-cyan-300">{emprestimo.turmaOuSala}</strong>
                </div>
              )}
            </div>
          </div>

          {/* Opção de Registro de Avaria */}
          <div className={`p-4 rounded-2xl border transition-all ${
            houveAvaria 
              ? 'bg-rose-950/20 border-rose-500/40' 
              : 'bg-slate-950 border-slate-800'
          }`}>
            <label 
              className="flex items-start gap-3 cursor-pointer select-none"
              onClick={() => setHouveAvaria(!houveAvaria)}
            >
              <div className="mt-0.5 text-rose-400">
                {houveAvaria ? (
                  <CheckSquare className="w-5 h-5 text-rose-500" />
                ) : (
                  <Square className="w-5 h-5 text-slate-600" />
                )}
              </div>
              <div>
                <span className="font-bold text-sm text-white flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  Houve avaria, dano ou defeito no equipamento?
                </span>
                <p className="text-xs text-slate-400 mt-0.5">
                  Marque esta opção caso o equipamento tenha retornado quebrado, com defeito ou precisando de conserto.
                </p>
              </div>
            </label>

            {/* Campos de Registro de Avaria caso marcado */}
            {houveAvaria && (
              <div className="mt-4 pt-4 border-t border-rose-500/20 space-y-4 animate-in fade-in duration-150">
                <div>
                  <label className="block text-xs font-semibold text-rose-200 uppercase tracking-wider mb-1.5">
                    Descrição da Avaria / Problema Encontrado *
                  </label>
                  <textarea
                    rows={3}
                    required={houveAvaria}
                    value={avariaDescricao}
                    onChange={(e) => setAvariaDescricao(e.target.value)}
                    placeholder="Ex: Tela riscada, cabo de energia com mau contato, botão quebrado..."
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-rose-500/40 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
                  ></textarea>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-rose-200 uppercase tracking-wider mb-1.5">
                    Novo Estado de Conservação do Item:
                  </label>
                  <select
                    value={estadoConservacao}
                    onChange={(e) => setEstadoConservacao(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-rose-500/40 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-rose-400 cursor-pointer"
                  >
                    <option value="Precisa de Reparo">Precisa de Reparo (Manutenção Corretiva)</option>
                    <option value="Inoperante">Inoperante (Sem condições de uso)</option>
                  </select>
                </div>

                <label 
                  className="flex items-center gap-2.5 cursor-pointer text-xs text-rose-200 select-none pt-1"
                  onClick={() => setAtualizarInventario(!atualizarInventario)}
                >
                  <div className="text-rose-400">
                    {atualizarInventario ? (
                      <CheckSquare className="w-4 h-4 text-rose-500" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-600" />
                    )}
                  </div>
                  <span>Atualizar status do equipamento no Inventário para "Manutenção"</span>
                </label>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-sm font-medium transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 ${
                houveAvaria
                  ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
              }`}
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : houveAvaria ? (
                <AlertTriangle className="w-4 h-4" />
              ) : (
                <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
              )}
              <span>{houveAvaria ? 'Confirmar Devolução com Avaria' : 'Confirmar Devolução (Sem Avaria)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
