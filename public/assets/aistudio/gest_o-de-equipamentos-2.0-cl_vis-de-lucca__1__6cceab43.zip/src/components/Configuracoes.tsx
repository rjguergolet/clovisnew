import React, { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  updateDoc, 
  serverTimestamp,
  writeBatch,
  getDocs
} from 'firebase/firestore';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut, updatePassword } from 'firebase/auth';
import { db, auth } from '../lib/firebase';
import firebaseConfig from '../../firebase-applet-config.json';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { parseCSVEquipamentos, INITIAL_CSV_EQUIPAMENTOS_STRING } from '../data/initialEquipamentosData';
import { UserRole, UsuarioDoc } from '../types';
import { 
  USER_ROLES, 
  SUPER_ADMIN_EMAIL, 
  isSuperAdminEmail,
  cleanUsername,
  usernameToAuthEmail,
  normalizeUserRole,
  PERMISSIONS,
  isAdminOrAbove,
  isDirectorOrTotal 
} from '../lib/userRoles';
import { 
  Settings, 
  Upload, 
  Download, 
  UserPlus, 
  Users, 
  Database, 
  FileSpreadsheet, 
  FileJson, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Trash2, 
  FileText, 
  HardDrive, 
  Check, 
  Layers, 
  HelpCircle, 
  Lock, 
  Key, 
  Mail, 
  User as UserIcon, 
  Info,
  Boxes,
  ArrowRightLeft,
  Sparkles,
  Eye,
  EyeOff,
  Crown,
  ShieldAlert,
  GraduationCap,
  BookOpen,
  ClipboardPaste,
  Copy,
  CheckCheck,
  Filter,
  KeyRound,
  FileCheck
} from 'lucide-react';

interface ConfiguracoesProps {
  userRole?: UserRole;
  currentUserEmail?: string | null;
  simulatedRole?: UserRole | null;
  onStartSimulation?: (role: UserRole) => void;
  onStopSimulation?: () => void;
}

export default function Configuracoes({ 
  userRole = 'padrao', 
  currentUserEmail = null,
  simulatedRole = null,
  onStartSimulation,
  onStopSimulation
}: ConfiguracoesProps) {
  const isFullAdmin = PERMISSIONS.canAccessFullConfig(userRole, currentUserEmail);
  const isLimitedUser = !isFullAdmin;
  const canSimulate = PERMISSIONS.canSimulateRoles(userRole, currentUserEmail);
  const canManageUsers = isFullAdmin && PERMISSIONS.canManageUsers(userRole);
  const canExportBackup = isFullAdmin && PERMISSIONS.canExportBackup(userRole);
  const canImportBackup = isFullAdmin && PERMISSIONS.canImportBackup(userRole);
  const canWipe = isFullAdmin && PERMISSIONS.canWipeDatabase(userRole);

  const [activeSubTab, setActiveSubTab] = useState<'conta' | 'backup' | 'usuarios' | 'simulacao' | 'sistema'>('conta');

  // Forçar subaba 'conta' caso o usuário perca privilégios de direção ou simule perfil com restrição
  useEffect(() => {
    if (isLimitedUser && activeSubTab !== 'conta') {
      setActiveSubTab('conta');
    }
  }, [isLimitedUser, activeSubTab]);

  // Estados de Alteração de Senha do Usuário Logado
  const [novaSenha, setNovaSenha] = useState('');
  const [confirmarNovaSenha, setConfirmarNovaSenha] = useState('');
  const [showNovaSenha, setShowNovaSenha] = useState(false);
  const [showConfirmarNovaSenha, setShowConfirmarNovaSenha] = useState(false);
  const [alterandoSenha, setAlterandoSenha] = useState(false);
  const [senhaSuccessMessage, setSenhaSuccessMessage] = useState<string | null>(null);
  const [senhaErrorMessage, setSenhaErrorMessage] = useState<string | null>(null);
  
  // Dados do Firestore
  const [equipamentos, setEquipamentos] = useState<any[]>([]);
  const [emprestimos, setEmprestimos] = useState<any[]>([]);
  const [usuarios, setUsuarios] = useState<UsuarioDoc[]>([]);
  const [loading, setLoading] = useState(true);

  // Estados do Módulo de Backup / Upload
  const [importFile, setImportFile] = useState<File | null>(null);
  const [parsedPreview, setParsedPreview] = useState<any[]>([]);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState<{ current: number; total: number; message: string } | null>(null);
  const [importSuccessMessage, setImportSuccessMessage] = useState<string | null>(null);
  const [importErrorMessage, setImportErrorMessage] = useState<string | null>(null);

  // Estados do Módulo de Usuários e Perfis Escolares
  const [userCreationMode, setUserCreationMode] = useState<'bulk' | 'single'>('bulk');
  const [userFilterRole, setUserFilterRole] = useState<string>('TODOS');
  const [userSearchTerm, setUserSearchTerm] = useState<string>('');

  // Subir Usuários em Lote (Copiar & Colar: Nome \t E-mail \t Nível de Acesso)
  const [bulkUsersText, setBulkUsersText] = useState<string>('');
  const [bulkDefaultPassword, setBulkDefaultPassword] = useState<string>('escola123');
  const [showBulkPassword, setShowBulkPassword] = useState<boolean>(false);
  const [bulkParsedList, setBulkParsedList] = useState<Array<{
    id: string;
    nome: string;
    email: string;
    perfil: string;
    usuario: string;
    valid: boolean;
    error?: string;
  }>>([]);
  const [bulkProcessing, setBulkProcessing] = useState(false);
  const [bulkProgress, setBulkProgress] = useState<{ current: number; total: number; message: string } | null>(null);
  const [bulkSuccessReport, setBulkSuccessReport] = useState<{
    total: number;
    created: number;
    updated: number;
    errorList: string[];
  } | null>(null);
  const [bulkErrorMessage, setBulkErrorMessage] = useState<string | null>(null);

  // Cadastro Individual de Usuário
  const [userFormData, setUserFormData] = useState<{
    nome: string;
    usuario: string;
    email: string;
    senha: string;
    perfil: string;
    status: 'ativo' | 'inativo';
  }>({
    nome: '',
    usuario: '',
    email: '',
    senha: '',
    perfil: 'PROFESSOR',
    status: 'ativo'
  });
  const [showPassword, setShowPassword] = useState(false);
  const [creatingUser, setCreatingUser] = useState(false);
  const [userSuccessMessage, setUserSuccessMessage] = useState<string | null>(null);
  const [userErrorMessage, setUserErrorMessage] = useState<string | null>(null);

  // Estado de confirmação de limpeza
  const [confirmClearText, setConfirmClearText] = useState('');
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [clearingData, setClearingData] = useState(false);

  // Ação de Alteração de Senha do Usuário Logado
  const handleAlterarMinhaSenha = async (e: React.FormEvent) => {
    e.preventDefault();
    setSenhaSuccessMessage(null);
    setSenhaErrorMessage(null);

    if (!novaSenha || novaSenha.length < 6) {
      setSenhaErrorMessage('A nova senha deve ter no mínimo 6 caracteres.');
      return;
    }

    if (novaSenha !== confirmarNovaSenha) {
      setSenhaErrorMessage('A confirmação da senha não confere com a nova senha digitada.');
      return;
    }

    if (!auth.currentUser) {
      setSenhaErrorMessage('Nenhum usuário logado detectado no momento.');
      return;
    }

    setAlterandoSenha(true);
    try {
      await updatePassword(auth.currentUser, novaSenha);
      setSenhaSuccessMessage('Sua senha de acesso foi alterada com sucesso!');
      setNovaSenha('');
      setConfirmarNovaSenha('');
    } catch (err: any) {
      console.error('Erro ao alterar senha:', err);
      if (err.code === 'auth/requires-recent-login') {
        setSenhaErrorMessage('Por motivos de segurança, saia do sistema e faça login novamente antes de trocar sua senha.');
      } else if (err.code === 'auth/weak-password') {
        setSenhaErrorMessage('A senha escolhida é muito fraca. Utilize uma combinação mais segura.');
      } else {
        setSenhaErrorMessage(err.message || 'Erro ao alterar a senha.');
      }
    } finally {
      setAlterandoSenha(false);
    }
  };

  // Carregar dados em tempo real
  useEffect(() => {
    setLoading(true);

    const unsubEq = onSnapshot(collection(db, 'equipamentos'), (snap) => {
      setEquipamentos(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'equipamentos'));

    const unsubEmp = onSnapshot(collection(db, 'emprestimos'), (snap) => {
      setEmprestimos(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'emprestimos'));

    const unsubUsers = onSnapshot(collection(db, 'usuarios'), (snap) => {
      setUsuarios(snap.docs.map(d => ({ id: d.id, ...(d.data() as any) })));
      setLoading(false);
    }, (err) => {
      setLoading(false);
      handleFirestoreError(err, OperationType.LIST, 'usuarios');
    });

    return () => {
      unsubEq();
      unsubEmp();
      unsubUsers();
    };
  }, []);

  // Processar arquivo selecionado para Upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setImportSuccessMessage(null);
    setImportErrorMessage(null);
    if (!file) {
      setImportFile(null);
      setParsedPreview([]);
      return;
    }

    setImportFile(file);
    const reader = new FileReader();

    if (file.name.endsWith('.json')) {
      reader.onload = (event) => {
        try {
          const json = JSON.parse(event.target?.result as string);
          let items: any[] = [];
          if (Array.isArray(json)) {
            items = json;
          } else if (json.equipamentos && Array.isArray(json.equipamentos)) {
            items = json.equipamentos;
          } else {
            throw new Error('Formato JSON não reconhecido.');
          }
          setParsedPreview(items);
        } catch (err: any) {
          setImportErrorMessage(`Erro ao ler JSON: ${err.message}`);
          setParsedPreview([]);
        }
      };
      reader.readAsText(file);
    } else {
      // Leitura CSV / Texto
      reader.onload = (event) => {
        try {
          const text = event.target?.result as string;
          const items = parseCSVEquipamentos(text);
          if (items.length === 0) {
            setImportErrorMessage('Nenhum equipamento reconhecido no CSV. Verifique as colunas.');
          }
          setParsedPreview(items);
        } catch (err: any) {
          setImportErrorMessage(`Erro ao processar CSV: ${err.message}`);
          setParsedPreview([]);
        }
      };
      reader.readAsText(file);
    }
  };

  // Carregar planilha fornecida diretamente
  const handleCarregarPlanilhaPadrao = () => {
    try {
      setImportSuccessMessage(null);
      setImportErrorMessage(null);
      const items = parseCSVEquipamentos(INITIAL_CSV_EQUIPAMENTOS_STRING);
      setParsedPreview(items);
      setImportFile(new File([INITIAL_CSV_EQUIPAMENTOS_STRING], 'planilha_equipamentos_fornecida.csv', { type: 'text/csv' }));
    } catch (err: any) {
      setImportErrorMessage(`Erro ao processar catálogo padrão: ${err.message}`);
    }
  };

  // Executar a Importação / Restauração para o Firestore
  const handleExecutarImportacao = async () => {
    if (parsedPreview.length === 0) {
      setImportErrorMessage('Nenhum item válido para importar.');
      return;
    }

    setImporting(true);
    setImportSuccessMessage(null);
    setImportErrorMessage(null);

    try {
      // Se modo for "replace", apaga os itens existentes antes
      if (importMode === 'replace') {
        setImportProgress({ current: 0, total: parsedPreview.length, message: 'Limpando catálogo existente...' });
        const existingDocs = await getDocs(collection(db, 'equipamentos'));
        
        // Deletar em lotes de 400
        const deleteBatches = [];
        let curDeleteBatch = writeBatch(db);
        let count = 0;

        for (const docSnap of existingDocs.docs) {
          curDeleteBatch.delete(docSnap.ref);
          count++;
          if (count % 400 === 0) {
            deleteBatches.push(curDeleteBatch.commit());
            curDeleteBatch = writeBatch(db);
          }
        }
        if (count % 400 !== 0 && count > 0) {
          deleteBatches.push(curDeleteBatch.commit());
        }
        await Promise.all(deleteBatches);
      }

      // Inserir novos itens em lotes (batch)
      const total = parsedPreview.length;
      const chunkSize = 300;
      let inserted = 0;

      for (let i = 0; i < total; i += chunkSize) {
        const chunk = parsedPreview.slice(i, i + chunkSize);
        const batch = writeBatch(db);

        chunk.forEach((item) => {
          const docRef = doc(collection(db, 'equipamentos'));
          batch.set(docRef, {
            nome: String(item.nome || 'Equipamento').slice(0, 200),
            patrimonio: String(item.patrimonio || item.numeroSerie || '').slice(0, 100),
            categoria: item.categoria || 'Outros',
            estadoConservacao: item.estadoConservacao || 'Bom',
            quantidade: Number(item.quantidade) || 1,
            localizacao: String(item.localizacao || 'Armário TI').slice(0, 200),
            observacoes: String(item.observacoes || '').slice(0, 1000),
            fabricante: item.fabricante ? String(item.fabricante).slice(0, 100) : null,
            modelo: item.modelo ? String(item.modelo).slice(0, 150) : null,
            numeroSerie: item.numeroSerie ? String(item.numeroSerie).slice(0, 100) : null,
            statusEquipamento: item.statusEquipamento ? String(item.statusEquipamento).slice(0, 50) : null,
            avaliacaoTecnica: item.avaliacaoTecnica ? String(item.avaliacaoTecnica).slice(0, 50) : null,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            importedAt: new Date().toISOString()
          });
        });

        await batch.commit();
        inserted += chunk.length;
        setImportProgress({
          current: inserted,
          total,
          message: `Gravando itens no banco de dados (${inserted} de ${total})...`
        });
      }

      setImportSuccessMessage(`Sucesso! ${total} equipamentos foram importados e salvos com sucesso.`);
      setParsedPreview([]);
      setImportFile(null);
    } catch (err: any) {
      console.error('Erro ao importar:', err);
      setImportErrorMessage(`Falha na importação: ${err.message}`);
    } finally {
      setImporting(false);
      setImportProgress(null);
    }
  };

  // Funções para Tirar / Exportar Backup
  const handleExportEquipamentosCSV = () => {
    if (equipamentos.length === 0) {
      alert('Não há equipamentos para exportar.');
      return;
    }

    const headers = ['CATEGORIA DO EQUIPAMENTO', 'FABRICANTE', 'MODELO', 'NÚMERO DE SÉRIE / PATRIMÔNIO', 'STATUS DO EQUIPAMENTO', 'ESTADO DE CONSERVAÇÃO', 'OBSERVAÇÕES', 'LOCALIZAÇÃO', 'QUANTIDADE'];
    
    const rows = equipamentos.map(eq => [
      eq.categoria || '',
      eq.fabricante || '',
      eq.modelo || eq.nome || '',
      eq.patrimonio || eq.numeroSerie || '',
      eq.statusEquipamento || (eq.estadoConservacao === 'Inoperante' ? 'Inativo' : 'Ativo'),
      eq.avaliacaoTecnica || eq.estadoConservacao || 'Bom',
      (eq.observacoes || '').replace(/[\r\n]+/g, ' '),
      eq.localizacao || '',
      eq.quantidade || 1
    ]);

    const csvContent = '\uFEFF' + [
      headers.join(';'),
      ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(';'))
    ].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `backup_equipamentos_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportEquipamentosJSON = () => {
    const dataStr = JSON.stringify(equipamentos, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `backup_equipamentos_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportEmprestimosCSV = () => {
    if (emprestimos.length === 0) {
      alert('Não há empréstimos para exportar.');
      return;
    }

    const headers = ['ID_EMPRESTIMO', 'EQUIPAMENTO', 'SOLICITANTE', 'CONTATO', 'DATA_RETIRADA', 'DATA_PREVISTA_DEVOLUCAO', 'DATA_REAL_DEVOLUCAO', 'STATUS', 'OBSERVACOES'];
    
    const rows = emprestimos.map(emp => [
      emp.id || '',
      emp.equipamentoNome || '',
      emp.solicitante || '',
      emp.contato || '',
      emp.dataRetirada || '',
      emp.dataDevolucao || '',
      emp.dataDevolucaoReal || '',
      emp.status || '',
      (emp.observacoes || '').replace(/[\r\n]+/g, ' ')
    ]);

    const csvContent = '\uFEFF' + [
      headers.join(';'),
      ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(';'))
    ].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `backup_emprestimos_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportBackupCompleto = () => {
    const fullBackup = {
      exportDate: new Date().toISOString(),
      app: 'Gestão de Equipamentos e Empréstimos',
      equipamentos,
      emprestimos,
      totalEquipamentos: equipamentos.length,
      totalEmprestimos: emprestimos.length
    };

    const dataStr = JSON.stringify(fullBackup, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `backup_completo_sistema_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Função para processar o texto colado no formato: Nome [TAB/;/,] E-mail [TAB/;/,] Nível de Acesso
  const handleParseBulkUsers = (overrideText?: string) => {
    const textToProcess = overrideText !== undefined ? overrideText : bulkUsersText;
    setBulkErrorMessage(null);
    setBulkSuccessReport(null);

    if (!textToProcess.trim()) {
      setBulkErrorMessage('Cole uma lista de usuários para processar.');
      setBulkParsedList([]);
      return;
    }

    const lines = textToProcess.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    const parsed: Array<{
      id: string;
      nome: string;
      email: string;
      perfil: string;
      usuario: string;
      valid: boolean;
      error?: string;
    }> = [];

    let lineIndex = 0;
    for (const rawLine of lines) {
      lineIndex++;

      // Detectar separador (TAB é prioritário por vir de planilhas/Excel)
      let cols: string[] = [];
      if (rawLine.includes('\t')) {
        cols = rawLine.split('\t');
      } else if (rawLine.includes(';') && (rawLine.match(/;/g) || []).length >= 1) {
        cols = rawLine.split(';');
      } else if (rawLine.includes(',') && (rawLine.match(/,/g) || []).length >= 1) {
        cols = rawLine.split(',');
      } else {
        // Separação por 2 ou mais espaços
        cols = rawLine.split(/\s{2,}/);
      }

      cols = cols.map(c => c.trim().replace(/^["']|["']$/g, ''));

      // Ignora cabeçalho se contiver "Nome" e "E-mail" ou "Nível"
      const lineLower = rawLine.toLowerCase();
      if (
        lineIndex === 1 && 
        (lineLower.includes('nome') && (lineLower.includes('email') || lineLower.includes('e-mail') || lineLower.includes('nível') || lineLower.includes('nivel') || lineLower.includes('acesso')))
      ) {
        continue;
      }

      const nome = cols[0] || '';
      const email = cols[1] || '';
      const rawPerfil = cols[2] || 'PROFESSOR';

      if (!nome && !email) continue;

      const perfil = normalizeUserRole(rawPerfil);
      const cleanUser = cleanUsername(email.includes('@') ? email.split('@')[0] : nome);
      const emailVal = email.trim().toLowerCase();

      let isValid = true;
      let errorMsg = '';

      if (!nome) {
        isValid = false;
        errorMsg = 'Nome ausente';
      } else if (!emailVal) {
        isValid = false;
        errorMsg = 'E-mail ausente';
      } else if (!emailVal.includes('@')) {
        isValid = false;
        errorMsg = 'E-mail sem @';
      }

      parsed.push({
        id: `bulk_${Date.now()}_${lineIndex}_${Math.random().toString(36).substring(2, 6)}`,
        nome,
        email: emailVal,
        perfil,
        usuario: cleanUser,
        valid: isValid,
        error: errorMsg
      });
    }

    if (parsed.length === 0) {
      setBulkErrorMessage('Nenhum usuário detectado. Verifique se o formato colado possui: Nome [TAB] E-mail [TAB] Nível de Acesso');
    }

    setBulkParsedList(parsed);
  };

  const handleInserirExemploUsuarios = () => {
    const exemplo = `Carlos Silva\tcarlos.silva@educacao.sp.gov.br\tPROFESSOR
Mariana Costa\tmariana.costa@educacao.sp.gov.br\tCGPG
Fernanda Lima\tfernanda.lima@educacao.sp.gov.br\tSECRETARIA
Paulo Roberto\tpaulo.roberto@educacao.sp.gov.br\tVICE_DIRETOR
Ana Paula Souza\tanapaula.souza@educacao.sp.gov.br\tPROFESSOR_PAAC
Roberto Guergolet\troberto.diretor@educacao.sp.gov.br\tDIRETOR`;

    setBulkUsersText(exemplo);
    handleParseBulkUsers(exemplo);
  };

  const handleUpdateBulkUserItem = (id: string, field: 'nome' | 'email' | 'perfil', value: string) => {
    setBulkParsedList(prev => prev.map(item => {
      if (item.id !== id) return item;
      const updated = { ...item, [field]: value };
      if (field === 'perfil') updated.perfil = normalizeUserRole(value);
      if (field === 'email') updated.usuario = cleanUsername(value.split('@')[0] || updated.nome);
      updated.valid = Boolean(updated.nome.trim() && updated.email.trim() && updated.email.includes('@'));
      updated.error = updated.valid ? undefined : 'Verifique nome e e-mail';
      return updated;
    }));
  };

  const handleRemoveBulkUserItem = (id: string) => {
    setBulkParsedList(prev => prev.filter(item => item.id !== id));
  };

  // Executar criação em lote no Firebase Auth e Firestore
  const handleExecutarUploadUsuariosLote = async () => {
    if (bulkParsedList.length === 0) {
      setBulkErrorMessage('Processe a lista de usuários antes de criar.');
      return;
    }

    const invalidItems = bulkParsedList.filter(item => !item.valid);
    if (invalidItems.length > 0) {
      if (!window.confirm(`Existem ${invalidItems.length} registros com dados incompletos que serão ignorados. Deseja continuar com os ${bulkParsedList.length - invalidItems.length} válidos?`)) {
        return;
      }
    }

    const validUsers = bulkParsedList.filter(item => item.valid);
    if (validUsers.length === 0) {
      setBulkErrorMessage('Não há usuários válidos para cadastrar.');
      return;
    }

    if (!bulkDefaultPassword || bulkDefaultPassword.length < 6) {
      setBulkErrorMessage('A senha padrão inicial deve conter no mínimo 6 caracteres.');
      return;
    }

    setBulkProcessing(true);
    setBulkErrorMessage(null);
    setBulkSuccessReport(null);

    let createdCount = 0;
    let updatedCount = 0;
    const errorList: string[] = [];

    try {
      const secondaryAppName = `BulkSecondaryApp_${Date.now()}`;
      const secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
      const secondaryAuth = getAuth(secondaryApp);

      for (let i = 0; i < validUsers.length; i++) {
        const u = validUsers[i];
        setBulkProgress({
          current: i + 1,
          total: validUsers.length,
          message: `Processando usuário ${i + 1} de ${validUsers.length}: ${u.nome} (${USER_ROLES[u.perfil]?.label || u.perfil})...`
        });

        let targetUid = '';

        // 1. Tentar criar conta no Firebase Auth
        try {
          const cred = await createUserWithEmailAndPassword(
            secondaryAuth,
            u.email,
            bulkDefaultPassword
          );
          targetUid = cred.user.uid;
          await signOut(secondaryAuth);
          createdCount++;
        } catch (authErr: any) {
          if (authErr.code === 'auth/email-already-in-use') {
            updatedCount++;
          } else {
            console.warn(`Aviso no Auth para ${u.email}:`, authErr);
            errorList.push(`${u.nome} (${u.email}): ${authErr.message}`);
          }
        }

        // 2. Salvar na coleção /usuarios do Firestore
        try {
          const cleanUser = cleanUsername(u.usuario || u.email.split('@')[0] || u.nome);
          const existingUserDoc = usuarios.find(
            ex => ex.email?.toLowerCase() === u.email.toLowerCase() || 
                  ex.usuario?.toLowerCase() === cleanUser.toLowerCase()
          );
          const docId = targetUid || existingUserDoc?.id || existingUserDoc?.uid || cleanUser;

          await setDoc(doc(db, 'usuarios', docId), {
            uid: targetUid || existingUserDoc?.uid || docId,
            usuario: cleanUser,
            email: u.email.toLowerCase(),
            nome: u.nome.trim(),
            perfil: u.perfil,
            status: 'ativo',
            updatedAt: serverTimestamp(),
            ...(existingUserDoc ? {} : { createdAt: serverTimestamp() }),
            createdBy: auth.currentUser?.email || 'admin'
          }, { merge: true });
        } catch (dbErr: any) {
          console.error(`Erro no Firestore para ${u.email}:`, dbErr);
          errorList.push(`${u.nome} (Firestore): ${dbErr.message}`);
        }
      }

      setBulkSuccessReport({
        total: validUsers.length,
        created: createdCount,
        updated: updatedCount,
        errorList
      });

      if (errorList.length === 0) {
        setBulkParsedList([]);
        setBulkUsersText('');
      }
    } catch (err: any) {
      console.error('Erro geral no upload em lote:', err);
      setBulkErrorMessage(`Erro no processamento em lote: ${err.message}`);
    } finally {
      setBulkProcessing(false);
      setBulkProgress(null);
    }
  };

  // Criar Usuário no Firebase Auth e registrar em /usuarios
  const handleCadastrarUsuario = async (e: React.FormEvent) => {
    e.preventDefault();
    setUserSuccessMessage(null);
    setUserErrorMessage(null);

    const cleanUser = cleanUsername(userFormData.usuario || userFormData.email.split('@')[0] || userFormData.nome);
    const targetEmail = userFormData.email.trim() 
      ? userFormData.email.trim().toLowerCase() 
      : usernameToAuthEmail(cleanUser);

    if (!cleanUser) {
      setUserErrorMessage('Informe o nome de usuário (login) do novo usuário.');
      return;
    }

    if (!userFormData.senha) {
      setUserErrorMessage('Informe a senha do novo usuário.');
      return;
    }

    if (userFormData.senha.length < 6) {
      setUserErrorMessage('A senha precisa conter no mínimo 6 caracteres.');
      return;
    }

    setCreatingUser(true);

    try {
      // Usar instância secundária do Firebase para não deslogar o usuário atual
      const secondaryAppName = `SecondaryApp_${Date.now()}`;
      const secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
      const secondaryAuth = getAuth(secondaryApp);

      const userCredential = await createUserWithEmailAndPassword(
        secondaryAuth,
        targetEmail,
        userFormData.senha
      );

      const newUserId = userCredential.user.uid;

      // Desconectar app secundário
      await signOut(secondaryAuth);

      // Salvar registro e perfil na coleção /usuarios do Firestore principal
      await setDoc(doc(db, 'usuarios', newUserId), {
        uid: newUserId,
        usuario: cleanUser,
        email: targetEmail,
        nome: userFormData.nome.trim() || cleanUser,
        perfil: userFormData.perfil,
        status: userFormData.status,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        createdBy: auth.currentUser?.email || 'admin'
      });

      const roleLabel = USER_ROLES[userFormData.perfil]?.label || userFormData.perfil;
      setUserSuccessMessage(`Usuário "${cleanUser}" cadastrado como "${roleLabel}" com sucesso!`);
      setUserFormData({
        nome: '',
        usuario: '',
        email: '',
        senha: '',
        perfil: 'PROFESSOR',
        status: 'ativo'
      });
    } catch (err: any) {
      console.error('Erro ao cadastrar usuário:', err);
      let msg = err.message;
      if (err.code === 'auth/email-already-in-use') msg = 'Este usuário/e-mail já está cadastrado no sistema.';
      if (err.code === 'auth/invalid-email') msg = 'Formato de usuário/e-mail inválido.';
      if (err.code === 'auth/weak-password') msg = 'A senha é fraca. Use pelo menos 6 caracteres.';
      setUserErrorMessage(`Erro ao cadastrar usuário: ${msg}`);
    } finally {
      setCreatingUser(false);
    }
  };

  const handleDeleteUsuario = async (userId: string, email: string) => {
    if (isSuperAdminEmail(email)) {
      alert(`A conta do Administrador Total Master (${email}) é protegida e não pode ser excluída.`);
      return;
    }

    if (!window.confirm(`Deseja remover o registro do usuário "${email}" da listagem?`)) return;
    try {
      await deleteDoc(doc(db, 'usuarios', userId));
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, `usuarios/${userId}`);
    }
  };

  const handleToggleStatusUsuario = async (u: any) => {
    if (isSuperAdminEmail(u.email)) {
      alert('A conta do Administrador Total Master é protegida e deve permanecer sempre ativa.');
      return;
    }

    const novoStatus = u.status === 'ativo' ? 'inativo' : 'ativo';
    try {
      await updateDoc(doc(db, 'usuarios', u.id), {
        status: novoStatus,
        updatedAt: serverTimestamp()
      });
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `usuarios/${u.id}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Seção de Configurações */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                Configurações do Sistema
              </h2>
              <p className="text-xs sm:text-sm text-slate-400">
                Gerencie backups (subir & tirar), importação de equipamentos e gestão de usuários (Padrão, Adm e Adm total)
              </p>
            </div>
          </div>

          {/* Navegação entre Sub-abas */}
          <div className="flex flex-wrap items-center p-1 bg-slate-950 rounded-xl border border-slate-800 self-start sm:self-auto gap-1">
            <button
              onClick={() => setActiveSubTab('conta')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'conta'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>Minha Conta & Senha</span>
            </button>

            {!isLimitedUser && (
              <>
                <button
                  onClick={() => setActiveSubTab('backup')}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeSubTab === 'backup'
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Database className="w-4 h-4" />
                  <span>Backups & Dados</span>
                </button>

                {canManageUsers && (
                  <button
                    onClick={() => setActiveSubTab('usuarios')}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeSubTab === 'usuarios'
                        ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                        : 'text-slate-400 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span>Usuários & Acessos</span>
                  </button>
                )}

                {canSimulate && (
                  <button
                    onClick={() => setActiveSubTab('simulacao')}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeSubTab === 'simulacao'
                        ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-amber-400/80 hover:text-amber-300 hover:bg-amber-500/10'
                    }`}
                  >
                    <Eye className="w-4 h-4" />
                    <span>Simulador de Perfis</span>
                  </button>
                )}

                <button
                  onClick={() => setActiveSubTab('sistema')}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeSubTab === 'sistema'
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <HardDrive className="w-4 h-4" />
                  <span>Resumo do Banco</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* SUB-ABA: MINHA CONTA & ALTERAR SENHA (DISPONÍVEL PARA TODOS OS PERFIS) */}
      {activeSubTab === 'conta' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* PAINEL 1: DADOS DO PERFIL ESCOLAR */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                  <UserIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Meu Perfil de Acesso</h3>
                  <p className="text-xs text-slate-400">Informações da sua credencial no sistema escolar</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800/60 pb-2.5">
                  <span className="text-xs text-slate-400">E-mail / Usuário:</span>
                  <span className="text-xs font-mono font-bold text-cyan-300">
                    {currentUserEmail || auth.currentUser?.email || 'Usuário Conectado'}
                  </span>
                </div>

                <div className="flex items-center justify-between border-b border-slate-800/60 pb-2.5">
                  <span className="text-xs text-slate-400">Nível / Cargo Escolar:</span>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold border ${USER_ROLES[userRole]?.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                    <GraduationCap className="w-3.5 h-3.5" />
                    {USER_ROLES[userRole]?.label || 'Padrão'}
                  </span>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 block mb-1">Descrição dos Seus Privilégios:</span>
                  <p className="text-xs text-slate-300 bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                    {USER_ROLES[userRole]?.description || 'Acesso padrão ao sistema.'}
                  </p>
                </div>
              </div>

              {/* Informações sobre o papel no fluxo escolar */}
              <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-xs text-cyan-200/90 space-y-1.5">
                <div className="flex items-center gap-1.5 font-bold text-cyan-300">
                  <Info className="w-4 h-4" />
                  <span>Resumo de Permissões Pedagógicas:</span>
                </div>
                {userRole === 'PROFESSOR' ? (
                  <ul className="list-disc list-inside space-y-1 text-slate-300 pl-1">
                    <li>Agendamento direto de equipamentos e kits para aulas e turmas.</li>
                    <li>Visualização com caixas de seleção rápida para itens disponíveis.</li>
                    <li>Acesso seguro e restrito à alteração da própria senha nesta aba.</li>
                  </ul>
                ) : (
                  <ul className="list-disc list-inside space-y-1 text-slate-300 pl-1">
                    <li>Controle de agendamentos e registros de aulas.</li>
                    <li>Gestão do catálogo de equipamentos e inventário pedagógico.</li>
                    {canSimulate && <li>Módulo da Direção para simular a experiência de outros cargos.</li>}
                  </ul>
                )}
              </div>
            </div>

            <div className="text-[11px] text-slate-500 text-center pt-2">
              Sistema de Controle de Agendamentos e Inventário Escolar
            </div>
          </div>

          {/* PAINEL 2: FORMULÁRIO DE ALTERAÇÃO DE SENHA */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <KeyRound className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Alterar Minha Senha</h3>
                <p className="text-xs text-slate-400">Digite sua nova senha de acesso para atualizar a segurança da sua conta</p>
              </div>
            </div>

            {senhaSuccessMessage && (
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5 animate-in fade-in duration-200">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{senhaSuccessMessage}</span>
              </div>
            )}

            {senhaErrorMessage && (
              <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5 animate-in fade-in duration-200">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{senhaErrorMessage}</span>
              </div>
            )}

            <form onSubmit={handleAlterarMinhaSenha} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Nova Senha (Mínimo 6 caracteres) *
                </label>
                <div className="relative">
                  <input
                    type={showNovaSenha ? 'text' : 'password'}
                    value={novaSenha}
                    onChange={(e) => setNovaSenha(e.target.value)}
                    placeholder="Digite sua nova senha"
                    required
                    minLength={6}
                    className="w-full pl-3.5 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNovaSenha(!showNovaSenha)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showNovaSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Confirmar Nova Senha *
                </label>
                <div className="relative">
                  <input
                    type={showConfirmarNovaSenha ? 'text' : 'password'}
                    value={confirmarNovaSenha}
                    onChange={(e) => setConfirmarNovaSenha(e.target.value)}
                    placeholder="Confirme a nova senha"
                    required
                    minLength={6}
                    className="w-full pl-3.5 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmarNovaSenha(!showConfirmarNovaSenha)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showConfirmarNovaSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={alterandoSenha || !novaSenha || !confirmarNovaSenha}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl shadow-lg transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {alterandoSenha ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Atualizando Senha...</span>
                    </>
                  ) : (
                    <>
                      <KeyRound className="w-4 h-4" />
                      <span>Salvar Nova Senha</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

        </div>
      )}

      {/* SUB-ABA: SIMULADOR DE PERFIS ESCOLARES (EXCLUSIVO PARA DIREÇÃO) */}
      {activeSubTab === 'simulacao' && canSimulate && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <Eye className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  Módulo de Simulação de Perfis Escolares
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Direção Escolar
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Teste o sistema exatamente sob a visão e permissões de cada um dos cargos escolares
                </p>
              </div>
            </div>

            {simulatedRole && onStopSimulation && (
              <button
                onClick={onStopSimulation}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-all cursor-pointer"
              >
                <EyeOff className="w-4 h-4" />
                <span>Encerrar Simulação Ativa</span>
              </button>
            )}
          </div>

          {simulatedRole && (
            <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Simulação em andamento:</strong> Você está navegando como{' '}
                  <span className="underline font-bold text-white">
                    {USER_ROLES[simulatedRole]?.label || simulatedRole}
                  </span>. Todas as telas e permissões foram adaptadas em tempo real.
                </span>
              </div>
              <button
                onClick={onStopSimulation}
                className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors shrink-0 cursor-pointer"
              >
                Restaurar Meu Acesso
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(['PROFESSOR', 'CGPG', 'SECRETARIA', 'PROFESSOR_PAAC', 'VICE_DIRETOR', 'DIRETOR'] as UserRole[]).map((role) => {
              const info = USER_ROLES[role];
              const isCurrentSim = simulatedRole === role;

              return (
                <div
                  key={role}
                  className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                    isCurrentSim
                      ? 'bg-amber-950/30 border-amber-500/60 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${info.badgeColor}`}>
                        {info.label}
                      </span>
                      {isCurrentSim && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-400 text-slate-950">
                          ATIVO
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {info.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80">
                    <button
                      type="button"
                      onClick={() => onStartSimulation && onStartSimulation(role)}
                      className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        isCurrentSim
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-900 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 border border-slate-800'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isCurrentSim ? 'Simulando Este Perfil' : `Simular ${info.label}`}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-ABA 1: BACKUPS (SUBIR E TIRAR BACKUP) */}
      {activeSubTab === 'backup' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* PAINEL 1: SUBIR BACKUP / IMPORTAR EQUIPAMENTOS */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Subir Backup / Importar Equipamentos</h3>
                  <p className="text-xs text-slate-400">Restaure inventário a partir de arquivos CSV, Excel ou JSON</p>
                </div>
              </div>

              {/* Botão de Atalho para Carregar Planilha Padrão */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="w-5 h-5 text-cyan-400 shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Carregar Planilha Base do Inventário</h4>
                    <p className="text-[11px] text-slate-400">Carrega a lista completa com Chromebooks, Notebooks, Desktops e Impressoras</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCarregarPlanilhaPadrao}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 text-xs font-bold transition-all shrink-0 cursor-pointer border border-cyan-500/20"
                >
                  Carregar
                </button>
              </div>

              {/* Área de Drag & Drop de Arquivo */}
              <div className="relative border-2 border-dashed border-slate-700 hover:border-cyan-500/50 rounded-2xl p-6 text-center transition-colors bg-slate-950/40">
                <input
                  type="file"
                  accept=".csv, .json, text/csv, application/json"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="flex flex-col items-center gap-2">
                  <div className="p-3 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                    <Upload className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-slate-200">
                    {importFile ? importFile.name : 'Clique para selecionar arquivo de backup (.csv ou .json)'}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Formatos suportados: Planilhas CSV exportadas ou Backups JSON do sistema
                  </p>
                </div>
              </div>

              {/* Opção de Modo de Importação */}
              <div className="flex items-center gap-4 text-xs text-slate-300 pt-1">
                <span className="font-semibold text-slate-400">Modo de Inserção:</span>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="importMode"
                    value="append"
                    checked={importMode === 'append'}
                    onChange={() => setImportMode('append')}
                    className="text-cyan-500 focus:ring-0"
                  />
                  <span>Acrescentar aos existentes</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="importMode"
                    value="replace"
                    checked={importMode === 'replace'}
                    onChange={() => setImportMode('replace')}
                    className="text-cyan-500 focus:ring-0"
                  />
                  <span className="text-amber-400">Substituir catálogo completo</span>
                </label>
              </div>

              {/* Pré-visualização de Itens Lidos */}
              {parsedPreview.length > 0 && (
                <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/30 text-xs text-cyan-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    <span>{parsedPreview.length} equipamentos identificados e prontos para gravação</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Exemplo: "{parsedPreview[0]?.nome}" ({parsedPreview[0]?.categoria})
                  </p>
                </div>
              )}

              {/* Mensagens de Sucesso e Erro */}
              {importSuccessMessage && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{importSuccessMessage}</span>
                </div>
              )}

              {importErrorMessage && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{importErrorMessage}</span>
                </div>
              )}

              {/* Barra de Progresso */}
              {importProgress && (
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>{importProgress.message}</span>
                    <span>{Math.round((importProgress.current / importProgress.total) * 100)}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-cyan-500 transition-all duration-200"
                      style={{ width: `${(importProgress.current / importProgress.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={importing || parsedPreview.length === 0}
              onClick={handleExecutarImportacao}
              className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/20 disabled:opacity-40 transition-all flex items-center justify-center gap-2 cursor-pointer mt-4"
            >
              {importing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Processando Importação no Firestore...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 stroke-[2.5]" />
                  <span>Gravar {parsedPreview.length > 0 ? `${parsedPreview.length} Itens no Catálogo` : 'Equipamentos'}</span>
                </>
              )}
            </button>
          </div>

          {/* PAINEL 2: TIRAR BACKUP / EXPORTAR DADOS */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Tirar Backup / Exportar Dados</h3>
                <p className="text-xs text-slate-400">Baixe cópias de segurança em formatos padrão</p>
              </div>
            </div>

            <div className="space-y-3">
              
              {/* Equipamentos CSV */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 hover:border-slate-700 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-200">Equipamentos (Planilha CSV)</h5>
                    <p className="text-[11px] text-slate-400">Compatível com Excel, Google Planilhas e LibreOffice</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleExportEquipamentosCSV}
                  className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-emerald-600 hover:text-white text-emerald-400 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 border border-slate-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar CSV</span>
                </button>
              </div>

              {/* Equipamentos JSON */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 hover:border-slate-700 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                    <FileJson className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-200">Equipamentos (Formato JSON)</h5>
                    <p className="text-[11px] text-slate-400">Arquivo estruturado para restaurações e integrações</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleExportEquipamentosJSON}
                  className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-blue-600 hover:text-white text-blue-400 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 border border-slate-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar JSON</span>
                </button>
              </div>

              {/* Empréstimos CSV */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 hover:border-slate-700 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-200">Empréstimos & Devoluções (CSV)</h5>
                    <p className="text-[11px] text-slate-400">Histórico de saídas, datas, solicitantes e status</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleExportEmprestimosCSV}
                  className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-amber-600 hover:text-white text-amber-400 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 border border-slate-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar CSV</span>
                </button>
              </div>

              {/* Backup Completo */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-slate-950 to-cyan-950/30 border border-cyan-500/30 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-cyan-200">Backup Completo Consolidado (JSON)</h5>
                    <p className="text-[11px] text-slate-400">Todos os equipamentos + histórico completo de empréstimos</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleExportBackupCompleto}
                  className="px-3.5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 shadow-md shadow-cyan-500/20"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Backup Geral</span>
                </button>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* SUB-ABA 2: USUÁRIOS & ACESSOS (PERFIS ESCOLARES & BULK UPLOAD) */}
      {activeSubTab === 'usuarios' && (
        <div className="space-y-6">
          
          {/* Seletor de Modo de Criação: Lote (Copiar & Colar) vs Individual */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-cyan-400" />
                Gestão de Usuários & Níveis de Acesso
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Cadastre professores, coordenação, secretaria e direção individualmente ou colando uma lista em lote
              </p>
            </div>

            <div className="inline-flex rounded-xl bg-slate-950 p-1 border border-slate-800 self-stretch sm:self-auto shadow-inner">
              <button
                type="button"
                onClick={() => setUserCreationMode('bulk')}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  userCreationMode === 'bulk'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <ClipboardPaste className="w-3.5 h-3.5" />
                <span>Subir em Lote (Copiar & Colar)</span>
              </button>

              <button
                type="button"
                onClick={() => setUserCreationMode('single')}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  userCreationMode === 'single'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Cadastro Individual</span>
              </button>
            </div>
          </div>

          {/* MODO 1: SUBIR USUÁRIOS EM LOTE (COPIAR & COLAR) */}
          {userCreationMode === 'bulk' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 mt-0.5">
                    <ClipboardPaste className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">
                      Subir Usuários em Lote (Copiar & Colar)
                    </h3>
                    <p className="text-xs text-slate-400">
                      Cole a relação de usuários diretamente do Excel, Planilhas ou bloco de notas na sequência:
                    </p>
                    <div className="inline-flex items-center gap-2 mt-2 px-3 py-1 rounded-lg bg-slate-950 border border-cyan-500/30 text-xs font-mono font-bold text-cyan-300">
                      <span>Nome</span>
                      <span className="text-slate-600">➔ [TAB] ➔</span>
                      <span>E-mail</span>
                      <span className="text-slate-600">➔ [TAB] ➔</span>
                      <span>Nível de Acesso</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start lg:self-center flex-wrap">
                  <button
                    type="button"
                    onClick={handleInserirExemploUsuarios}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Inserir Exemplo Pré-formatado</span>
                  </button>
                </div>
              </div>

              {/* Guia de Perfis Aceitos */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2.5">
                <p className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  Níveis de Acesso Suportados:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                  <div className="p-2 rounded-lg bg-slate-900 border border-sky-500/20 text-sky-300">
                    <span className="font-bold block font-mono">PROFESSOR</span>
                    <span className="text-[10px] text-slate-400">Docente regular</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-indigo-500/20 text-indigo-300">
                    <span className="font-bold block font-mono">CGPG</span>
                    <span className="text-[10px] text-slate-400">Coord. Pedagógica</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-teal-500/20 text-teal-300">
                    <span className="font-bold block font-mono">SECRETARIA</span>
                    <span className="text-[10px] text-slate-400">Secretaria Escolar</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-amber-500/20 text-amber-300">
                    <span className="font-bold block font-mono">VICE_DIRETOR</span>
                    <span className="text-[10px] text-slate-400">Vice-Direção</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-emerald-500/20 text-emerald-300">
                    <span className="font-bold block font-mono">PROFESSOR_PAAC</span>
                    <span className="text-[10px] text-slate-400">Prof. Apoio/TI</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-purple-500/20 text-purple-300">
                    <span className="font-bold block font-mono">DIRETOR</span>
                    <span className="text-[10px] text-slate-400">Direção Geral</span>
                  </div>
                </div>
              </div>

              {/* Área de Colagem e Configuração da Senha Inicial */}
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                <div className="lg:col-span-3 space-y-2">
                  <label className="block text-xs font-bold text-slate-300">
                    Área para Copiar e Colar a Lista:
                  </label>
                  <textarea
                    rows={7}
                    value={bulkUsersText}
                    onChange={(e) => setBulkUsersText(e.target.value)}
                    placeholder={`Exemplo de colagem:\nCarlos Silva\tcarlos.silva@educacao.sp.gov.br\tPROFESSOR\nMariana Costa\tmariana.costa@educacao.sp.gov.br\tCGPG\nFernanda Lima\tfernanda.lima@educacao.sp.gov.br\tSECRETARIA\nPaulo Roberto\tpaulo.roberto@educacao.sp.gov.br\tVICE_DIRETOR\nAna Paula Souza\tanapaula.souza@educacao.sp.gov.br\tPROFESSOR_PAAC\nRoberto Guergolet\troberto.diretor@educacao.sp.gov.br\tDIRETOR`}
                    className="w-full p-3.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 leading-relaxed shadow-inner"
                  />
                </div>

                <div className="lg:col-span-1 bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300">
                      Senha Inicial Padrão *
                    </label>
                    <p className="text-[11px] text-slate-500">
                      Senha provisória atribuída aos novos usuários criados no lote.
                    </p>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type={showBulkPassword ? 'text' : 'password'}
                        value={bulkDefaultPassword}
                        onChange={(e) => setBulkDefaultPassword(e.target.value)}
                        placeholder="Mínimo 6 caracteres"
                        className="w-full pl-9 pr-9 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowBulkPassword(!showBulkPassword)}
                        className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 cursor-pointer"
                      >
                        {showBulkPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleParseBulkUsers()}
                    className="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    <ClipboardPaste className="w-4 h-4" />
                    <span>Processar & Pré-visualizar</span>
                  </button>
                </div>
              </div>

              {/* Mensagens de Erro / Sucesso do Lote */}
              {bulkErrorMessage && (
                <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{bulkErrorMessage}</span>
                </div>
              )}

              {bulkSuccessReport && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs space-y-2">
                  <div className="flex items-center gap-2 font-bold text-emerald-200">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <span>Processamento em Lote Concluído!</span>
                  </div>
                  <p>
                    Foram processados <strong>{bulkSuccessReport.total} usuários</strong>: 
                    {bulkSuccessReport.created > 0 && ` ${bulkSuccessReport.created} novas contas criadas no Firebase Auth, `}
                    {bulkSuccessReport.updated > 0 && ` ${bulkSuccessReport.updated} contas sincronizadas no Firestore com o perfil correto.`}
                  </p>
                  {bulkSuccessReport.errorList.length > 0 && (
                    <div className="p-2.5 bg-slate-950/80 rounded-lg border border-amber-500/30 text-amber-300 space-y-1 mt-2">
                      <p className="font-bold">Avisos / Exceções durante o processo:</p>
                      {bulkSuccessReport.errorList.map((err, i) => (
                        <p key={i} className="text-[11px] font-mono">• {err}</p>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Barra de Progresso durante a criação */}
              {bulkProcessing && bulkProgress && (
                <div className="p-4 bg-slate-950 border border-cyan-500/40 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-cyan-300">
                    <span className="flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                      {bulkProgress.message}
                    </span>
                    <span>{bulkProgress.current} de {bulkProgress.total}</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(bulkProgress.current / bulkProgress.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Tabela de Pré-visualização dos Usuários Detectados */}
              {bulkParsedList.length > 0 && (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                      <Users className="w-4 h-4 text-cyan-400" />
                      Pré-visualização dos Usuários a Serem Criados ({bulkParsedList.length})
                    </h4>
                    <span className="text-[11px] text-slate-400">
                      Você pode ajustar os níveis de acesso individualmente abaixo antes de confirmar.
                    </span>
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="p-3">#</th>
                          <th className="p-3">Nome Completo</th>
                          <th className="p-3">E-mail</th>
                          <th className="p-3">Usuário Gerado</th>
                          <th className="p-3">Nível de Acesso (Perfil)</th>
                          <th className="p-3">Validação</th>
                          <th className="p-3 text-right">Ação</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 text-slate-200">
                        {bulkParsedList.map((item, idx) => {
                          const roleCfg = USER_ROLES[item.perfil] || USER_ROLES.PROFESSOR;
                          return (
                            <tr key={item.id} className="hover:bg-slate-900/40">
                              <td className="p-3 text-slate-500 font-mono">{idx + 1}</td>
                              <td className="p-3 font-semibold text-white">
                                <input
                                  type="text"
                                  value={item.nome}
                                  onChange={(e) => handleUpdateBulkUserItem(item.id, 'nome', e.target.value)}
                                  className="px-2 py-1 bg-slate-900 border border-slate-700/60 rounded text-xs text-white focus:outline-none focus:border-cyan-500 w-full"
                                />
                              </td>
                              <td className="p-3 text-cyan-300 font-mono text-[11px]">
                                <input
                                  type="email"
                                  value={item.email}
                                  onChange={(e) => handleUpdateBulkUserItem(item.id, 'email', e.target.value)}
                                  className="px-2 py-1 bg-slate-900 border border-slate-700/60 rounded text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-500 w-full"
                                />
                              </td>
                              <td className="p-3 text-slate-400 font-mono text-[11px]">
                                @{item.usuario}
                              </td>
                              <td className="p-3">
                                <select
                                  value={item.perfil}
                                  onChange={(e) => handleUpdateBulkUserItem(item.id, 'perfil', e.target.value)}
                                  className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-bold text-white focus:outline-none focus:border-cyan-500"
                                >
                                  <option value="PROFESSOR">PROFESSOR (Docente)</option>
                                  <option value="CGPG">CGPG (Coord. Pedagógica)</option>
                                  <option value="SECRETARIA">SECRETARIA (Secretaria Escolar)</option>
                                  <option value="VICE_DIRETOR">VICE_DIRETOR (Vice-Direção)</option>
                                  <option value="PROFESSOR_PAAC">PROFESSOR_PAAC (Apoio TI/Pedagógico)</option>
                                  <option value="DIRETOR">DIRETOR (Direção Escolar)</option>
                                  <option value="adm">ADM (Administrador de TI)</option>
                                  <option value="adm_total">ADM_TOTAL (Master Total)</option>
                                </select>
                              </td>
                              <td className="p-3">
                                {item.valid ? (
                                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                                    <Check className="w-3.5 h-3.5" />
                                    <span>Válido</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-400" title={item.error}>
                                    <AlertTriangle className="w-3.5 h-3.5" />
                                    <span>{item.error || 'Inválido'}</span>
                                  </span>
                                )}
                              </td>
                              <td className="p-3 text-right">
                                <button
                                  type="button"
                                  onClick={() => handleRemoveBulkUserItem(item.id)}
                                  title="Remover linha"
                                  className="p-1 rounded hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setBulkParsedList([])}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Limpar Pré-visualização
                    </button>

                    <button
                      type="button"
                      disabled={bulkProcessing || bulkParsedList.length === 0}
                      onClick={handleExecutarUploadUsuariosLote}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {bulkProcessing ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Criando Usuários no Firebase...</span>
                        </>
                      ) : (
                        <>
                          <CheckCheck className="w-4 h-4 stroke-[2.5]" />
                          <span>Criar e Sincronizar Todos ({bulkParsedList.length}) Usuários</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* MODO 2: CADASTRO INDIVIDUAL */}
          {userCreationMode === 'single' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Cadastro Individual de Usuário</h3>
                  <p className="text-xs text-slate-400">Crie uma conta específica escolhendo o nível de acesso desejado</p>
                </div>
              </div>

              <form onSubmit={handleCadastrarUsuario} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Nome Completo */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nome Completo *
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      placeholder="Ex: Carlos Silva"
                      value={userFormData.nome}
                      onChange={(e) => setUserFormData({ ...userFormData, nome: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    E-mail Institucional *
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      placeholder="carlos.silva@educacao.sp.gov.br"
                      value={userFormData.email}
                      onChange={(e) => setUserFormData({ ...userFormData, email: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Usuário / Login */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nome de Usuário (Login)
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      placeholder="Ex: carlos.silva (opcional)"
                      value={userFormData.usuario}
                      onChange={(e) => setUserFormData({ ...userFormData, usuario: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Senha */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Senha Inicial *
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="Mínimo 6 caracteres"
                      value={userFormData.senha}
                      onChange={(e) => setUserFormData({ ...userFormData, senha: e.target.value })}
                      className="w-full pl-9 pr-10 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Nível de Acesso */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nível de Acesso (Perfil) *
                  </label>
                  <select
                    value={userFormData.perfil}
                    onChange={(e) => setUserFormData({ ...userFormData, perfil: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                  >
                    <option value="PROFESSOR">PROFESSOR (Docente - Consulta e Empréstimos)</option>
                    <option value="CGPG">CGPG (Coordenação Geral Pedagógica)</option>
                    <option value="SECRETARIA">SECRETARIA (Secretaria Escolar)</option>
                    <option value="VICE_DIRETOR">VICE_DIRETOR (Vice-Direção)</option>
                    <option value="PROFESSOR_PAAC">PROFESSOR_PAAC (Apoio Pedagógico/TI)</option>
                    <option value="DIRETOR">DIRETOR (Direção Geral)</option>
                    <option value="adm">ADM (Administrador de Inventário & Backups)</option>
                    <option value="adm_total">ADM TOTAL (Super Administrador Master)</option>
                  </select>
                </div>

                {/* Botão de Envio */}
                <div className="flex items-end">
                  <button
                    type="submit"
                    disabled={creatingUser}
                    className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {creatingUser ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Criando Usuário...</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Salvar Usuário</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Feedback */}
                {userSuccessMessage && (
                  <div className="sm:col-span-2 lg:col-span-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{userSuccessMessage}</span>
                  </div>
                )}

                {userErrorMessage && (
                  <div className="sm:col-span-2 lg:col-span-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{userErrorMessage}</span>
                  </div>
                )}
              </form>
            </div>
          )}

          {/* TABELA DE USUÁRIOS CADASTRADOS & FILTROS */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Usuários Cadastrados no Sistema</h3>
                  <p className="text-xs text-slate-400">Relação completa de contas ativas e perfis escolares</p>
                </div>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-950 border border-slate-800 text-slate-300 self-start sm:self-auto">
                {usuarios.length} {usuarios.length === 1 ? 'usuário cadastrado' : 'usuários cadastrados'}
              </span>
            </div>

            {/* Barra de Filtros e Busca */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2 relative">
                <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Buscar por nome, e-mail ou login..."
                  value={userSearchTerm}
                  onChange={(e) => setUserSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="sm:col-span-1">
                <select
                  value={userFilterRole}
                  onChange={(e) => setUserFilterRole(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="TODOS">Todos os Níveis de Acesso</option>
                  <option value="PROFESSOR">PROFESSOR</option>
                  <option value="CGPG">CGPG</option>
                  <option value="SECRETARIA">SECRETARIA</option>
                  <option value="VICE_DIRETOR">VICE_DIRETOR</option>
                  <option value="PROFESSOR_PAAC">PROFESSOR_PAAC</option>
                  <option value="DIRETOR">DIRETOR</option>
                  <option value="adm">ADM</option>
                  <option value="adm_total">ADM TOTAL</option>
                </select>
              </div>
            </div>

            {/* Listagem */}
            {(() => {
              const filteredList = usuarios.filter((u) => {
                const search = userSearchTerm.toLowerCase();
                const matchesSearch = 
                  (u.nome || '').toLowerCase().includes(search) ||
                  (u.email || '').toLowerCase().includes(search) ||
                  (u.usuario || '').toLowerCase().includes(search);

                const normalizedRole = normalizeUserRole(u.perfil);
                let matchesRole = true;
                if (userFilterRole !== 'TODOS') {
                  matchesRole = normalizedRole === userFilterRole;
                }

                return matchesSearch && matchesRole;
              });

              if (filteredList.length === 0) {
                return (
                  <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-slate-800 space-y-2">
                    <Users className="w-8 h-8 text-slate-600 mx-auto" />
                    <p className="text-xs text-slate-400">
                      Nenhum usuário encontrado com os filtros selecionados.
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Utilize o botão "Subir em Lote (Copiar & Colar)" acima para cadastrar a relação de docentes e equipe escolar.
                    </p>
                  </div>
                );
              }

              return (
                <div className="overflow-x-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-3">Nome</th>
                        <th className="p-3">E-mail</th>
                        <th className="p-3">Usuário (Login)</th>
                        <th className="p-3">Nível de Acesso (Perfil)</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70 text-slate-200">
                      {filteredList.map((u) => {
                        const isSuperMaster = isSuperAdminEmail(u.email) || isSuperAdminEmail(u.usuario);
                        const role = isSuperMaster ? 'adm_total' : normalizeUserRole(u.perfil);
                        const roleConfig = USER_ROLES[role] || USER_ROLES.PROFESSOR;
                        const displayUsername = u.usuario || u.email?.split('@')[0] || 'usuario';

                        return (
                          <tr key={u.id || u.uid} className={`hover:bg-slate-950/50 ${isSuperMaster ? 'bg-amber-500/5' : ''}`}>
                            <td className="p-3 font-semibold text-white flex items-center gap-1.5">
                              {isSuperMaster && <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                              <span>{u.nome || displayUsername}</span>
                            </td>
                            <td className="p-3 text-slate-300 font-mono text-[11px]">
                              {u.email || '-'}
                            </td>
                            <td className="p-3 text-cyan-300 font-mono text-[11px] font-semibold">
                              @{displayUsername}
                            </td>
                            <td className="p-3">
                              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md border text-[11px] font-bold ${roleConfig.badgeColor}`}>
                                {role === 'adm_total' && <Crown className="w-3 h-3 text-amber-300" />}
                                {role === 'DIRETOR' && <Crown className="w-3 h-3 text-purple-300" />}
                                {role === 'VICE_DIRETOR' && <ShieldCheck className="w-3 h-3 text-amber-300" />}
                                {role === 'CGPG' && <BookOpen className="w-3 h-3 text-indigo-300" />}
                                {role === 'SECRETARIA' && <FileSpreadsheet className="w-3 h-3 text-teal-300" />}
                                {role === 'PROFESSOR_PAAC' && <Sparkles className="w-3 h-3 text-emerald-300" />}
                                {role === 'PROFESSOR' && <GraduationCap className="w-3 h-3 text-sky-400" />}
                                {role === 'adm' && <ShieldCheck className="w-3 h-3 text-cyan-400" />}
                                <span>{roleConfig.label}</span>
                              </span>
                            </td>
                            <td className="p-3">
                              {isSuperMaster ? (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                                  Master Ativo
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleToggleStatusUsuario(u)}
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border cursor-pointer transition-colors ${
                                    u.status === 'ativo'
                                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                                  }`}
                                >
                                  {u.status === 'ativo' ? 'Ativo' : 'Inativo'}
                                </button>
                              )}
                            </td>
                            <td className="p-3 text-right">
                              {!isSuperMaster && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteUsuario(u.id || u.uid, u.email)}
                                  title="Remover usuário da lista"
                                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              );
            })()}
          </div>

        </div>
      )}

      {/* SUB-ABA 3: RESUMO DO BANCO E ESTATÍSTICAS */}
      {activeSubTab === 'sistema' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-medium">Equipamentos Cadastrados</span>
                <Boxes className="w-5 h-5 text-cyan-400" />
              </div>
              <div className="text-3xl font-black text-white">{equipamentos.length}</div>
              <div className="text-xs text-slate-500 mt-2">
                Itens rastreados no inventário físico
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-medium">Empréstimos Ativos</span>
                <ArrowRightLeft className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-3xl font-black text-amber-400">
                {emprestimos.filter(e => e.status !== 'Devolvido').length}
              </div>
              <div className="text-xs text-slate-500 mt-2">
                Itens atualmente emprestados
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-medium">Devoluções Concluídas</span>
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-3xl font-black text-emerald-400">
                {emprestimos.filter(e => e.status === 'Devolvido').length}
              </div>
              <div className="text-xs text-slate-500 mt-2">
                Histórico de devoluções baixadas
              </div>
            </div>

          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              Informações do Ambiente & Credenciais Master
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400">Administrador Total Master:</span>
                <p className="font-mono text-cyan-300 font-bold">{SUPER_ADMIN_EMAIL}</p>
                <p className="text-[11px] text-slate-500">Possui controle irrestrito de banco, usuários e dados.</p>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400">Banco de Dados:</span>
                <p className="font-mono text-emerald-400 font-bold">Cloud Firestore (Tempo Real)</p>
                <p className="text-[11px] text-slate-500">Coleções: /equipamentos, /emprestimos, /usuarios</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
