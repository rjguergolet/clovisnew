import React, { useState, useEffect, useMemo } from 'react';
import { Equipamento, Kit, KitItem, Emprestimo } from '../types';
import { isEquipamentoAptoParaEmprestimo } from '../lib/userRoles';
import { AULAS_MANHA, AULAS_TARDE, determineTurnoFromAulas } from '../lib/schoolSchedule';
import { 
  getEquipamentoIndisponibilidadeMap, 
  validateAgendamento, 
  ConflitoAgendamento 
} from '../lib/loanConflictChecker';
import MultiEquipamentoSelector from './MultiEquipamentoSelector';
import { 
  X, 
  ArrowRightLeft, 
  Package, 
  Boxes, 
  CheckSquare, 
  User, 
  School, 
  CalendarDays, 
  Clock, 
  Check, 
  Loader2, 
  Sparkles,
  Search,
  ChevronDown,
  Repeat,
  Info,
  AlertTriangle,
  Ban
} from 'lucide-react';

interface AgendamentoRapidoModalProps {
  isOpen: boolean;
  onClose: () => void;
  equipamentos: Equipamento[];
  kits: Kit[];
  emprestimos?: Emprestimo[];
  currentUserName?: string;
  initialEquipamento?: any;
  onConfirm: (formData: any) => Promise<void>;
  loading?: boolean;
}

const TURMAS_SUGERIDAS = [
  '6º Ano A', '6º Ano B',
  '7º Ano A', '7º Ano B',
  '8º Ano A', '8º Ano B',
  '9º Ano A', '9º Ano B',
  '1ª Série EM', '2ª Série EM', '3ª Série EM',
  'Sala de Leitura', 'Lab. de Informática', 'Sala dos Professores'
];

export default function AgendamentoRapidoModal({
  isOpen,
  onClose,
  equipamentos,
  kits,
  emprestimos = [],
  currentUserName = '',
  initialEquipamento,
  onConfirm,
  loading = false
}: AgendamentoRapidoModalProps) {
  if (!isOpen) return null;

  const getTodayDateString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const getTomorrowDateString = () => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const todayStr = getTodayDateString();
  const tomorrowStr = getTomorrowDateString();

  // Modo de seleção: 'individual', 'kit', 'lote'
  const [tipoSelecao, setTipoSelecao] = useState<'individual' | 'kit' | 'lote'>('individual');
  const [selectedEqId, setSelectedEqId] = useState<string>('');
  const [selectedKitId, setSelectedKitId] = useState<string>('');
  const [selectedLoteItems, setSelectedLoteItems] = useState<KitItem[]>([]);
  
  // Solicitante e Local
  const [solicitante, setSolicitante] = useState<string>(currentUserName || '');
  const [turmaOuSala, setTurmaOuSala] = useState<string>('');
  const [contato, setContato] = useState<string>('');
  
  // Data e Aulas
  const [dataAgendada, setDataAgendada] = useState<string>(todayStr);
  const [selectedAulas, setSelectedAulas] = useState<string[]>(['M1', 'M2']);

  // Opções Avançadas (Observações e Recorrência)
  const [showAvancadas, setShowAvancadas] = useState<boolean>(false);
  const [observacoes, setObservacoes] = useState<string>('');
  const [isRecorrente, setIsRecorrente] = useState<boolean>(false);
  const [diasSemana, setDiasSemana] = useState<number[]>([1, 3]); // Seg e Qua
  const [dataFimRecorrencia, setDataFimRecorrencia] = useState<string>(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    return d.toISOString().split('T')[0];
  });

  // Mapa de Indisponibilidade para o dia e aulas selecionados
  const indisponibilidadeMap = useMemo(() => {
    return getEquipamentoIndisponibilidadeMap(dataAgendada, selectedAulas, emprestimos, kits);
  }, [dataAgendada, selectedAulas, emprestimos, kits]);

  // Equipamentos Aptos (Ativos, Operacionais e NUNCA de uso fixo/permanente)
  const equipamentosAptos = useMemo(() => {
    return equipamentos.filter(eq => isEquipamentoAptoParaEmprestimo(eq) && !eq.usoPermanente);
  }, [equipamentos]);

  // Separação entre disponíveis e já agendados no dia/horário selecionados
  const { equipamentosDisponiveis, equipamentosAgendados } = useMemo(() => {
    const disp: Equipamento[] = [];
    const agend: { eq: Equipamento; conflito: ConflitoAgendamento }[] = [];

    equipamentosAptos.forEach(eq => {
      const conflito = eq.id ? indisponibilidadeMap.get(eq.id) : undefined;
      if (conflito) {
        agend.push({ eq, conflito });
      } else {
        disp.push(eq);
      }
    });

    return { equipamentosDisponiveis: disp, equipamentosAgendados: agend };
  }, [equipamentosAptos, indisponibilidadeMap]);

  // Conflito do item individual atualmente selecionado (se houver)
  const conflitoAtual = useMemo(() => {
    if (tipoSelecao !== 'individual' || !selectedEqId) return null;
    return indisponibilidadeMap.get(selectedEqId) || null;
  }, [tipoSelecao, selectedEqId, indisponibilidadeMap]);

  // Kits com status de disponibilidade (desativa se algum item do kit estiver em uso ou agendado)
  const kitsComStatus = useMemo(() => {
    return kits.filter(k => k.status !== 'Inativo').map(kit => {
      let itemConflitante: { itemNome: string; solicitante: string; aulas: string[] } | null = null;
      if (kit.itens && kit.itens.length > 0) {
        for (const it of kit.itens) {
          if (it.equipamentoId && indisponibilidadeMap.has(it.equipamentoId)) {
            const c = indisponibilidadeMap.get(it.equipamentoId)!;
            itemConflitante = {
              itemNome: it.nome,
              solicitante: c.solicitante,
              aulas: c.aulasConflitantes
            };
            break;
          }
        }
      }
      return {
        kit,
        isBloqueado: Boolean(itemConflitante),
        conflito: itemConflitante
      };
    });
  }, [kits, indisponibilidadeMap]);

  // Conflito do Kit atualmente selecionado
  const conflitoKitAtual = useMemo(() => {
    if (tipoSelecao !== 'kit' || !selectedKitId) return null;
    const found = kitsComStatus.find(k => k.kit.id === selectedKitId);
    return found?.conflito || null;
  }, [tipoSelecao, selectedKitId, kitsComStatus]);

  // Inicializar se vier equipamento pré-selecionado
  useEffect(() => {
    if (initialEquipamento) {
      if (initialEquipamento.tipoEmprestimo === 'kit' || initialEquipamento.kit) {
        setTipoSelecao('kit');
        const kId = initialEquipamento.kit?.id || initialEquipamento.id;
        setSelectedKitId(kId);
      } else {
        setTipoSelecao('individual');
        setSelectedEqId(initialEquipamento.id || '');
      }
    } else if (!selectedEqId) {
      // Prioriza selecionar o primeiro disponível
      if (equipamentosDisponiveis.length > 0) {
        setSelectedEqId(equipamentosDisponiveis[0].id || '');
      } else if (equipamentosAptos.length > 0) {
        setSelectedEqId(equipamentosAptos[0].id || '');
      }
    }
  }, [initialEquipamento, equipamentosDisponiveis, equipamentosAptos]);

  // Atalhos de Equipamentos Populares (escolhe um que esteja disponível no momento)
  const handleSelectPopular = (termo: string) => {
    setTipoSelecao('individual');
    const dispFound = equipamentosDisponiveis.find(e => 
      e.nome.toLowerCase().includes(termo.toLowerCase()) || 
      e.categoria.toLowerCase().includes(termo.toLowerCase())
    );
    if (dispFound && dispFound.id) {
      setSelectedEqId(dispFound.id);
      return;
    }

    const anyFound = equipamentosAptos.find(e => 
      e.nome.toLowerCase().includes(termo.toLowerCase()) || 
      e.categoria.toLowerCase().includes(termo.toLowerCase())
    );
    if (anyFound && anyFound.id) {
      setSelectedEqId(anyFound.id);
    }
  };

  // Alternar aula individual
  const toggleAula = (aulaId: string) => {
    setSelectedAulas(prev => 
      prev.includes(aulaId) ? prev.filter(id => id !== aulaId) : [...prev, aulaId]
    );
  };

  // Atalhos de Aulas
  const selecionarTodaManha = () => {
    setSelectedAulas(AULAS_MANHA.map(a => a.id));
  };

  const selecionarTodaTarde = () => {
    setSelectedAulas(AULAS_TARDE.map(a => a.id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!solicitante.trim()) {
      alert('Por favor, informe o nome do Professor ou Solicitante.');
      return;
    }

    if (selectedAulas.length === 0) {
      alert('Por favor, selecione ao menos uma aula para o agendamento.');
      return;
    }

    let finalEqId = selectedEqId;
    let finalEqNome = '';
    let finalItens: KitItem[] | null = null;
    let finalQtdTotal = 1;

    if (tipoSelecao === 'kit') {
      if (!selectedKitId) {
        alert('Selecione um Kit da lista.');
        return;
      }
      const kitObj = kits.find(k => k.id === selectedKitId);
      finalEqId = selectedKitId;
      finalEqNome = `[KIT] ${kitObj?.nome || 'Kit'} (${kitObj?.totalItens || 1} itens)`;
      finalItens = kitObj?.itens || null;
      finalQtdTotal = kitObj?.totalItens || 1;
    } else if (tipoSelecao === 'lote') {
      if (selectedLoteItems.length === 0) {
        alert('Selecione pelo menos um equipamento nas caixas de seleção.');
        return;
      }
      finalItens = selectedLoteItems;
      finalQtdTotal = selectedLoteItems.reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);
      finalEqId = selectedLoteItems[0]?.equipamentoId || 'lote';
      if (selectedLoteItems.length === 1) {
        finalEqNome = `${selectedLoteItems[0].quantidade}x ${selectedLoteItems[0].nome}`;
      } else {
        finalEqNome = `${finalQtdTotal} Itens: ${selectedLoteItems.map(i => `${i.quantidade}x ${i.nome}`).join(', ')}`;
      }
    } else {
      if (!selectedEqId) {
        alert('Selecione um equipamento.');
        return;
      }
      const eqObj = equipamentosAptos.find(e => e.id === selectedEqId);
      finalEqId = selectedEqId;
      finalEqNome = eqObj ? `${eqObj.nome}${eqObj.patrimonio ? ` (Patr: ${eqObj.patrimonio})` : ''}` : 'Equipamento';
      finalItens = eqObj ? [{
        equipamentoId: eqObj.id || '',
        nome: eqObj.nome,
        patrimonio: eqObj.patrimonio || null,
        categoria: eqObj.categoria || 'Geral',
        quantidade: 1
      }] : null;
      finalQtdTotal = 1;
    }

    // Validação Estrita Contra Conflitos e Uso Fixo / Inativo
    const validacao = validateAgendamento({
      tipoEmprestimo: tipoSelecao,
      equipamentoId: selectedEqId,
      kitId: selectedKitId,
      itens: tipoSelecao === 'lote' ? selectedLoteItems : finalItens,
      data: dataAgendada,
      aulas: selectedAulas,
      isRecorrente,
      diasSemana,
      dataFimRecorrencia,
      equipamentos,
      kits,
      emprestimos
    });

    if (!validacao.isValid) {
      alert(validacao.errorMessage || 'Não foi possível agendar devido a conflito de agendamento ou equipamento indisponível.');
      return;
    }

    const payload = {
      tipoEmprestimo: tipoSelecao,
      equipamentoId: finalEqId,
      equipamentoNome: finalEqNome,
      kitId: tipoSelecao === 'kit' ? selectedKitId : null,
      kitNome: tipoSelecao === 'kit' ? (kits.find(k => k.id === selectedKitId)?.nome || null) : null,
      itensEmprestados: finalItens,
      quantidadeTotal: finalQtdTotal,
      selectedEquipamentos: tipoSelecao === 'lote' ? selectedLoteItems : [],
      solicitante: solicitante.trim(),
      turmaOuSala: turmaOuSala.trim() || null,
      contato: contato.trim() || null,
      dataRetirada: dataAgendada,
      dataDevolucao: dataAgendada,
      dataAgendamento: dataAgendada,
      aulas: selectedAulas,
      status: 'Pendente',
      retirado: false,
      observacoes: observacoes.trim() || null,
      isRecorrente,
      diasSemana,
      dataFimRecorrencia
    };

    await onConfirm(payload);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Limpo */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <ArrowRightLeft className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                Novo Agendamento Rápido
              </h3>
              <p className="text-xs text-slate-400">
                Reserve equipamentos para suas aulas em menos de 30 segundos
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={loading}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulário Ágil */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* PASSO 1: QUAL EQUIPAMENTO? */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-4 h-4 rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center text-[10px]">1</span>
                <span>Qual equipamento você precisa? *</span>
              </label>

              {/* Alternador de Modo: Individual vs Kit vs Lote */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setTipoSelecao('individual')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                    tipoSelecao === 'individual' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Individual
                </button>
                <button
                  type="button"
                  onClick={() => setTipoSelecao('kit')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                    tipoSelecao === 'kit' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Kit
                </button>
                <button
                  type="button"
                  onClick={() => setTipoSelecao('lote')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                    tipoSelecao === 'lote' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Vários Itens
                </button>
              </div>
            </div>

            {/* Chips de Atalhos dos Equipamentos Mais Usados */}
            {tipoSelecao === 'individual' && (
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                <span className="text-[11px] text-slate-400">Atalhos rápidos:</span>
                {['Projetor', 'Caixa de Som', 'Chromebook', 'Robótica', 'Microfone'].map((itemTag) => (
                  <button
                    key={itemTag}
                    type="button"
                    onClick={() => handleSelectPopular(itemTag)}
                    className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-800 text-xs font-medium transition-colors cursor-pointer"
                  >
                    + {itemTag}
                  </button>
                ))}
              </div>
            )}

            {/* Campo de Seleção do Equipamento */}
            {tipoSelecao === 'individual' && (
              <div className="space-y-2">
                <select
                  value={selectedEqId}
                  onChange={(e) => setSelectedEqId(e.target.value)}
                  required
                  className={`w-full px-3.5 py-2.5 bg-slate-950 border rounded-xl text-sm text-white focus:outline-none focus:ring-2 ${
                    conflitoAtual ? 'border-rose-700 focus:ring-rose-500' : 'border-slate-800 focus:ring-cyan-400'
                  }`}
                >
                  <option value="">-- Selecione o Equipamento --</option>
                  {equipamentosDisponiveis.length > 0 && (
                    <optgroup label="✅ Disponíveis no Horário Selecionado">
                      {equipamentosDisponiveis.map(eq => (
                        <option key={eq.id} value={eq.id}>
                          {eq.nome} {eq.patrimonio ? `(Patr: ${eq.patrimonio})` : ''} - {eq.categoria || 'Geral'}
                        </option>
                      ))}
                    </optgroup>
                  )}
                  {equipamentosAgendados.length > 0 && (
                    <optgroup label="🚫 Já Agendados / Ocupados no Horário">
                      {equipamentosAgendados.map(({ eq, conflito }) => (
                        <option key={eq.id} value={eq.id} disabled>
                          {eq.nome} {eq.patrimonio ? `(Patr: ${eq.patrimonio})` : ''} [🚫 {conflito.solicitante} - {conflito.aulasConflitantes.join(', ')}]
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>

                {conflitoAtual && (
                  <div className="p-3 bg-rose-950/50 border border-rose-800/80 rounded-xl flex items-start gap-2.5 text-rose-300 text-xs animate-in fade-in">
                    <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-rose-200">⚠️ Conflito de Agendamento:</p>
                      <p className="mt-0.5 leading-relaxed">
                        Este equipamento já está agendado para <strong className="text-white">{conflitoAtual.solicitante}</strong>
                        {conflitoAtual.turmaOuSala ? ` (${conflitoAtual.turmaOuSala})` : ''} no dia{' '}
                        <strong className="text-white">{conflitoAtual.data.split('-').reverse().join('/')}</strong> na(s) aula(s){' '}
                        <strong className="text-white">{conflitoAtual.aulasConflitantes.join(', ')}</strong>.
                      </p>
                      <p className="mt-1 font-semibold text-rose-400">
                        Por favor, selecione outro equipamento da lista acima ou altere a data e as aulas.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tipoSelecao === 'kit' && (
              <div className="space-y-2">
                <select
                  value={selectedKitId}
                  onChange={(e) => setSelectedKitId(e.target.value)}
                  required
                  className={`w-full px-3.5 py-2.5 bg-slate-950 border rounded-xl text-sm text-white focus:outline-none focus:ring-2 ${
                    conflitoKitAtual ? 'border-rose-700 focus:ring-rose-500' : 'border-slate-800 focus:ring-cyan-400'
                  }`}
                >
                  <option value="">-- Escolha um Kit de Equipamentos --</option>
                  {kitsComStatus.map(({ kit, isBloqueado, conflito }) => (
                    <option key={kit.id} value={kit.id} disabled={isBloqueado}>
                      {kit.nome} ({kit.totalItens} itens) - {kit.categoria || 'Geral'} {isBloqueado ? `[🚫 Ocupado: ${conflito?.itemNome} p/ ${conflito?.solicitante}]` : '✅ Disponível'}
                    </option>
                  ))}
                </select>

                {conflitoKitAtual && (
                  <div className="p-3 bg-rose-950/50 border border-rose-800/80 rounded-xl flex items-start gap-2.5 text-rose-300 text-xs animate-in fade-in">
                    <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-rose-200">⚠️ Kit Indisponível:</p>
                      <p className="mt-0.5 leading-relaxed">
                        O item <strong className="text-white">"{conflitoKitAtual.itemNome}"</strong> deste kit já está agendado para <strong className="text-white">{conflitoKitAtual.solicitante}</strong> na(s) aula(s){' '}
                        <strong className="text-white">{conflitoKitAtual.aulas.join(', ')}</strong>.
                      </p>
                      <p className="mt-1 font-semibold text-rose-400">
                        Selecione outro kit ou mude o horário do agendamento.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tipoSelecao === 'lote' && (
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                <MultiEquipamentoSelector
                  equipamentos={equipamentosAptos}
                  selectedItems={selectedLoteItems}
                  onChange={setSelectedLoteItems}
                  title="Marque os equipamentos desejados:"
                  indisponibilidadeMap={indisponibilidadeMap}
                />
              </div>
            )}
          </div>

          {/* PASSO 2: PROFESSOR E SALA */}
          <div className="space-y-2.5 pt-2 border-t border-slate-800/80">
            <label className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center text-[10px]">2</span>
              <span>Quem vai usar e onde? *</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Professor(a) Solicitante *</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    placeholder="Nome do Professor"
                    value={solicitante}
                    onChange={(e) => setSolicitante(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Turma ou Sala</label>
                <div className="relative">
                  <School className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Ex: 8º Ano B, Lab 01"
                    value={turmaOuSala}
                    onChange={(e) => setTurmaOuSala(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>
              </div>
            </div>

            {/* Sugestões Rápidas de Turmas com 1 Clique */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-[11px] text-slate-500">Turmas:</span>
              {TURMAS_SUGERIDAS.slice(0, 6).map((turma) => (
                <button
                  key={turma}
                  type="button"
                  onClick={() => setTurmaOuSala(turma)}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium border transition-colors cursor-pointer ${
                    turmaOuSala === turma 
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' 
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {turma}
                </button>
              ))}
            </div>
          </div>

          {/* PASSO 3: DATA E AULAS */}
          <div className="space-y-2.5 pt-2 border-t border-slate-800/80">
            <label className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center text-[10px]">3</span>
              <span>Para quando você precisa? *</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              {/* Seleção da Data */}
              <div className="space-y-1.5">
                <span className="text-xs text-slate-400">Data do Agendamento:</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setDataAgendada(todayStr)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      dataAgendada === todayStr
                        ? 'bg-cyan-500 text-slate-950 shadow-md'
                        : 'bg-slate-950 text-slate-300 border border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    Hoje
                  </button>
                  <button
                    type="button"
                    onClick={() => setDataAgendada(tomorrowStr)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      dataAgendada === tomorrowStr
                        ? 'bg-cyan-500 text-slate-950 shadow-md'
                        : 'bg-slate-950 text-slate-300 border border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    Amanhã
                  </button>
                </div>

                <input
                  type="date"
                  value={dataAgendada}
                  onChange={(e) => setDataAgendada(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-400"
                />
              </div>

              {/* Seleção das Aulas */}
              <div className="sm:col-span-2 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Aulas que irá usar:</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={selecionarTodaManha}
                      className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-cyan-300 hover:bg-slate-700 font-semibold cursor-pointer"
                    >
                      Toda Manhã
                    </button>
                    <button
                      type="button"
                      onClick={selecionarTodaTarde}
                      className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-300 hover:bg-slate-700 font-semibold cursor-pointer"
                    >
                      Toda Tarde
                    </button>
                  </div>
                </div>

                {/* Grid das Aulas da Manhã */}
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold">Manhã:</span>
                  <div className="grid grid-cols-7 gap-1 mt-0.5">
                    {AULAS_MANHA.map(aula => {
                      const isSelected = selectedAulas.includes(aula.id);
                      return (
                        <button
                          key={aula.id}
                          type="button"
                          onClick={() => toggleAula(aula.id)}
                          className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-500 text-slate-950 shadow-sm'
                              : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                          }`}
                          title={`${aula.label} (${aula.horario})`}
                        >
                          {aula.id}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Grid das Aulas da Tarde */}
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold">Tarde:</span>
                  <div className="grid grid-cols-7 gap-1 mt-0.5">
                    {AULAS_TARDE.map(aula => {
                      const isSelected = selectedAulas.includes(aula.id);
                      return (
                        <button
                          key={aula.id}
                          type="button"
                          onClick={() => toggleAula(aula.id)}
                          className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500 text-slate-950 shadow-sm'
                              : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                          }`}
                          title={`${aula.label} (${aula.horario})`}
                        >
                          {aula.id}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* OPÇÃO DE EXPANDIR CONFIGURAÇÕES AVANÇADAS (RECORRÊNCIA E OBSERVAÇÕES) */}
          <div className="pt-2 border-t border-slate-800/80">
            <button
              type="button"
              onClick={() => setShowAvancadas(!showAvancadas)}
              className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 font-semibold cursor-pointer transition-colors"
            >
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAvancadas ? 'rotate-180' : ''}`} />
              <span>{showAvancadas ? 'Ocultar Opções Avançadas' : 'Mais Opções (Observações / Repetição Semanal Fixo)'}</span>
            </button>

            {showAvancadas && (
              <div className="mt-3 p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 animate-in fade-in duration-150">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Observações adicionais:</label>
                  <textarea
                    rows={2}
                    placeholder="Algum aviso especial para o almoxarifado ou especificidade de uso..."
                    value={observacoes}
                    onChange={(e) => setObservacoes(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-400"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="chkRecorrenteRapido"
                    checked={isRecorrente}
                    onChange={(e) => setIsRecorrente(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-400 cursor-pointer"
                  />
                  <label htmlFor="chkRecorrenteRapido" className="text-xs font-semibold text-slate-300 cursor-pointer flex items-center gap-1.5">
                    <Repeat className="w-3.5 h-3.5 text-purple-400" />
                    <span>Repetir semanalmente toda semana (Uso Fixo)</span>
                  </label>
                </div>

                {isRecorrente && (
                  <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 space-y-2">
                    <span className="text-xs text-purple-300 font-bold block">Dias da Semana:</span>
                    <div className="grid grid-cols-5 gap-1.5 text-xs">
                      {[
                        { id: 1, label: 'Segunda' },
                        { id: 2, label: 'Terça' },
                        { id: 3, label: 'Quarta' },
                        { id: 4, label: 'Quinta' },
                        { id: 5, label: 'Sexta' }
                      ].map(dia => {
                        const isDayChecked = diasSemana.includes(dia.id);
                        return (
                          <button
                            key={dia.id}
                            type="button"
                            onClick={() => {
                              setDiasSemana(prev => 
                                prev.includes(dia.id) ? prev.filter(d => d !== dia.id) : [...prev, dia.id]
                              );
                            }}
                            className={`py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                              isDayChecked 
                                ? 'bg-purple-500 text-white shadow-sm' 
                                : 'bg-slate-900 text-slate-400 border border-slate-800'
                            }`}
                          >
                            {dia.label}
                          </button>
                        );
                      })}
                    </div>

                    <div className="pt-1">
                      <label className="block text-[11px] text-slate-400 mb-0.5">Repetir até a data:</label>
                      <input
                        type="date"
                        value={dataFimRecorrencia}
                        onChange={(e) => setDataFimRecorrencia(e.target.value)}
                        className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* BOTÃO PRINCIPAL DE CONFIRMAÇÃO */}
          {(() => {
            const temConflitoGeral = Boolean(
              (tipoSelecao === 'individual' && conflitoAtual) ||
              (tipoSelecao === 'kit' && conflitoKitAtual) ||
              (tipoSelecao === 'lote' && selectedLoteItems.some(i => i.equipamentoId && indisponibilidadeMap.has(i.equipamentoId)))
            );

            return (
              <div className="pt-3">
                <button
                  type="submit"
                  disabled={loading || temConflitoGeral}
                  className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl font-bold text-sm transition-all ${
                    temConflitoGeral
                      ? 'bg-rose-950/40 text-rose-300 border border-rose-800/60 cursor-not-allowed opacity-80'
                      : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-xl shadow-cyan-500/25 cursor-pointer disabled:opacity-50'
                  }`}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Registrando Agendamento...</span>
                    </>
                  ) : temConflitoGeral ? (
                    <>
                      <Ban className="w-5 h-5 text-rose-400" />
                      <span>Equipamento Indisponível (Já Agendado no Horário)</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5 stroke-[3]" />
                      <span>Confirmar Agendamento</span>
                    </>
                  )}
                </button>
              </div>
            );
          })()}

        </form>
      </div>
    </div>
  );
}
