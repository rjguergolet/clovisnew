import React, { useState, useMemo } from 'react';
import { 
  collection, 
  writeBatch, 
  doc, 
  serverTimestamp,
  query,
  where,
  getDocs
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { UserRole, Equipamento, Kit, Emprestimo } from '../types';
import { 
  AULAS_MANHA, 
  AULAS_TARDE, 
  ALL_AULAS, 
  formatAulasSummary, 
  determineTurnoFromAulas,
  DIAS_SEMANA_OPCOES,
  gerarDatasRecorrentes
} from '../lib/schoolSchedule';
import { isEquipamentoAptoParaEmprestimo } from '../lib/userRoles';
import { 
  validateAgendamento, 
  checkEquipamentoConflict, 
  ConflitoAgendamento 
} from '../lib/loanConflictChecker';
import { 
  Calendar, 
  Clock, 
  User, 
  School, 
  Repeat, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Trash2, 
  X, 
  Loader2, 
  Boxes, 
  Laptop, 
  Check, 
  CalendarDays, 
  Sun, 
  Sunset, 
  AlertCircle,
  Layers,
  ChevronRight,
  Info,
  Ban
} from 'lucide-react';

interface RecorrenciaModalProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: UserRole;
  equipamentos: Equipamento[];
  kits: Kit[];
  emprestimos: Emprestimo[];
}

export default function RecorrenciaModal({
  isOpen,
  onClose,
  userRole,
  equipamentos,
  kits,
  emprestimos
}: RecorrenciaModalProps) {
  const [activeTab, setActiveTab] = useState<'novo' | 'series'>('novo');
  const [salvando, setSalvando] = useState(false);
  const [excluindoSerieId, setExcluindoSerieId] = useState<string | null>(null);

  // Form State
  const todayStr = new Date().toISOString().split('T')[0];
  // Padrão de data final: 3 meses à frente
  const defaultEndDate = new Date();
  defaultEndDate.setMonth(defaultEndDate.getMonth() + 3);
  const defaultEndDateStr = defaultEndDate.toISOString().split('T')[0];

  const [tipoItem, setTipoItem] = useState<'individual' | 'kit'>('individual');
  const [selectedEquipamentoId, setSelectedEquipamentoId] = useState('');
  const [selectedKitId, setSelectedKitId] = useState('');
  const [solicitante, setSolicitante] = useState('');
  const [turmaOuSala, setTurmaOuSala] = useState('');
  const [contato, setContato] = useState('');
  const [observacoes, setObservacoes] = useState('');
  
  // Recorrência
  const [diasSemanaSelecionados, setDiasSemanaSelecionados] = useState<number[]>([1, 3]); // Padrão: Seg e Qua
  const [aulasSelecionadas, setAulasSelecionadas] = useState<string[]>(['M1', 'M2']); // Padrão: 1ª e 2ª Manhã
  const [dataInicio, setDataInicio] = useState(todayStr);
  const [dataFim, setDataFim] = useState(defaultEndDateStr);

  // Itens disponíveis (apenas ativos, operacionais e NÃO de uso permanente)
  const equipamentosDisponiveis = useMemo(() => {
    return equipamentos.filter(eq => isEquipamentoAptoParaEmprestimo(eq) && !eq.usoPermanente);
  }, [equipamentos]);

  const kitsDisponiveis = useMemo(() => {
    return kits.filter(k => {
      if (k.status === 'Inativo') return false;
      if (k.itens && k.itens.length > 0) {
        const hasInvalidItem = k.itens.some(it => {
          if (!it.equipamentoId) return false;
          const eq = equipamentos.find(e => e.id === it.equipamentoId);
          return eq && (eq.usoPermanente || !isEquipamentoAptoParaEmprestimo(eq));
        });
        if (hasInvalidItem) return false;
      }
      return true;
    });
  }, [kits, equipamentos]);

  // Seletor inicial automático
  React.useEffect(() => {
    if (tipoItem === 'individual' && !selectedEquipamentoId && equipamentosDisponiveis.length > 0) {
      setSelectedEquipamentoId(equipamentosDisponiveis[0].id || '');
    } else if (tipoItem === 'kit' && !selectedKitId && kitsDisponiveis.length > 0) {
      setSelectedKitId(kitsDisponiveis[0].id || '');
    }
  }, [tipoItem, equipamentosDisponiveis, kitsDisponiveis, selectedEquipamentoId, selectedKitId]);

  // Toggle dia da semana
  const toggleDiaSemana = (id: number) => {
    setDiasSemanaSelecionados(prev => 
      prev.includes(id) ? prev.filter(d => d !== id) : [...prev, id].sort((a, b) => a - b)
    );
  };

  // Toggle aula
  const toggleAula = (aulaId: string) => {
    setAulasSelecionadas(prev => 
      prev.includes(aulaId) ? prev.filter(a => a !== aulaId) : [...prev, aulaId]
    );
  };

  const selectAllManha = () => {
    const ids = AULAS_MANHA.map(a => a.id);
    setAulasSelecionadas(prev => {
      const allSelected = ids.every(id => prev.includes(id));
      if (allSelected) {
        return prev.filter(id => !ids.includes(id));
      } else {
        return Array.from(new Set([...prev, ...ids]));
      }
    });
  };

  const selectAllTarde = () => {
    const ids = AULAS_TARDE.map(a => a.id);
    setAulasSelecionadas(prev => {
      const allSelected = ids.every(id => prev.includes(id));
      if (allSelected) {
        return prev.filter(id => !ids.includes(id));
      } else {
        return Array.from(new Set([...prev, ...ids]));
      }
    });
  };

  // Cálculo das datas geradas
  const datasGeradas = useMemo(() => {
    return gerarDatasRecorrentes(dataInicio, dataFim, diasSemanaSelecionados);
  }, [dataInicio, dataFim, diasSemanaSelecionados]);

  // Nomes dos dias selecionados
  const diasSemanaNomes = useMemo(() => {
    return diasSemanaSelecionados.map(d => {
      const opt = DIAS_SEMANA_OPCOES.find(o => o.id === d);
      return opt ? opt.short : String(d);
    });
  }, [diasSemanaSelecionados]);

  // Detecção de possíveis conflitos para o item selecionado
  const conflitosDetectados = useMemo(() => {
    if (datasGeradas.length === 0 || aulasSelecionadas.length === 0) return [];
    const conflitos: { data: string; itemNome: string; solicitante: string; aulas: string[] }[] = [];

    if (tipoItem === 'individual') {
      if (!selectedEquipamentoId) return [];
      const eq = equipamentos.find(e => e.id === selectedEquipamentoId);
      const nome = eq?.nome || 'Equipamento';
      for (const data of datasGeradas) {
        const conf = checkEquipamentoConflict(selectedEquipamentoId, data, aulasSelecionadas, emprestimos);
        if (conf) {
          conflitos.push({
            data,
            itemNome: nome,
            solicitante: conf.solicitante,
            aulas: conf.aulasConflitantes
          });
        }
      }
    } else {
      if (!selectedKitId) return [];
      const kit = kits.find(k => k.id === selectedKitId);
      if (kit && kit.itens) {
        for (const data of datasGeradas) {
          for (const item of kit.itens) {
            if (item.equipamentoId) {
              const conf = checkEquipamentoConflict(item.equipamentoId, data, aulasSelecionadas, emprestimos);
              if (conf) {
                conflitos.push({
                  data,
                  itemNome: `${kit.nome} (${item.nome})`,
                  solicitante: conf.solicitante,
                  aulas: conf.aulasConflitantes
                });
                break;
              }
            }
          }
        }
      }
    }

    return conflitos;
  }, [datasGeradas, aulasSelecionadas, tipoItem, selectedEquipamentoId, selectedKitId, equipamentos, kits, emprestimos]);

  // Agrupamento de Séries Recorrentes Existentes
  const seriesRecorrentes = useMemo(() => {
    const map = new Map<string, {
      recorrenciaId: string;
      descricao?: string;
      solicitante: string;
      equipamentoNome: string;
      turmaOuSala?: string;
      tipoEmprestimo?: string;
      aulas?: string[];
      diasSemanaNomes?: string[];
      dataFimRecorrencia?: string;
      totalAgendamentos: number;
      pendentes: number;
      devolvidos: number;
      primeiraData: string;
      ultimaData: string;
    }>();

    emprestimos.forEach(emp => {
      if (emp.recorrente && emp.recorrenciaId) {
        const id = emp.recorrenciaId;
        const cur = map.get(id);
        const data = emp.dataAgendamento || emp.dataRetirada || '';

        if (!cur) {
          map.set(id, {
            recorrenciaId: id,
            descricao: emp.recorrenciaDescricao || '',
            solicitante: emp.solicitante,
            equipamentoNome: emp.equipamentoNome,
            turmaOuSala: emp.turmaOuSala || '',
            tipoEmprestimo: emp.tipoEmprestimo,
            aulas: emp.aulas || [],
            diasSemanaNomes: emp.diasSemanaNomes || [],
            dataFimRecorrencia: emp.dataFimRecorrencia || '',
            totalAgendamentos: 1,
            pendentes: emp.status === 'Pendente' ? 1 : 0,
            devolvidos: emp.status === 'Devolvido' ? 1 : 0,
            primeiraData: data,
            ultimaData: data
          });
        } else {
          cur.totalAgendamentos++;
          if (emp.status === 'Pendente') cur.pendentes++;
          if (emp.status === 'Devolvido') cur.devolvidos++;
          if (data && data < cur.primeiraData) cur.primeiraData = data;
          if (data && data > cur.ultimaData) cur.ultimaData = data;
        }
      }
    });

    return Array.from(map.values()).sort((a, b) => b.ultimaData.localeCompare(a.ultimaData));
  }, [emprestimos]);

  // Submeter criação da recorrência
  const handleSalvarRecorrencia = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!solicitante.trim()) {
      alert('Informe o nome do professor / solicitante.');
      return;
    }
    if (diasSemanaSelecionados.length === 0) {
      alert('Selecione pelo menos um dia da semana para a recorrência.');
      return;
    }
    if (aulasSelecionadas.length === 0) {
      alert('Selecione pelo menos uma aula no horário.');
      return;
    }
    if (datasGeradas.length === 0) {
      alert('Nenhuma data válida encontrada no intervalo selecionado.');
      return;
    }

    // Validação estrita de conflitos e disponibilidade
    const validacao = validateAgendamento({
      tipoEmprestimo: tipoItem,
      equipamentoId: selectedEquipamentoId,
      kitId: selectedKitId,
      data: dataInicio,
      aulas: aulasSelecionadas,
      isRecorrente: true,
      diasSemana: diasSemanaSelecionados,
      dataFimRecorrencia: dataFim,
      equipamentos,
      kits,
      emprestimos
    });

    if (!validacao.isValid) {
      alert(validacao.errorMessage);
      return;
    }

    let targetItemName = '';
    let targetItemId = '';
    let targetKitId: string | null = null;
    let targetKitName: string | null = null;

    if (tipoItem === 'individual') {
      const eq = equipamentos.find(i => i.id === selectedEquipamentoId);
      if (!eq) {
        alert('Selecione um equipamento disponível.');
        return;
      }
      targetItemId = eq.id || '';
      targetItemName = `${eq.nome}${eq.patrimonio ? ` (Patrimônio: ${eq.patrimonio})` : ''}`;
    } else {
      const kit = kits.find(k => k.id === selectedKitId);
      if (!kit) {
        alert('Selecione um kit de equipamentos.');
        return;
      }
      targetItemId = kit.id || 'kit-' + Date.now();
      targetItemName = `[KIT] ${kit.nome} (${kit.totalItens} itens)`;
      targetKitId = kit.id || '';
      targetKitName = kit.nome;
    }

    const recorrenciaId = `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const descricaoRecorrencia = `Uso Fixo: ${diasSemanaNomes.join('/')} • ${formatAulasSummary(aulasSelecionadas)} até ${dataFim.split('-').reverse().join('/')}`;
    const turno = determineTurnoFromAulas(aulasSelecionadas);

    setSalvando(true);
    try {
      // Gravar em batches de até 350 itens
      const batchSize = 350;
      const chunks: string[][] = [];
      for (let i = 0; i < datasGeradas.length; i += batchSize) {
        chunks.push(datasGeradas.slice(i, i + batchSize));
      }

      for (const chunk of chunks) {
        const batch = writeBatch(db);
        chunk.forEach(dataAgendada => {
          const newDocRef = doc(collection(db, 'emprestimos'));
          batch.set(newDocRef, {
            tipoEmprestimo: tipoItem,
            equipamentoId: targetItemId,
            equipamentoNome: targetItemName,
            kitId: targetKitId,
            kitNome: targetKitName,
            solicitante: solicitante.trim(),
            turmaOuSala: turmaOuSala.trim() || null,
            contato: contato.trim() || null,
            dataRetirada: dataAgendada,
            dataDevolucao: dataAgendada,
            dataAgendamento: dataAgendada,
            turno: turno,
            aulas: aulasSelecionadas,
            status: 'Pendente',
            observacoes: observacoes.trim() ? `[Recorrente] ${observacoes.trim()}` : `[Uso Fixo Recorrente - ${solicitante.trim()}]`,
            recorrente: true,
            recorrenciaId: recorrenciaId,
            diasSemana: diasSemanaSelecionados,
            diasSemanaNomes: diasSemanaNomes,
            dataFimRecorrencia: dataFim,
            recorrenciaDescricao: descricaoRecorrencia,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        });
        await batch.commit();
      }

      alert(`Sucesso! ${datasGeradas.length} agendamentos recorrentes foram gerados no calendário até ${dataFim.split('-').reverse().join('/')}.`);
      setActiveTab('series');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'emprestimos_recorrentes');
    } finally {
      setSalvando(false);
    }
  };

  // Excluir toda a série recorrente
  const handleExcluirSerieCompleta = async (recorrenciaId: string) => {
    if (!window.confirm('Tem certeza que deseja excluir TODOS os agendamentos desta série recorrente?')) {
      return;
    }

    setExcluindoSerieId(recorrenciaId);
    try {
      const qRec = query(collection(db, 'emprestimos'), where('recorrenciaId', '==', recorrenciaId));
      const snap = await getDocs(qRec);

      if (snap.empty) {
        alert('Nenhum agendamento encontrado para esta série.');
        return;
      }

      const batch = writeBatch(db);
      snap.docs.forEach(docSnap => {
        batch.delete(docSnap.ref);
      });
      await batch.commit();

      alert(`Série excluída com sucesso! ${snap.docs.length} agendamentos foram removidos.`);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `emprestimos_serie/${recorrenciaId}`);
    } finally {
      setExcluindoSerieId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[92vh] shadow-2xl flex flex-col overflow-hidden">
        
        {/* Cabeçalho */}
        <div className="px-6 py-5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/10 rounded-2xl border border-amber-500/30 text-amber-300 shadow-sm shadow-amber-500/10">
              <Repeat className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">Módulo de Agendamento Recorrente</h2>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Adm / Adm Total
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Configure reservas fixas semanais para professores por período de aulas até data a definir
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Abas Superiores */}
        <div className="px-6 pt-3 border-b border-slate-800 bg-slate-950/40 flex items-center gap-2 flex-shrink-0">
          <button
            onClick={() => setActiveTab('novo')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'novo'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Repeat className="w-4 h-4" />
            <span>Novo Agendamento Fixo</span>
          </button>

          <button
            onClick={() => setActiveTab('series')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'series'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            <span>Séries Fixas Ativas</span>
            {seriesRecorrentes.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-amber-500/30 text-amber-300 font-extrabold">
                {seriesRecorrentes.length}
              </span>
            )}
          </button>
        </div>

        {/* Conteúdo com Scroll */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'novo' ? (
            <form onSubmit={handleSalvarRecorrencia} className="space-y-6">
              {/* Aviso Explicativo */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-3">
                <Sparkles className="w-5 h-5 flex-shrink-0 text-amber-400 mt-0.5" />
                <div>
                  <strong className="font-semibold block text-amber-200 text-sm">Automação de Uso Fixo Semanal</strong>
                  <span>
                    Este módulo cria automaticamente todos os agendamentos no calendário para as aulas e dias da semana escolhidos, 
                    garantindo a reserva do equipamento/kit para o professor durante todo o semestre ou período estipulado.
                  </span>
                </div>
              </div>

              {/* 1. Escolha do Tipo de Item e Seleção */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Laptop className="w-4 h-4 text-cyan-400" />
                    1. Item a ser Reservado de Forma Fixa
                  </span>
                  
                  {/* Alternador Equipamento / Kit */}
                  <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
                    <button
                      type="button"
                      onClick={() => setTipoItem('individual')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        tipoItem === 'individual'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Equipamento Individual
                    </button>
                    <button
                      type="button"
                      onClick={() => setTipoItem('kit')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        tipoItem === 'kit'
                          ? 'bg-cyan-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Kit de Equipamentos
                    </button>
                  </div>
                </div>

                {tipoItem === 'individual' ? (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Selecione o Equipamento *
                    </label>
                    <select
                      value={selectedEquipamentoId}
                      onChange={(e) => setSelectedEquipamentoId(e.target.value)}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                    >
                      {equipamentosDisponiveis.length === 0 ? (
                        <option value="">Nenhum equipamento ativo disponível</option>
                      ) : (
                        equipamentosDisponiveis.map(eq => (
                          <option key={eq.id} value={eq.id}>
                            {eq.nome} {eq.patrimonio ? `• Patr: ${eq.patrimonio}` : ''} {eq.fabricante ? `• (${eq.fabricante})` : ''} - [{eq.categoria}]
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                ) : (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Selecione o Kit de Equipamentos *
                    </label>
                    <select
                      value={selectedKitId}
                      onChange={(e) => setSelectedKitId(e.target.value)}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                    >
                      {kitsDisponiveis.length === 0 ? (
                        <option value="">Nenhum kit cadastrado</option>
                      ) : (
                        kitsDisponiveis.map(kit => (
                          <option key={kit.id} value={kit.id}>
                            [KIT] {kit.nome} • ({kit.totalItens} itens totais)
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                )}
              </div>

              {/* 2. Dados do Professor e Turma */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <User className="w-4 h-4 text-amber-400" />
                  2. Responsável e Local de Uso
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Professor(a) / Solicitante *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Prof. Marcos Silva, Profa. Juliana"
                      value={solicitante}
                      onChange={(e) => setSolicitante(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Turma / Sala / Laboratório *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: 3º Ano B, Lab de Ciências, Sala 14"
                      value={turmaOuSala}
                      onChange={(e) => setTurmaOuSala(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Contato / Telefone (Opcional)
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: (11) 98765-4321 ou ramal"
                      value={contato}
                      onChange={(e) => setContato(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Observação Pedagógica / Motivo (Opcional)
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: Aulas fixas de Robótica e Programação"
                      value={observacoes}
                      onChange={(e) => setObservacoes(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                  </div>
                </div>
              </div>

              {/* 3. Padrão de Recorrência (Dias da Semana) */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  3. Dias da Semana de Uso Fixo
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                  {DIAS_SEMANA_OPCOES.map((dia) => {
                    const isSelected = diasSemanaSelecionados.includes(dia.id);
                    return (
                      <button
                        type="button"
                        key={dia.id}
                        onClick={() => toggleDiaSemana(dia.id)}
                        className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-500/50 text-amber-200 font-bold shadow-sm shadow-amber-500/10'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                        }`}
                      >
                        <span className="text-xs font-bold">{dia.label}</span>
                        {isSelected && (
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4. Aulas do Horário */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    4. Horário das Aulas nos Dias Selecionados
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={selectAllManha}
                      className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors"
                    >
                      Toda Manhã
                    </button>
                    <button
                      type="button"
                      onClick={selectAllTarde}
                      className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-colors"
                    >
                      Toda Tarde
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Turno da Manhã */}
                  <div className="space-y-2 p-3.5 rounded-xl bg-slate-900/90 border border-slate-800/80">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400 border-b border-slate-800 pb-2">
                      <Sun className="w-3.5 h-3.5" />
                      <span>Manhã (7 Aulas)</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {AULAS_MANHA.map(aula => {
                        const isSelected = aulasSelecionadas.includes(aula.id);
                        return (
                          <button
                            type="button"
                            key={aula.id}
                            onClick={() => toggleAula(aula.id)}
                            className={`p-2 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <div className="font-bold text-[11px]">{aula.label}</div>
                            <div className="text-[9px] opacity-75">{aula.horario}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Turno da Tarde */}
                  <div className="space-y-2 p-3.5 rounded-xl bg-slate-900/90 border border-slate-800/80">
                    <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 border-b border-slate-800 pb-2">
                      <Sunset className="w-3.5 h-3.5" />
                      <span>Tarde (7 Aulas)</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {AULAS_TARDE.map(aula => {
                        const isSelected = aulasSelecionadas.includes(aula.id);
                        return (
                          <button
                            type="button"
                            key={aula.id}
                            onClick={() => toggleAula(aula.id)}
                            className={`p-2 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200 font-bold'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <div className="font-bold text-[11px]">{aula.label}</div>
                            <div className="text-[9px] opacity-75">{aula.horario}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/60 text-xs flex items-center justify-between text-slate-300">
                  <span>Aulas Selecionadas: <strong>{formatAulasSummary(aulasSelecionadas)}</strong></span>
                  <span className="text-amber-400 font-bold">{aulasSelecionadas.length} aula(s) por dia</span>
                </div>
              </div>

              {/* 5. Período de Validade (De / Até) */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-4">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-purple-400" />
                  5. Período de Vigência da Recorrência
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Data de Início *
                    </label>
                    <input
                      type="date"
                      required
                      value={dataInicio}
                      onChange={(e) => setDataInicio(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Data Final / Limite da Recorrência *
                    </label>
                    <input
                      type="date"
                      required
                      value={dataFim}
                      min={dataInicio}
                      onChange={(e) => setDataFim(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                  </div>
                </div>

                {/* Resumo da Quantidade de Agendamentos Calculados */}
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <p className="text-xs text-slate-400">Total de agendamentos gerados automaticamente:</p>
                    <p className="text-xl font-bold text-amber-300 mt-0.5">
                      {datasGeradas.length} dias de aula ({datasGeradas.length * aulasSelecionadas.length} períodos reservados)
                    </p>
                  </div>

                  {datasGeradas.length > 0 && (
                    <div className="text-xs text-slate-400">
                      Próximas datas: <span className="text-slate-200 font-mono">{datasGeradas.slice(0, 4).map(d => d.split('-').reverse().slice(0, 2).join('/')).join(', ')}...</span>
                    </div>
                  )}
                </div>

                {/* Bloqueio de Conflito se houver */}
                {conflitosDetectados.length > 0 && (
                  <div className="p-4 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-3">
                    <Ban className="w-5 h-5 flex-shrink-0 text-rose-400 mt-0.5" />
                    <div>
                      <strong className="font-bold block text-rose-200 text-sm mb-1">Bloqueado: Conflito de Agendamento Detectado</strong>
                      <span>
                        Foram detectados {conflitosDetectados.length} conflito(s) em datas do intervalo (ex: dia <strong>{conflitosDetectados[0].data.split('-').reverse().join('/')}</strong> já agendado para <strong>{conflitosDetectados[0].solicitante}</strong>). O sistema impede o agendamento de equipamentos já ocupados. Escolha outro equipamento ou altere as aulas/dias da semana.
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Botões de Ação */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-sm font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={salvando || datasGeradas.length === 0 || conflitosDetectados.length > 0}
                  className={`px-6 py-2.5 rounded-xl text-sm font-bold shadow-lg transition-all flex items-center gap-2 ${
                    conflitosDetectados.length > 0
                      ? 'bg-rose-950/50 text-rose-300 border border-rose-800/60 cursor-not-allowed opacity-80'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20 cursor-pointer disabled:opacity-50'
                  }`}
                >
                  {salvando ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Gerando Agendamentos...</span>
                    </>
                  ) : conflitosDetectados.length > 0 ? (
                    <>
                      <Ban className="w-4 h-4 text-rose-400" />
                      <span>Bloqueado por Conflito ({conflitosDetectados.length})</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Gerar e Salvar {datasGeradas.length} Agendamentos Fixos</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            /* Tab 2: Séries Fixas Ativas */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <CalendarDays className="w-4 h-4 text-amber-400" />
                    Regras de Agendamento Recorrente Cadastradas
                  </h3>
                  <p className="text-xs text-slate-400">
                    Gerencie, acompanhe e exclua regras fixas de professores
                  </p>
                </div>
              </div>

              {seriesRecorrentes.length === 0 ? (
                <div className="p-12 text-center text-slate-400 space-y-3 bg-slate-950/40 rounded-2xl border border-slate-800">
                  <Repeat className="w-10 h-10 mx-auto text-slate-600 stroke-[1.5]" />
                  <p className="text-sm font-semibold text-slate-300">Nenhum agendamento recorrente ativo</p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Crie um agendamento fixo na aba anterior para professores com horário regular semanal.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {seriesRecorrentes.map(serie => (
                    <div 
                      key={serie.recorrenciaId}
                      className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800/90 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm hover:border-slate-700 transition-all"
                    >
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-base text-white flex items-center gap-1.5">
                            <User className="w-4 h-4 text-amber-400" />
                            {serie.solicitante}
                          </span>
                          {serie.turmaOuSala && (
                            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                              {serie.turmaOuSala}
                            </span>
                          )}
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                            🔁 Recorrência Fixo
                          </span>
                        </div>

                        <div className="text-xs text-slate-300 flex items-center gap-2">
                          <span className="font-semibold text-cyan-300">{serie.equipamentoNome}</span>
                        </div>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                          <span>Dias: <strong className="text-slate-200">{serie.diasSemanaNomes?.join(', ') || 'Semanal'}</strong></span>
                          <span>•</span>
                          <span>Aulas: <strong className="text-slate-200">{formatAulasSummary(serie.aulas)}</strong></span>
                          <span>•</span>
                          <span>Vigência: <strong className="text-slate-200">{serie.primeiraData.split('-').reverse().join('/')} até {serie.ultimaData.split('-').reverse().join('/')}</strong></span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 flex-shrink-0">
                        <div className="text-right">
                          <p className="text-xs font-bold text-slate-200">
                            {serie.pendentes} pendente(s)
                          </p>
                          <p className="text-[11px] text-slate-500">
                            {serie.totalAgendamentos} aulas no total
                          </p>
                        </div>

                        <button
                          onClick={() => handleExcluirSerieCompleta(serie.recorrenciaId)}
                          disabled={excluindoSerieId === serie.recorrenciaId}
                          title="Excluir Todos os Agendamentos Desta Série"
                          className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                        >
                          {excluindoSerieId === serie.recorrenciaId ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5" />
                          )}
                          <span>Excluir Série</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
