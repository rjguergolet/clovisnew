import React, { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  query,
  orderBy,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { UserRole, Equipamento, Kit } from '../types';
import { PERMISSIONS, isEquipamentoAtivo, isEquipamentoAptoParaEmprestimo } from '../lib/userRoles';
import KitsModal from './KitsModal';
import { 
  Wrench, 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Layers, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Laptop, 
  Printer, 
  Tv, 
  Cpu, 
  Boxes, 
  Loader2, 
  X, 
  Sparkles, 
  ArrowUpDown, 
  FileText,
  ShieldAlert,
  Info,
  Ban,
  ArrowRightLeft,
  SlidersHorizontal,
  PackageCheck,
  Building2,
  UserCheck,
  MapPin,
  ShieldCheck,
  CheckSquare,
  Square,
  CheckCheck,
  Tags
} from 'lucide-react';

const CATEGORIAS = [
  'Chromebooks',
  'Notebook',
  'Desktop',
  'Tablet',
  'Impressão 3D',
  'Ferramentas',
  'Audiovisual',
  'Eletrônicos',
  'Informática',
  'Robótica',
  'Outros'
];

const STATUS_EQUIPAMENTO_LIST = [
  { label: 'Ativo', value: 'Ativo', badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30', dotColor: 'bg-emerald-400' },
  { label: 'Manutenção', value: 'Manutenção', badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30', dotColor: 'bg-amber-400' },
  { label: 'Inativo', value: 'Inativo', badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/30', dotColor: 'bg-rose-400' },
];

const ESTADOS_CONSERVACAO = [
  { label: 'Novo', value: 'Novo', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' },
  { label: 'Bom', value: 'Bom', color: 'bg-blue-500/10 text-blue-400 border-blue-500/30' },
  { label: 'Precisa de Reparo', value: 'Precisa de Reparo', color: 'bg-amber-500/10 text-amber-400 border-amber-500/30' },
  { label: 'Inoperante', value: 'Inoperante', color: 'bg-rose-500/10 text-rose-400 border-rose-500/30' },
];

interface EquipamentosProps {
  userRole?: UserRole;
  onSolicitarEmprestimo?: (equipamento: any) => void;
}

export default function Equipamentos({ userRole = 'padrao', onSolicitarEmprestimo }: EquipamentosProps) {
  const [equipamentos, setEquipamentos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategoria, setSelectedCategoria] = useState('TODAS');
  const [selectedStatus, setSelectedStatus] = useState('TODOS');
  const [selectedEstado, setSelectedEstado] = useState('TODOS');
  const [classificarPor, setClassificarPor] = useState('nome-asc');

  // Kits State
  const [isKitsModalOpen, setIsKitsModalOpen] = useState(false);
  const [totalKitsCount, setTotalKitsCount] = useState(0);

  // Multi-seleção por caixas de seleção
  const [selectedEquipamentoIds, setSelectedEquipamentoIds] = useState<string[]>([]);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [isBatchUsoPermanenteModalOpen, setIsBatchUsoPermanenteModalOpen] = useState(false);
  const [isBatchStatusModalOpen, setIsBatchStatusModalOpen] = useState(false);
  const [batchStatusValue, setBatchStatusValue] = useState('Ativo');
  const [batchPermanenteForm, setBatchPermanenteForm] = useState({
    responsavel: '',
    local: '',
    motivo: ''
  });

  // Modal de Adicionar / Editar
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [salvando, setSalvando] = useState(false);

  // Modal de Exclusão
  const [itemToDelete, setItemToDelete] = useState<any>(null);
  const [excluindo, setExcluindo] = useState(false);

  // Modal de Detalhes
  const [detailItem, setDetailItem] = useState<any>(null);

  // Permissões
  const canManage = PERMISSIONS.canAddEquipamento(userRole);
  const canEdit = PERMISSIONS.canEditEquipamento(userRole);
  const canDelete = PERMISSIONS.canDeleteEquipamento(userRole);
  const canAssignUsoPermanente = PERMISSIONS.canAssignUsoPermanente(userRole);

  // Formulário
  const [formData, setFormData] = useState({
    nome: '',
    patrimonio: '',
    categoria: 'Informática',
    statusEquipamento: 'Ativo',
    estadoConservacao: 'Bom',
    localizacao: '',
    quantidade: 1,
    observacoes: '',
    fabricante: '',
    modelo: '',
    usoPermanente: false,
    responsavelPermanente: '',
    localPermanente: '',
    motivoUsoPermanente: ''
  });

  // Listener em tempo real do Firestore
  useEffect(() => {
    setLoading(true);
    const q = query(collection(db, 'equipamentos'), orderBy('nome', 'asc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      }));
      setEquipamentos(docs);
      setLoading(false);
    }, (error) => {
      setLoading(false);
      handleFirestoreError(error, OperationType.LIST, 'equipamentos');
    });

    // Escutar contagem de kits
    const unsubKits = onSnapshot(collection(db, 'kits'), (snapshot) => {
      setTotalKitsCount(snapshot.docs.length);
    }, () => {});

    return () => {
      unsubscribe();
      unsubKits();
    };
  }, []);

  const handleOpenAddModal = () => {
    if (!canManage) return;
    setEditingItem(null);
    setFormData({
      nome: '',
      patrimonio: '',
      categoria: 'Informática',
      statusEquipamento: 'Ativo',
      estadoConservacao: 'Bom',
      localizacao: '',
      quantidade: 1,
      observacoes: '',
      fabricante: '',
      modelo: '',
      usoPermanente: false,
      responsavelPermanente: '',
      localPermanente: '',
      motivoUsoPermanente: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (item: any) => {
    if (!canManage) return;
    setEditingItem(item);
    setFormData({
      nome: item.nome || '',
      patrimonio: item.patrimonio || item.numeroSerie || '',
      categoria: item.categoria || 'Informática',
      statusEquipamento: item.statusEquipamento || 'Ativo',
      estadoConservacao: item.estadoConservacao || 'Bom',
      localizacao: item.localizacao || '',
      quantidade: item.quantidade || 1,
      observacoes: item.observacoes || '',
      fabricante: item.fabricante || '',
      modelo: item.modelo || '',
      usoPermanente: Boolean(item.usoPermanente),
      responsavelPermanente: item.responsavelPermanente || '',
      localPermanente: item.localPermanente || '',
      motivoUsoPermanente: item.motivoUsoPermanente || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nome.trim()) return;

    setSalvando(true);
    try {
      if (editingItem) {
        // Atualizar
        const docRef = doc(db, 'equipamentos', editingItem.id);
        await updateDoc(docRef, {
          nome: formData.nome.trim(),
          patrimonio: formData.patrimonio.trim() || null,
          categoria: formData.categoria,
          statusEquipamento: formData.statusEquipamento,
          estadoConservacao: formData.estadoConservacao,
          localizacao: formData.localizacao.trim() || null,
          quantidade: Number(formData.quantidade) || 1,
          observacoes: formData.observacoes.trim() || null,
          fabricante: formData.fabricante.trim() || null,
          modelo: formData.modelo.trim() || null,
          usoPermanente: Boolean(formData.usoPermanente),
          responsavelPermanente: formData.usoPermanente ? (formData.responsavelPermanente.trim() || null) : null,
          localPermanente: formData.usoPermanente ? (formData.localPermanente.trim() || null) : null,
          motivoUsoPermanente: formData.usoPermanente ? (formData.motivoUsoPermanente.trim() || null) : null,
          updatedAt: serverTimestamp()
        });
      } else {
        // Criar
        await addDoc(collection(db, 'equipamentos'), {
          nome: formData.nome.trim(),
          patrimonio: formData.patrimonio.trim() || null,
          categoria: formData.categoria,
          statusEquipamento: formData.statusEquipamento,
          estadoConservacao: formData.estadoConservacao,
          localizacao: formData.localizacao.trim() || null,
          quantidade: Number(formData.quantidade) || 1,
          observacoes: formData.observacoes.trim() || null,
          fabricante: formData.fabricante.trim() || null,
          modelo: formData.modelo.trim() || null,
          usoPermanente: Boolean(formData.usoPermanente),
          responsavelPermanente: formData.usoPermanente ? (formData.responsavelPermanente.trim() || null) : null,
          localPermanente: formData.usoPermanente ? (formData.localPermanente.trim() || null) : null,
          motivoUsoPermanente: formData.usoPermanente ? (formData.motivoUsoPermanente.trim() || null) : null,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      }

      setIsModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      if (editingItem) {
        handleFirestoreError(error, OperationType.UPDATE, `equipamentos/${editingItem.id}`);
      } else {
        handleFirestoreError(error, OperationType.CREATE, 'equipamentos');
      }
    } finally {
      setSalvando(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete || !canManage) return;
    setExcluindo(true);
    try {
      await deleteDoc(doc(db, 'equipamentos', itemToDelete.id));
      setItemToDelete(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `equipamentos/${itemToDelete.id}`);
    } finally {
      setExcluindo(false);
    }
  };

  // Funções de Seleção de Equipamentos em Lote
  const handleToggleSelectEquipamento = (id: string) => {
    setSelectedEquipamentoIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllEquipamentos = (list: Equipamento[]) => {
    const visibleIds = list.map(item => item.id).filter(Boolean) as string[];
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => selectedEquipamentoIds.includes(id));

    if (allSelected) {
      setSelectedEquipamentoIds(prev => prev.filter(id => !visibleIds.includes(id)));
    } else {
      setSelectedEquipamentoIds(prev => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  const handleClearEquipamentoSelection = () => {
    setSelectedEquipamentoIds([]);
  };

  // Ação em Lote: Atualizar Status
  const handleBatchUpdateStatus = async (newStatus: string) => {
    if (selectedEquipamentoIds.length === 0 || !canManage) return;
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const eqId of selectedEquipamentoIds) {
        const ref = doc(db, 'equipamentos', eqId);
        batch.update(ref, {
          statusEquipamento: newStatus,
          updatedAt: serverTimestamp()
        });
      }
      await batch.commit();
      setIsBatchStatusModalOpen(false);
      setSelectedEquipamentoIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'equipamentos/batch-status');
    } finally {
      setBatchProcessing(false);
    }
  };

  // Ação em Lote: Definir Uso Permanente (Fixo para Professor ou Sala)
  const handleBatchApplyUsoPermanente = async () => {
    if (selectedEquipamentoIds.length === 0 || !canAssignUsoPermanente) return;
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const eqId of selectedEquipamentoIds) {
        const ref = doc(db, 'equipamentos', eqId);
        batch.update(ref, {
          usoPermanente: true,
          responsavelPermanente: batchPermanenteForm.responsavel.trim() || null,
          localPermanente: batchPermanenteForm.local.trim() || null,
          motivoUsoPermanente: batchPermanenteForm.motivo.trim() || null,
          updatedAt: serverTimestamp()
        });
      }
      await batch.commit();
      setIsBatchUsoPermanenteModalOpen(false);
      setBatchPermanenteForm({ responsavel: '', local: '', motivo: '' });
      setSelectedEquipamentoIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'equipamentos/batch-permanente');
    } finally {
      setBatchProcessing(false);
    }
  };

  // Ação em Lote: Remover Uso Permanente (Devolver ao Inventário Geral de Empréstimos)
  const handleBatchRemoveUsoPermanente = async () => {
    if (selectedEquipamentoIds.length === 0 || !canAssignUsoPermanente) return;
    if (!window.confirm(`Deseja remover a atribuição de Uso Permanente de ${selectedEquipamentoIds.length} equipamentos selecionados? Eles voltarão para a lista de empréstimos gerais.`)) {
      return;
    }
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const eqId of selectedEquipamentoIds) {
        const ref = doc(db, 'equipamentos', eqId);
        batch.update(ref, {
          usoPermanente: false,
          responsavelPermanente: null,
          localPermanente: null,
          motivoUsoPermanente: null,
          updatedAt: serverTimestamp()
        });
      }
      await batch.commit();
      setSelectedEquipamentoIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'equipamentos/batch-remove-permanente');
    } finally {
      setBatchProcessing(false);
    }
  };

  // Ação em Lote: Excluir Equipamentos
  const handleBatchDeleteEquipamentos = async () => {
    if (selectedEquipamentoIds.length === 0 || !canManage) return;
    if (!window.confirm(`Tem certeza que deseja excluir permanentemente ${selectedEquipamentoIds.length} equipamentos selecionados?`)) {
      return;
    }
    setBatchProcessing(true);
    try {
      const batch = writeBatch(db);
      for (const eqId of selectedEquipamentoIds) {
        const ref = doc(db, 'equipamentos', eqId);
        batch.delete(ref);
      }
      await batch.commit();
      setSelectedEquipamentoIds([]);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'equipamentos/batch-delete');
    } finally {
      setBatchProcessing(false);
    }
  };

  // Ícones por categoria
  const getCategoryIcon = (categoria: string) => {
    switch (categoria) {
      case 'Impressão 3D':
        return <Printer className="w-4 h-4 text-cyan-400" />;
      case 'Robótica':
      case 'Eletrônicos':
        return <Cpu className="w-4 h-4 text-purple-400" />;
      case 'Audiovisual':
        return <Tv className="w-4 h-4 text-amber-400" />;
      case 'Ferramentas':
        return <Wrench className="w-4 h-4 text-orange-400" />;
      case 'Chromebooks':
      case 'Notebook':
      case 'Desktop':
      case 'Tablet':
      case 'Informática':
      default:
        return <Laptop className="w-4 h-4 text-blue-400" />;
    }
  };

  // Filtragem e Ordenação / Classificação
  const filteredEquipamentos = equipamentos.filter(item => {
    const matchesSearch = 
      (item.nome || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.patrimonio || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.fabricante || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.modelo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.numeroSerie || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.localizacao || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.statusEquipamento || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.observacoes || '').toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategoria = selectedCategoria === 'TODAS' || item.categoria === selectedCategoria;
    
    let matchesStatus = true;
    if (selectedStatus !== 'TODOS') {
      const itemStatus = (item.statusEquipamento || 'Ativo').toLowerCase();
      if (selectedStatus === 'Permanente') {
        matchesStatus = Boolean(item.usoPermanente);
      } else if (selectedStatus === 'Ativo') {
        matchesStatus = !item.usoPermanente && (itemStatus === 'ativo' || itemStatus === 'disponivel' || itemStatus === 'disponível');
      } else if (selectedStatus === 'Manutenção') {
        matchesStatus = itemStatus.includes('manuten') || itemStatus.includes('análise') || itemStatus.includes('analise');
      } else if (selectedStatus === 'Inativo') {
        matchesStatus = itemStatus === 'inativo' || itemStatus.includes('inoperante');
      } else {
        matchesStatus = itemStatus === selectedStatus.toLowerCase();
      }
    }

    const matchesEstado = selectedEstado === 'TODOS' || item.estadoConservacao === selectedEstado;

    return matchesSearch && matchesCategoria && matchesStatus && matchesEstado;
  }).sort((a, b) => {
    if (classificarPor === 'nome-asc') {
      return (a.nome || '').localeCompare(b.nome || '', 'pt-BR');
    }
    if (classificarPor === 'nome-desc') {
      return (b.nome || '').localeCompare(a.nome || '', 'pt-BR');
    }
    if (classificarPor === 'fabricante-asc') {
      return (a.fabricante || 'ZZZ').localeCompare(b.fabricante || 'ZZZ', 'pt-BR');
    }
    if (classificarPor === 'patrimonio-asc') {
      return (a.patrimonio || a.numeroSerie || 'ZZZ').localeCompare(b.patrimonio || b.numeroSerie || 'ZZZ', 'pt-BR');
    }
    if (classificarPor === 'status-asc') {
      const isAtivoA = isEquipamentoAptoParaEmprestimo(a) ? 0 : 1;
      const isAtivoB = isEquipamentoAptoParaEmprestimo(b) ? 0 : 1;
      return isAtivoA - isAtivoB;
    }
    if (classificarPor === 'condicao-asc') {
      const condicaoOrder: Record<string, number> = { 'Novo': 1, 'Bom': 2, 'Precisa de Reparo': 3, 'Inoperante': 4 };
      return (condicaoOrder[a.estadoConservacao] || 5) - (condicaoOrder[b.estadoConservacao] || 5);
    }
    if (classificarPor === 'quantidade-desc') {
      return (Number(b.quantidade) || 0) - (Number(a.quantidade) || 0);
    }
    if (classificarPor === 'quantidade-asc') {
      return (Number(a.quantidade) || 0) - (Number(b.quantidade) || 0);
    }
    return 0;
  });

  // Estatísticas Rápidas
  const totalItens = equipamentos.reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);
  
  const totalAtivos = equipamentos
    .filter(i => isEquipamentoAptoParaEmprestimo(i))
    .reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);

  const totalUsoPermanente = equipamentos
    .filter(i => Boolean(i.usoPermanente))
    .reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);

  const totalEmManutencao = equipamentos
    .filter(i => {
      const st = (i.statusEquipamento || '').toLowerCase();
      return st.includes('manuten') || st.includes('análise') || st.includes('analise');
    })
    .reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);

  const totalInativos = equipamentos
    .filter(i => {
      const st = (i.statusEquipamento || '').toLowerCase();
      return st === 'inativo' || st.includes('inoperante');
    })
    .reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);

  const renderStatusEquipamentoBadge = (itemOrStatus: any) => {
    // Pode receber o item inteiro ou apenas a string status
    if (typeof itemOrStatus === 'object' && itemOrStatus !== null && itemOrStatus.usoPermanente) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm">
          <Building2 className="w-3.5 h-3.5" />
          Uso Permanente
        </span>
      );
    }

    const raw = typeof itemOrStatus === 'string' ? itemOrStatus : (itemOrStatus?.statusEquipamento || 'Ativo');
    const lower = raw.toLowerCase();

    if (lower === 'ativo' || lower === 'disponivel' || lower === 'disponível') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          Ativo
        </span>
      );
    }

    if (lower.includes('manuten') || lower.includes('análise') || lower.includes('analise')) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
          Manutenção
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30">
        <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
        Inativo
      </span>
    );
  };

  const renderEstadoBadge = (estado: string) => {
    const config = ESTADOS_CONSERVACAO.find(e => e.value === estado) || ESTADOS_CONSERVACAO[1];
    return (
      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-medium border ${config.color}`}>
        {estado}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Aviso de Modo Padrão */}
      {!canManage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 flex-shrink-0 text-emerald-400" />
            <span>
              <strong>Modo de Acesso Padrão:</strong> você pode consultar o catálogo completo (ativos, uso permanente, manutenção e inativos) e solicitar empréstimos de equipamentos <strong>Ativos</strong>.
            </span>
          </div>
        </div>
      )}

      {/* Cards de Métricas e Resumo Atualizado com Status */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total em Estoque</p>
            <p className="text-2xl font-bold text-white mt-1">{totalItens}</p>
          </div>
          <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20">
            <Boxes className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Ativos (Liberados)</p>
            <p className="text-2xl font-bold text-emerald-400 mt-1">{totalAtivos}</p>
          </div>
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Uso Permanente</p>
            <p className="text-2xl font-bold text-amber-300 mt-1">{totalUsoPermanente}</p>
          </div>
          <div className="p-2.5 bg-amber-500/10 text-amber-300 rounded-xl border border-amber-500/20">
            <Building2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Manutenção</p>
            <p className="text-2xl font-bold text-amber-400 mt-1">{totalEmManutencao}</p>
          </div>
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm col-span-2 sm:col-span-1">
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Inativos</p>
            <p className="text-2xl font-bold text-rose-400 mt-1">{totalInativos}</p>
          </div>
          <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/20">
            <XCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Barra de Ações e Filtros */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Laptop className="w-5 h-5 text-cyan-400" />
              Inventário de Equipamentos
            </h2>
            <p className="text-xs text-slate-400">
              Listagem geral com identificação de status operacional e disponibilidade para empréstimo
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            <button
              onClick={() => setIsKitsModalOpen(true)}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-cyan-500/30 font-bold text-sm shadow-md transition-all cursor-pointer"
            >
              <Boxes className="w-4 h-4" />
              <span>Kits de Equipamentos</span>
              {totalKitsCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-xs border border-cyan-500/30">
                  {totalKitsCount}
                </span>
              )}
            </button>

            {canManage && (
              <button
                onClick={handleOpenAddModal}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                Novo Equipamento
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2 border-t border-slate-800/80">
          {/* Busca por texto */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar nome, série, status..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Classificar por */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap flex items-center gap-1">
              <SlidersHorizontal className="w-3 h-3 text-cyan-400" />
              Ordenar:
            </span>
            <select
              value={classificarPor}
              onChange={(e) => setClassificarPor(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="nome-asc">Nome (A → Z)</option>
              <option value="nome-desc">Nome (Z → A)</option>
              <option value="fabricante-asc">Fabricante (A → Z)</option>
              <option value="patrimonio-asc">Patrimônio / Série</option>
              <option value="status-asc">Status (Ativos 1º)</option>
              <option value="condicao-asc">Condição (Novos 1º)</option>
              <option value="quantidade-desc">Maior Estoque</option>
              <option value="quantidade-asc">Menor Estoque</option>
            </select>
          </div>

          {/* Filtro por Status do Equipamento */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="TODOS">Todos os Status</option>
              <option value="Ativo">Apenas Ativos (Liberados p/ Empréstimo)</option>
              <option value="Permanente">🏢 Uso Permanente (Fixados em Sala/Professor)</option>
              <option value="Manutenção">Em Manutenção</option>
              <option value="Inativo">Inativos (Bloqueados)</option>
            </select>
          </div>

          {/* Filtro por Categoria */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Categoria:</span>
            <select
              value={selectedCategoria}
              onChange={(e) => setSelectedCategoria(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="TODAS">Todas as Categorias</option>
              {CATEGORIAS.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Filtro por Estado */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Condição:</span>
            <select
              value={selectedEstado}
              onChange={(e) => setSelectedEstado(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
            >
              <option value="TODOS">Todas as Condições</option>
              {ESTADOS_CONSERVACAO.map(est => (
                <option key={est.value} value={est.value}>{est.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Barra de Ações em Massa / Lote (Equipamentos Selecionados via Caixas de Seleção) */}
      {selectedEquipamentoIds.length > 0 && (
        <div className="sticky top-4 z-30 p-4 rounded-2xl bg-cyan-950/90 border border-cyan-500/40 shadow-xl backdrop-blur-md flex flex-wrap items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500 text-slate-950 font-bold">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">
                {selectedEquipamentoIds.length} {selectedEquipamentoIds.length === 1 ? 'equipamento selecionado' : 'equipamentos selecionados'}
              </p>
              <p className="text-xs text-cyan-200">
                Gerencie múltiplos equipamentos simultaneamente com as caixas de seleção
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {canAssignUsoPermanente && (
              <>
                <button
                  onClick={() => setIsBatchUsoPermanenteModalOpen(true)}
                  disabled={batchProcessing}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
                  title="Atribuir uso fixo para professor ou sala a todos os itens selecionados"
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>Fixar Uso Permanente</span>
                </button>

                <button
                  onClick={handleBatchRemoveUsoPermanente}
                  disabled={batchProcessing}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-all cursor-pointer disabled:opacity-50"
                  title="Desvincular uso fixo e disponibilizar para empréstimo geral"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span>Liberar para Empréstimo</span>
                </button>
              </>
            )}

            {canManage && (
              <button
                onClick={() => setIsBatchStatusModalOpen(true)}
                disabled={batchProcessing}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
              >
                <Tags className="w-3.5 h-3.5" />
                <span>Alterar Status</span>
              </button>
            )}

            {canDelete && (
              <button
                onClick={handleBatchDeleteEquipamentos}
                disabled={batchProcessing}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir</span>
              </button>
            )}

            <button
              onClick={handleClearEquipamentoSelection}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-all cursor-pointer"
            >
              Desmarcar
            </button>
          </div>
        </div>
      )}

      {/* Lista / Tabela de Equipamentos */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-12 flex flex-col items-center justify-center text-slate-400 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            <p className="text-sm font-medium">Carregando catálogo de equipamentos...</p>
          </div>
        ) : filteredEquipamentos.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Boxes className="w-12 h-12 mx-auto text-slate-600 stroke-[1.5]" />
            <p className="text-base font-semibold text-slate-300">Nenhum equipamento encontrado</p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {searchTerm || selectedCategoria !== 'TODAS' || selectedStatus !== 'TODOS' || selectedEstado !== 'TODOS'
                ? 'Tente ajustar os filtros ou termos da sua busca para encontrar os itens.'
                : 'O inventário está vazio no momento. Importe a planilha na aba Configurações ou cadastre um item.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="px-3 py-3.5 text-center w-10">
                    <input
                      type="checkbox"
                      title="Selecionar / Desmarcar todos os equipamentos visíveis"
                      checked={
                        filteredEquipamentos.length > 0 &&
                        filteredEquipamentos.every(item => item.id && selectedEquipamentoIds.includes(item.id))
                      }
                      onChange={() => handleSelectAllEquipamentos(filteredEquipamentos)}
                      className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-cyan-400 focus:ring-offset-slate-900 cursor-pointer"
                    />
                  </th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5">Equipamento / Modelo</th>
                  <th className="px-4 py-3.5">Patrimônio / Série</th>
                  <th className="px-4 py-3.5">Categoria</th>
                  <th className="px-4 py-3.5">Condição</th>
                  <th className="px-4 py-3.5">Qtd / Local</th>
                  <th className="px-5 py-3.5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-sm">
                {filteredEquipamentos.map((item) => {
                  const isApto = isEquipamentoAptoParaEmprestimo(item);
                  const isAtivo = isEquipamentoAtivo(item.statusEquipamento);
                  const isChecked = item.id ? selectedEquipamentoIds.includes(item.id) : false;

                  return (
                    <tr 
                      key={item.id} 
                      className={`hover:bg-slate-800/30 transition-colors ${
                        isChecked 
                          ? 'bg-cyan-950/30'
                          : item.usoPermanente 
                          ? 'bg-amber-950/10' 
                          : !isAtivo 
                            ? 'bg-slate-950/30 opacity-90' 
                            : ''
                      }`}
                    >
                      {/* Checkbox de Seleção */}
                      <td className="px-3 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => item.id && handleToggleSelectEquipamento(item.id)}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-cyan-400 focus:ring-offset-slate-900 cursor-pointer"
                        />
                      </td>

                      {/* Coluna de Status do Equipamento */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        {renderStatusEquipamentoBadge(item)}
                      </td>

                      {/* Coluna de Nome / Modelo */}
                      <td className="px-4 py-4">
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-xl border mt-0.5 ${
                            item.usoPermanente 
                              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' 
                              : 'bg-slate-800 border-slate-700/60'
                          }`}>
                            {getCategoryIcon(item.categoria)}
                          </div>
                          <div>
                            <span 
                              onClick={() => setDetailItem(item)}
                              className="font-bold text-white hover:text-cyan-400 cursor-pointer transition-colors block"
                            >
                              {item.nome}
                            </span>
                            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 flex-wrap">
                              {item.fabricante && <span>{item.fabricante}</span>}
                              {item.fabricante && item.modelo && <span>•</span>}
                              {item.modelo && <span className="text-slate-300">{item.modelo}</span>}
                            </div>
                            {item.usoPermanente && (
                              <div className="flex items-center gap-2 mt-1.5 text-[11px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20 w-fit">
                                <span className="font-semibold">Fixo:</span>
                                {item.localPermanente && <span>📍 {item.localPermanente}</span>}
                                {item.responsavelPermanente && <span>👤 {item.responsavelPermanente}</span>}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Patrimônio / Número de Série */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        {item.patrimonio || item.numeroSerie ? (
                          <span className="font-mono text-xs text-cyan-300 bg-cyan-950/40 px-2 py-1 rounded border border-cyan-800/40">
                            {item.patrimonio || item.numeroSerie}
                          </span>
                        ) : (
                          <span className="text-xs text-slate-600">Sem patrimônio</span>
                        )}
                      </td>

                      {/* Categoria */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 text-xs text-slate-300 font-medium bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/50">
                          {item.categoria || 'Outros'}
                        </span>
                      </td>

                      {/* Avaliação Técnica / Condição */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        {renderEstadoBadge(item.estadoConservacao)}
                      </td>

                      {/* Quantidade e Local */}
                      <td className="px-4 py-4 text-xs whitespace-nowrap">
                        <div className="text-slate-200 font-semibold">{item.quantidade || 1} un.</div>
                        {(item.localPermanente || item.localizacao) && (
                          <div className="text-slate-400 mt-0.5">{item.localPermanente || item.localizacao}</div>
                        )}
                      </td>

                      {/* Ações: Emprestar (se Ativo) ou Indicativo de Bloqueio/Uso Fixo */}
                      <td className="px-5 py-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {onSolicitarEmprestimo && (
                            item.usoPermanente ? (
                              <span 
                                title={`Uso Permanente: alocado fixo para ${item.responsavelPermanente || item.localPermanente || 'sala/setor'}`}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium bg-amber-500/15 text-amber-300 border border-amber-500/30"
                              >
                                <Building2 className="w-3 h-3" />
                                <span>Uso Fixo</span>
                              </span>
                            ) : isApto ? (
                              <button
                                onClick={() => onSolicitarEmprestimo(item)}
                                title="Registrar Empréstimo deste Item"
                                className="p-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500 text-cyan-400 hover:text-slate-950 transition-colors cursor-pointer text-xs font-semibold px-2.5 flex items-center gap-1 border border-cyan-500/30"
                              >
                                <ArrowRightLeft className="w-3.5 h-3.5" />
                                <span>Emprestar</span>
                              </button>
                            ) : (
                              <span 
                                title={`Não disponível para empréstimo (Status: ${item.statusEquipamento || 'Não Ativo'})`}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium bg-slate-800/70 text-slate-500 border border-slate-800 cursor-not-allowed"
                              >
                                <Ban className="w-3 h-3 text-slate-500" />
                                <span>Indisponível</span>
                              </span>
                            )
                          )}
                          
                          {canEdit && (
                            <button
                              onClick={() => handleOpenEditModal(item)}
                              title="Editar Equipamento"
                              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              onClick={() => setItemToDelete(item)}
                              title="Excluir Equipamento"
                              className="p-2 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal: Atribuição de Uso Permanente em Lote */}
      {isBatchUsoPermanenteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-amber-400" />
                <h4 className="font-bold text-white text-base">
                  Fixar Uso Permanente em Lote
                </h4>
              </div>
              <button
                onClick={() => setIsBatchUsoPermanenteModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Você está definindo o uso permanente para <strong className="text-amber-300 font-bold">{selectedEquipamentoIds.length} equipamentos</strong>. Eles sairão da lista de empréstimos gerais e ficarão vinculados à sala ou responsável indicado.
            </p>

            <div className="space-y-3 text-left">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Professor / Responsável Permanente
                </label>
                <input
                  type="text"
                  placeholder="Ex: Prof. Carlos Silva"
                  value={batchPermanenteForm.responsavel}
                  onChange={(e) => setBatchPermanenteForm(prev => ({ ...prev, responsavel: e.target.value }))}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Local / Sala Fixa *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Laboratório Maker, Sala dos Professores"
                  value={batchPermanenteForm.local}
                  onChange={(e) => setBatchPermanenteForm(prev => ({ ...prev, local: e.target.value }))}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Motivo / Observação
                </label>
                <input
                  type="text"
                  placeholder="Ex: Alocado para o ano letivo completo"
                  value={batchPermanenteForm.motivo}
                  onChange={(e) => setBatchPermanenteForm(prev => ({ ...prev, motivo: e.target.value }))}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsBatchUsoPermanenteModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleBatchApplyUsoPermanente}
                disabled={batchProcessing || (!batchPermanenteForm.local && !batchPermanenteForm.responsavel)}
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-lg shadow-amber-500/20 transition-all disabled:opacity-50 cursor-pointer"
              >
                {batchProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Building2 className="w-3.5 h-3.5" />}
                <span>Aplicar a {selectedEquipamentoIds.length} Itens</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Atualização de Status em Lote */}
      {isBatchStatusModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Tags className="w-5 h-5 text-cyan-400" />
                <h4 className="font-bold text-white text-base">
                  Alterar Status em Lote
                </h4>
              </div>
              <button
                onClick={() => setIsBatchStatusModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Escolha o novo status para aplicar a <strong className="text-cyan-300">{selectedEquipamentoIds.length} itens selecionados</strong>:
            </p>

            <select
              value={batchStatusValue}
              onChange={(e) => setBatchStatusValue(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
            >
              {STATUS_EQUIPAMENTO_LIST.map(st => (
                <option key={st.value} value={st.value}>
                  {st.label}
                </option>
              ))}
            </select>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsBatchStatusModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => handleBatchUpdateStatus(batchStatusValue)}
                disabled={batchProcessing}
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50 cursor-pointer"
              >
                {batchProcessing && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Confirmar Status</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Detalhes do Equipamento */}
      {detailItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-cyan-400" />
                Detalhes do Equipamento
              </h3>
              <button
                onClick={() => setDetailItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-sm text-slate-200">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Nome</p>
                <p className="text-lg font-bold text-white mt-0.5">{detailItem.nome}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Status Operacional</p>
                  <div className="mt-1">{renderStatusEquipamentoBadge(detailItem)}</div>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Disponibilidade</p>
                  <p className="mt-1 text-xs">
                    {detailItem.usoPermanente ? (
                      <span className="text-amber-400 font-bold flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5" /> Fixo / Uso Permanente
                      </span>
                    ) : isEquipamentoAptoParaEmprestimo(detailItem) ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" /> Liberado para Empréstimo
                      </span>
                    ) : (
                      <span className="text-rose-400 font-bold flex items-center gap-1">
                        <Ban className="w-3.5 h-3.5" /> Bloqueado para Empréstimo
                      </span>
                    )}
                  </p>
                </div>
              </div>

              {detailItem.usoPermanente && (
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider">
                    <Building2 className="w-4 h-4 text-amber-400" />
                    Informações de Uso Permanente
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block">Responsável / Docente:</span>
                      <span className="text-amber-200 font-medium">{detailItem.responsavelPermanente || 'Não especificado'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Sala / Local Fixo:</span>
                      <span className="text-amber-200 font-medium">{detailItem.localPermanente || detailItem.localizacao || 'Não especificado'}</span>
                    </div>
                  </div>
                  {detailItem.motivoUsoPermanente && (
                    <div className="text-xs pt-1 border-t border-amber-500/20">
                      <span className="text-slate-400 block">Finalidade / Motivo:</span>
                      <span className="text-slate-200">{detailItem.motivoUsoPermanente}</span>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Fabricante / Marca</p>
                  <p className="text-slate-300 mt-0.5">{detailItem.fabricante || 'Não informado'}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Modelo</p>
                  <p className="text-slate-300 mt-0.5">{detailItem.modelo || 'Não informado'}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Patrimônio / Série</p>
                  <p className="font-mono text-cyan-300 mt-0.5">{detailItem.patrimonio || detailItem.numeroSerie || 'Sem registro'}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Categoria</p>
                  <p className="text-slate-300 mt-0.5">{detailItem.categoria || 'Outros'}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Estado de Conservação</p>
                  <div className="mt-1">{renderEstadoBadge(detailItem.estadoConservacao)}</div>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Quantidade Total</p>
                  <p className="text-white font-bold mt-0.5">{detailItem.quantidade || 1} unidade(s)</p>
                </div>
              </div>

              {detailItem.localizacao && !detailItem.usoPermanente && (
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Localização Físico</p>
                  <p className="text-slate-300 mt-0.5">{detailItem.localizacao}</p>
                </div>
              )}

              {detailItem.observacoes && (
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Observações Técnicas / Descrição</p>
                  <p className="text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs mt-1 whitespace-pre-wrap">
                    {detailItem.observacoes}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                {onSolicitarEmprestimo && isEquipamentoAptoParaEmprestimo(detailItem) && (
                  <button
                    onClick={() => {
                      onSolicitarEmprestimo(detailItem);
                      setDetailItem(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
                  >
                    Solicitar Empréstimo
                  </button>
                )}
                <button
                  onClick={() => setDetailItem(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Criação / Edição */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden my-6">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                {editingItem ? <Edit2 className="w-5 h-5 text-cyan-400" /> : <Plus className="w-5 h-5 text-cyan-400" />}
                {editingItem ? 'Editar Equipamento' : 'Novo Equipamento'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Nome do Equipamento / Item *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Chromebook Samsung 4, Notebook Positivo N1110"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Fabricante / Marca
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: SAMSUNG, POSITIVO, LENOVO"
                    value={formData.fabricante}
                    onChange={(e) => setFormData({ ...formData, fabricante: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Modelo
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Chromebook Samsung 4, ThinkCentre M75s"
                    value={formData.modelo}
                    onChange={(e) => setFormData({ ...formData, modelo: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Nº de Série / Patrimônio
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: 0ANS9QCY304458F"
                    value={formData.patrimonio}
                    onChange={(e) => setFormData({ ...formData, patrimonio: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Categoria *
                  </label>
                  <select
                    value={formData.categoria}
                    onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  >
                    {CATEGORIAS.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Status do Equipamento *
                  </label>
                  <select
                    value={formData.statusEquipamento}
                    onChange={(e) => setFormData({ ...formData, statusEquipamento: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  >
                    {STATUS_EQUIPAMENTO_LIST.map(st => (
                      <option key={st.value} value={st.value}>
                        {st.label} {st.value === 'Ativo' ? '(Liberado para empréstimo)' : '(Bloqueado para empréstimo)'}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Condição / Conservação *
                  </label>
                  <select
                    value={formData.estadoConservacao}
                    onChange={(e) => setFormData({ ...formData, estadoConservacao: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  >
                    {ESTADOS_CONSERVACAO.map(est => (
                      <option key={est.value} value={est.value}>{est.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Quantidade
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.quantidade}
                    onChange={(e) => setFormData({ ...formData, quantidade: Number(e.target.value) || 1 })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Localização no Estoque (Opcional)
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Armário 01, TI, Prateleira B"
                    value={formData.localizacao}
                    onChange={(e) => setFormData({ ...formData, localizacao: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>
              </div>

              {/* Seção de Uso Permanente por Sala ou Professor (Apenas ADM / ADM Total) */}
              {canAssignUsoPermanente && (
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-amber-400" />
                      <label htmlFor="usoPermanenteToggle" className="text-xs font-bold text-amber-300 uppercase tracking-wider cursor-pointer">
                        Definir como Uso Permanente / Fixo
                      </label>
                    </div>
                    <input
                      type="checkbox"
                      id="usoPermanenteToggle"
                      checked={formData.usoPermanente}
                      onChange={(e) => setFormData({ ...formData, usoPermanente: e.target.checked })}
                      className="w-4 h-4 text-amber-500 bg-slate-950 border-slate-700 rounded focus:ring-amber-400 cursor-pointer"
                    />
                  </div>

                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Itens em <strong>Uso Permanente</strong> ficam vinculados a uma sala fixa ou a um professor e são <strong>retirados da lista comum de empréstimos</strong>.
                  </p>

                  {formData.usoPermanente && (
                    <div className="space-y-3 pt-2 border-t border-amber-500/20 animate-in fade-in duration-200">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                            Professor / Responsável *
                          </label>
                          <input
                            type="text"
                            required={formData.usoPermanente}
                            placeholder="Ex: Prof. Carlos Silva"
                            value={formData.responsavelPermanente}
                            onChange={(e) => setFormData({ ...formData, responsavelPermanente: e.target.value })}
                            className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                            Sala / Setor Fixo *
                          </label>
                          <input
                            type="text"
                            required={formData.usoPermanente}
                            placeholder="Ex: Laboratório Maker, Sala 04"
                            value={formData.localPermanente}
                            onChange={(e) => setFormData({ ...formData, localPermanente: e.target.value })}
                            className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                          Motivo / Finalidade do Uso Fixo
                        </label>
                        <input
                          type="text"
                          placeholder="Ex: Uso diário com turmas do 3º ano / Projetos de Robótica"
                          value={formData.motivoUsoPermanente}
                          onChange={(e) => setFormData({ ...formData, motivoUsoPermanente: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Observações Técnicas / Descrição
                </label>
                <textarea
                  rows={3}
                  placeholder="Ex: Check ok, sem teclado, falta fonte ou detalhes de uso."
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400 resize-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-sm font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={salvando}
                  className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-sm font-bold shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {salvando && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>{editingItem ? 'Salvar Alterações' : 'Cadastrar Item'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Exclusão */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-xl border border-rose-500/20">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-white">Excluir Equipamento?</h3>
                <p className="text-xs text-slate-400">Esta ação removerá permanentemente o item do catálogo.</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-300">
              <span className="font-semibold text-white">{itemToDelete.nome}</span>
              {itemToDelete.patrimonio && (
                <span className="block text-xs text-slate-400 font-mono mt-0.5">Patrimônio: {itemToDelete.patrimonio}</span>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-sm font-medium transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={excluindo}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-sm font-bold shadow-lg shadow-rose-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {excluindo && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Excluir Item</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Kits de Equipamentos */}
      <KitsModal
        isOpen={isKitsModalOpen}
        onClose={() => setIsKitsModalOpen(false)}
        userRole={userRole}
        equipamentos={equipamentos}
        onEmprestarKit={(kit) => {
          if (onSolicitarEmprestimo) {
            onSolicitarEmprestimo({
              tipoEmprestimo: 'kit',
              kitId: kit.id,
              nome: kit.nome,
              equipamentoNome: kit.nome,
              kit: kit
            });
          }
        }}
      />
    </div>
  );
}

