import React, { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  query,
  orderBy
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { UserRole, Kit, KitItem, Equipamento } from '../types';
import { PERMISSIONS, isEquipamentoAptoParaEmprestimo } from '../lib/userRoles';
import MultiEquipamentoSelector from './MultiEquipamentoSelector';
import { 
  Boxes, 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  X, 
  Loader2, 
  PackageCheck, 
  Sparkles, 
  Layers, 
  ArrowRightLeft, 
  AlertCircle,
  PlusCircle,
  MinusCircle,
  CheckCircle2,
  CheckSquare
} from 'lucide-react';

interface KitsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userRole?: UserRole;
  equipamentos: Equipamento[];
  onEmprestarKit: (kit: Kit) => void;
}

export default function KitsModal({
  isOpen,
  onClose,
  userRole = 'padrao',
  equipamentos,
  onEmprestarKit
}: KitsModalProps) {
  const [kits, setKits] = useState<Kit[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal de Criação / Edição de Kit
  const [isEditingKit, setIsEditingKit] = useState(false);
  const [editingKitId, setEditingKitId] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);

  // Form State do Kit
  const [nome, setNome] = useState('');
  const [descricao, setDescricao] = useState('');
  const [categoria, setCategoria] = useState('Informática');
  const [status, setStatus] = useState<'Ativo' | 'Inativo'>('Ativo');
  const [selectedItems, setSelectedItems] = useState<KitItem[]>([]);

  // Item sendo adicionado ao kit no form
  const [tempEquipamentoId, setTempEquipamentoId] = useState('');
  const [tempQuantidade, setTempQuantidade] = useState<number>(1);

  // Delete modal
  const [kitToDelete, setKitToDelete] = useState<Kit | null>(null);
  const [excluindo, setExcluindo] = useState(false);

  const canManageKits = PERMISSIONS.canAddEquipamento(userRole);
  const canDeleteKits = PERMISSIONS.canDeleteEquipamento(userRole);

  // Escutar coleção de Kits no Firestore
  useEffect(() => {
    if (!isOpen) return;

    setLoading(true);
    const qKits = query(collection(db, 'kits'), orderBy('nome', 'asc'));
    const unsub = onSnapshot(qKits, (snapshot) => {
      const docs = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as Kit[];
      setKits(docs);
      setLoading(false);
    }, (err) => {
      setLoading(false);
      handleFirestoreError(err, OperationType.LIST, 'kits');
    });

    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const handleOpenAddKit = () => {
    setEditingKitId(null);
    setNome('');
    setDescricao('');
    setCategoria('Informática');
    setStatus('Ativo');
    setSelectedItems([]);
    setTempEquipamentoId(equipamentos.length > 0 ? equipamentos[0].id || '' : '');
    setTempQuantidade(1);
    setIsEditingKit(true);
  };

  const handleOpenEditKit = (kit: Kit) => {
    setEditingKitId(kit.id || null);
    setNome(kit.nome || '');
    setDescricao(kit.descricao || '');
    setCategoria(kit.categoria || 'Informática');
    setStatus(kit.status || 'Ativo');
    setSelectedItems(kit.itens ? [...kit.itens] : []);
    setTempEquipamentoId(equipamentos.length > 0 ? equipamentos[0].id || '' : '');
    setTempQuantidade(1);
    setIsEditingKit(true);
  };

  const handleAddItemToKit = () => {
    if (!tempEquipamentoId) return;
    const eq = equipamentos.find(e => e.id === tempEquipamentoId);
    if (!eq) return;

    // Verificar se já existe na lista do kit
    const existingIndex = selectedItems.findIndex(i => i.equipamentoId === eq.id);
    if (existingIndex >= 0) {
      const updated = [...selectedItems];
      updated[existingIndex].quantidade += tempQuantidade;
      setSelectedItems(updated);
    } else {
      setSelectedItems(prev => [
        ...prev,
        {
          equipamentoId: eq.id,
          nome: eq.nome,
          patrimonio: eq.patrimonio || null,
          categoria: eq.categoria,
          quantidade: tempQuantidade
        }
      ]);
    }
  };

  const handleRemoveItemFromKit = (index: number) => {
    setSelectedItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleSaveKit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome.trim()) {
      alert('Informe o nome do Kit.');
      return;
    }

    if (selectedItems.length === 0) {
      alert('Adicione pelo menos 1 equipamento ao Kit.');
      return;
    }

    const totalItens = selectedItems.reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);

    setSalvando(true);
    try {
      const kitPayload = {
        nome: nome.trim(),
        descricao: descricao.trim() || null,
        categoria: categoria || 'Informática',
        status: status || 'Ativo',
        itens: selectedItems,
        totalItens: totalItens,
        updatedAt: serverTimestamp()
      };

      if (editingKitId) {
        await updateDoc(doc(db, 'kits', editingKitId), kitPayload);
      } else {
        await addDoc(collection(db, 'kits'), {
          ...kitPayload,
          createdAt: serverTimestamp()
        });
      }

      setIsEditingKit(false);
    } catch (err) {
      handleFirestoreError(err, editingKitId ? OperationType.UPDATE : OperationType.CREATE, 'kits');
    } finally {
      setSalvando(false);
    }
  };

  const handleDeleteKit = async () => {
    if (!kitToDelete?.id) return;
    setExcluindo(true);
    try {
      await deleteDoc(doc(db, 'kits', kitToDelete.id));
      setKitToDelete(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'kits');
    } finally {
      setExcluindo(false);
    }
  };

  // Filtragem dos kits
  const filteredKits = kits.filter(k => 
    k.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (k.descricao && k.descricao.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (k.categoria && k.categoria.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                Kits de Equipamentos
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-semibold">
                  {kits.length} {kits.length === 1 ? 'kit cadastrado' : 'kits cadastrados'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Agrupe múltiplos equipamentos (ex: carrinhos de chromebooks, kits de robótica) para agendamento em lote
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1 overflow-y-auto space-y-6">
          
          {/* Barra de Ações & Busca */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar kits por nome ou itens..."
                className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
            </div>

            {canManageKits && (
              <button
                onClick={handleOpenAddKit}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Criar Novo Kit
              </button>
            )}
          </div>

          {/* Form de Criação/Edição inline se estiver ativo */}
          {isEditingKit && (
            <div className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/30 shadow-xl space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-bold text-cyan-400 flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  {editingKitId ? 'Editar Kit de Equipamentos' : 'Montar Novo Kit de Equipamentos'}
                </h3>
                <button 
                  type="button" 
                  onClick={() => setIsEditingKit(false)}
                  className="text-slate-400 hover:text-white text-xs"
                >
                  Cancelar
                </button>
              </div>

              <form onSubmit={handleSaveKit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                      Nome do Kit *
                    </label>
                    <input
                      required
                      type="text"
                      value={nome}
                      onChange={(e) => setNome(e.target.value)}
                      placeholder="Ex: Carrinho 1 (30 Chromebooks Samsung)"
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                      Categoria do Kit
                    </label>
                    <select
                      value={categoria}
                      onChange={(e) => setCategoria(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                    >
                      <option value="Informática">Informática</option>
                      <option value="Chromebooks">Chromebooks</option>
                      <option value="Notebook">Notebooks</option>
                      <option value="Robótica">Robótica & Maker</option>
                      <option value="Audiovisual">Audiovisual</option>
                      <option value="Ciências / Lab">Ciências / Lab</option>
                      <option value="Outros">Outros</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Descrição / Instruções de Uso
                  </label>
                  <textarea
                    rows={2}
                    value={descricao}
                    onChange={(e) => setDescricao(e.target.value)}
                    placeholder="Ex: Contém 30 notebooks Samsung, fonte de carregamento centralizada e chave do carrinho."
                    className="w-full px-3.5 py-2 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                </div>

                {/* Seção de Adicionar Itens ao Kit com Caixas de Seleção */}
                <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                      <CheckSquare className="w-4 h-4 text-cyan-400" />
                      Composição do Kit (Selecione pelas Caixas de Seleção) *
                    </label>
                    <span className="text-xs text-cyan-400 font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/20">
                      Total: {selectedItems.reduce((acc, curr) => acc + (Number(curr.quantidade) || 0), 0)} itens
                    </span>
                  </div>

                  <MultiEquipamentoSelector
                    equipamentos={equipamentos}
                    selectedItems={selectedItems}
                    onChange={(updatedItems) => setSelectedItems(updatedItems)}
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingKit(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={salvando}
                    className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50 cursor-pointer"
                  >
                    {salvando && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    {editingKitId ? 'Salvar Alterações do Kit' : 'Cadastrar Kit'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Listagem de Kits Cadastrados */}
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center text-slate-400 gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
              <p className="text-xs">Carregando kits...</p>
            </div>
          ) : filteredKits.length === 0 ? (
            <div className="py-12 text-center rounded-2xl bg-slate-950 border border-slate-800/80 p-8 space-y-3">
              <Boxes className="w-12 h-12 text-slate-600 mx-auto" />
              <h4 className="text-sm font-bold text-slate-300">Nenhum Kit Encontrado</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {searchTerm 
                  ? 'Nenhum kit corresponde aos termos da pesquisa.' 
                  : 'Crie kits com conjuntos de múltiplos equipamentos (ex: Carrinho de 30 Chromebooks, Kit Robótica) para agilizar o agendamento coletivo.'}
              </p>
              {canManageKits && !isEditingKit && (
                <button
                  onClick={handleOpenAddKit}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-xl shadow-lg transition-all cursor-pointer mt-2"
                >
                  <Plus className="w-4 h-4" />
                  Criar Primeiro Kit
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredKits.map((kit) => (
                <div 
                  key={kit.id}
                  className="p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between group shadow-md"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                          <Layers className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                            {kit.nome}
                          </h4>
                          <span className="text-[11px] font-medium text-slate-400">
                            {kit.categoria || 'Geral'}
                          </span>
                        </div>
                      </div>

                      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                        {kit.totalItens} {kit.totalItens === 1 ? 'item' : 'itens'}
                      </span>
                    </div>

                    {kit.descricao && (
                      <p className="text-xs text-slate-400 line-clamp-2">
                        {kit.descricao}
                      </p>
                    )}

                    {/* Itens do Kit resumidos */}
                    <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1.5">
                      <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Itens no Kit:
                      </p>
                      <ul className="text-xs space-y-1 max-h-28 overflow-y-auto pr-1">
                        {kit.itens?.map((it, idx) => (
                          <li key={idx} className="flex items-center justify-between text-slate-300">
                            <span className="truncate max-w-[220px]">
                              • {it.nome}
                            </span>
                            <span className="font-bold text-cyan-400 ml-2">
                              {it.quantidade}x
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Ações do Kit */}
                  <div className="flex items-center justify-between gap-2 pt-4 mt-2 border-t border-slate-800/80">
                    <button
                      type="button"
                      onClick={() => {
                        onEmprestarKit(kit);
                        onClose();
                      }}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
                    >
                      <ArrowRightLeft className="w-3.5 h-3.5" />
                      Agendar / Emprestar Kit
                    </button>

                    {canManageKits && (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditKit(kit)}
                          title="Editar Kit"
                          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {canDeleteKits && (
                          <button
                            type="button"
                            onClick={() => setKitToDelete(kit)}
                            title="Excluir Kit"
                            className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal de Confirmação de Exclusão */}
        {kitToDelete && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
              <div className="flex items-center gap-3 text-rose-400">
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Excluir Kit</h3>
                  <p className="text-xs text-slate-400">Esta ação não pode ser desfeita.</p>
                </div>
              </div>

              <p className="text-xs text-slate-300">
                Tem certeza de que deseja excluir o kit <span className="font-bold text-white">"{kitToDelete.nome}"</span>? Os equipamentos individuais permanecerão no inventário.
              </p>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setKitToDelete(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleDeleteKit}
                  disabled={excluindo}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold shadow-lg shadow-rose-500/20 transition-all disabled:opacity-50"
                >
                  {excluindo && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Confirmar Exclusão
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
