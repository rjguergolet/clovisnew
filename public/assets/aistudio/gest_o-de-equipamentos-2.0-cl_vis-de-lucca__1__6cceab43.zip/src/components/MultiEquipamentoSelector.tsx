import React, { useState, useMemo } from 'react';
import { Equipamento, KitItem } from '../types';
import { isEquipamentoAptoParaEmprestimo } from '../lib/userRoles';
import { ConflitoAgendamento } from '../lib/loanConflictChecker';
import { 
  Search, 
  Check, 
  Plus, 
  Minus, 
  Trash2, 
  Package, 
  Laptop, 
  Tv, 
  Volume2, 
  Cable, 
  Bot, 
  Camera, 
  Boxes,
  CheckSquare,
  Square,
  AlertCircle,
  Building2,
  X,
  Ban
} from 'lucide-react';

interface MultiEquipamentoSelectorProps {
  equipamentos: Equipamento[];
  selectedItems: KitItem[];
  onChange: (items: KitItem[]) => void;
  title?: string;
  subtitle?: string;
  onlyAptos?: boolean;
  maxSelection?: number;
  showAptosToggle?: boolean;
  indisponibilidadeMap?: Map<string, ConflitoAgendamento>;
}

export default function MultiEquipamentoSelector({
  equipamentos,
  selectedItems,
  onChange,
  title = 'Selecione os Equipamentos',
  subtitle = 'Marque as caixas de seleção dos itens que deseja incluir',
  onlyAptos = true,
  maxSelection,
  showAptosToggle = true,
  indisponibilidadeMap
}: MultiEquipamentoSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('TODAS');
  const [filterOnlyAptos, setFilterOnlyAptos] = useState<boolean>(onlyAptos);

  // Categorias únicas presentes nos equipamentos
  const categories = useMemo(() => {
    const set = new Set<string>();
    equipamentos.forEach(e => {
      if (e.categoria) set.add(e.categoria);
    });
    return Array.from(set).sort();
  }, [equipamentos]);

  // Ícone por categoria
  const getCategoryIcon = (cat?: string) => {
    const c = (cat || '').toLowerCase();
    if (c.includes('computador') || c.includes('notebook') || c.includes('tablet') || c.includes('info')) {
      return <Laptop className="w-4 h-4 text-cyan-400" />;
    }
    if (c.includes('projetor') || c.includes('monitor') || c.includes('tv') || c.includes('tela')) {
      return <Tv className="w-4 h-4 text-purple-400" />;
    }
    if (c.includes('som') || c.includes('áudio') || c.includes('audio') || c.includes('microfone') || c.includes('caixa')) {
      return <Volume2 className="w-4 h-4 text-amber-400" />;
    }
    if (c.includes('cabo') || c.includes('adaptador') || c.includes('carregador')) {
      return <Cable className="w-4 h-4 text-emerald-400" />;
    }
    if (c.includes('robótica') || c.includes('robotica') || c.includes('maker') || c.includes('lego')) {
      return <Bot className="w-4 h-4 text-rose-400" />;
    }
    if (c.includes('câmera') || c.includes('camera') || c.includes('foto')) {
      return <Camera className="w-4 h-4 text-blue-400" />;
    }
    return <Package className="w-4 h-4 text-slate-400" />;
  };

  // Filtragem dos equipamentos
  const filteredList = useMemo(() => {
    return equipamentos.filter(eq => {
      if (filterOnlyAptos && (!isEquipamentoAptoParaEmprestimo(eq) || eq.usoPermanente)) {
        return false;
      }
      if (selectedCategory !== 'TODAS' && eq.categoria !== selectedCategory) {
        return false;
      }
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const nome = (eq.nome || '').toLowerCase();
        const patr = (eq.patrimonio || '').toLowerCase();
        const fab = (eq.fabricante || '').toLowerCase();
        const mod = (eq.modelo || '').toLowerCase();
        const cat = (eq.categoria || '').toLowerCase();
        const loc = (eq.localizacao || '').toLowerCase();
        return nome.includes(term) || patr.includes(term) || fab.includes(term) || mod.includes(term) || cat.includes(term) || loc.includes(term);
      }
      return true;
    });
  }, [equipamentos, filterOnlyAptos, selectedCategory, searchTerm]);

  // Mapa de IDs selecionados para busca rápida
  const selectedMap = useMemo(() => {
    const map = new Map<string, KitItem>();
    selectedItems.forEach(item => {
      if (item.equipamentoId) {
        map.set(item.equipamentoId, item);
      }
    });
    return map;
  }, [selectedItems]);

  const totalQuantity = useMemo(() => {
    return selectedItems.reduce((acc, curr) => acc + (Number(curr.quantidade) || 1), 0);
  }, [selectedItems]);

  // Alternar seleção de um item individual
  const handleToggleItem = (eq: Equipamento) => {
    if (!eq.id) return;
    
    // Bloqueio de Conflito de Agendamento
    const conflito = indisponibilidadeMap?.get(eq.id);
    if (conflito) {
      alert(`Não é possível selecionar o equipamento "${eq.nome}":\nEle já está agendado para ${conflito.solicitante} na(s) aula(s) ${conflito.aulasConflitantes.join(', ')}.`);
      return;
    }

    // Bloqueio de Uso Permanente ou Inativo
    if (eq.usoPermanente) {
      alert(`O equipamento "${eq.nome}" está em USO FIXO / PERMANENTE e não pode ser selecionado para empréstimo.`);
      return;
    }
    if (!isEquipamentoAptoParaEmprestimo(eq)) {
      alert(`O equipamento "${eq.nome}" está com status "${eq.statusEquipamento || 'Inativo'}" (${eq.estadoConservacao || 'Inoperante'}) e não pode ser selecionado.`);
      return;
    }

    const isSelected = selectedMap.has(eq.id);

    if (isSelected) {
      // Remover
      const updated = selectedItems.filter(item => item.equipamentoId !== eq.id);
      onChange(updated);
    } else {
      // Adicionar
      if (maxSelection && selectedItems.length >= maxSelection) {
        alert(`Você pode selecionar no máximo ${maxSelection} itens.`);
        return;
      }
      const newItem: KitItem = {
        equipamentoId: eq.id,
        nome: eq.nome,
        patrimonio: eq.patrimonio || null,
        categoria: eq.categoria || 'Geral',
        quantidade: 1
      };
      onChange([...selectedItems, newItem]);
    }
  };

  // Alterar quantidade de um item selecionado
  const handleQuantityChange = (equipamentoId: string, delta: number, maxAvailable: number = 99) => {
    const updated = selectedItems.map(item => {
      if (item.equipamentoId === equipamentoId) {
        const currentQty = Number(item.quantidade) || 1;
        const newQty = Math.max(1, Math.min(maxAvailable, currentQty + delta));
        return { ...item, quantidade: newQty };
      }
      return item;
    });
    onChange(updated);
  };

  // Selecionar todos os filtrados (pulando itens conflitantes ou inaptos)
  const handleSelectAllFiltered = () => {
    const newItems = [...selectedItems];
    let skippedCount = 0;
    filteredList.forEach(eq => {
      if (!eq.id) return;
      if (indisponibilidadeMap?.has(eq.id) || eq.usoPermanente || !isEquipamentoAptoParaEmprestimo(eq)) {
        skippedCount++;
        return;
      }
      if (!selectedMap.has(eq.id)) {
        newItems.push({
          equipamentoId: eq.id,
          nome: eq.nome,
          patrimonio: eq.patrimonio || null,
          categoria: eq.categoria || 'Geral',
          quantidade: 1
        });
      }
    });
    onChange(newItems);
    if (skippedCount > 0) {
      // Informar discretamente se algum foi pulado por indisponibilidade
    }
  };

  // Desmarcar todos
  const handleDeselectAll = () => {
    onChange([]);
  };

  const areAllFilteredSelected = filteredList.length > 0 && filteredList.every(eq => eq.id && selectedMap.has(eq.id));

  return (
    <div className="space-y-3 bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4">
      {/* Header do Seletor */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              {title}
            </h4>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
              {selectedItems.length} selecionado{selectedItems.length !== 1 ? 's' : ''} ({totalQuantity} un.)
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {subtitle}
          </p>
        </div>

        {/* Botões Rápidos */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {filteredList.length > 0 && (
            <button
              type="button"
              onClick={areAllFilteredSelected ? handleDeselectAll : handleSelectAllFiltered}
              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors flex items-center gap-1"
            >
              {areAllFilteredSelected ? <Square className="w-3.5 h-3.5 text-slate-400" /> : <CheckSquare className="w-3.5 h-3.5 text-cyan-400" />}
              <span>{areAllFilteredSelected ? 'Desmarcar Todos' : 'Marcar Todos'}</span>
            </button>
          )}

          {selectedItems.length > 0 && (
            <button
              type="button"
              onClick={handleDeselectAll}
              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-colors flex items-center gap-1"
              title="Limpar seleção"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar</span>
            </button>
          )}
        </div>
      </div>

      {/* Chips dos Itens Selecionados Atualmente (Bandeja Rápida) */}
      {selectedItems.length > 0 && (
        <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-[11px] font-semibold text-cyan-300">
            <span>Itens Escolhidos para o Empréstimo / Kit:</span>
            <span>Total: {selectedItems.length} tipos de itens ({totalQuantity} unidades)</span>
          </div>

          <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
            {selectedItems.map(item => (
              <span
                key={item.equipamentoId || item.nome}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-slate-900 border border-cyan-500/30 text-slate-200 shadow-sm"
              >
                <span className="font-bold text-cyan-400">{item.quantidade || 1}x</span>
                <span className="truncate max-w-[140px] sm:max-w-[200px]" title={item.nome}>{item.nome}</span>
                {item.patrimonio && (
                  <span className="text-[10px] text-slate-400 bg-slate-800 px-1 py-0.2 rounded font-mono">
                    #{item.patrimonio}
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => {
                    if (item.equipamentoId) {
                      const updated = selectedItems.filter(i => i.equipamentoId !== item.equipamentoId);
                      onChange(updated);
                    }
                  }}
                  className="text-slate-400 hover:text-rose-400 transition-colors p-0.5 rounded"
                  title="Remover este item"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Barra de Pesquisa e Filtro de Categoria */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por nome, patrimônio, marca, modelo ou local..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-8 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Categorias Rápidas em Pílulas */}
        {categories.length > 1 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            <button
              type="button"
              onClick={() => setSelectedCategory('TODAS')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all ${
                selectedCategory === 'TODAS'
                  ? 'bg-cyan-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              Todas ({equipamentos.length})
            </button>
            {categories.map(cat => {
              const count = equipamentos.filter(e => e.categoria === cat).length;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all ${
                    selectedCategory === cat
                      ? 'bg-cyan-500 text-slate-950 shadow-sm'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat} ({count})
                </button>
              );
            })}
          </div>
        )}

        {/* Caixinha de Filtro: Apenas Equipamentos Disponíveis */}
        {showAptosToggle && (
          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none group">
              <input
                type="checkbox"
                checked={filterOnlyAptos}
                onChange={(e) => setFilterOnlyAptos(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-400/50 cursor-pointer accent-cyan-500"
              />
              <span className="text-xs font-semibold text-slate-300 group-hover:text-white transition-colors">
                Exibir apenas equipamentos disponíveis para aula
              </span>
            </label>
            <span className="text-[11px] text-slate-400">
              {filteredList.length} itens encontrados
            </span>
          </div>
        )}
      </div>

      {/* Lista Interativa com Caixas de Seleção */}
      <div className="max-h-72 overflow-y-auto space-y-1.5 pr-1 border border-slate-800/80 rounded-xl bg-slate-900/40 p-2 divide-y divide-slate-800/40">
        {filteredList.length === 0 ? (
          <div className="p-6 text-center text-slate-500 space-y-2">
            <Boxes className="w-8 h-8 mx-auto text-slate-600" />
            <p className="text-xs font-semibold text-slate-400">Nenhum equipamento encontrado no catálogo</p>
            <p className="text-[11px]">Tente limpar a pesquisa ou selecionar outra categoria.</p>
          </div>
        ) : (
          filteredList.map((eq) => {
            const isSelected = eq.id ? selectedMap.has(eq.id) : false;
            const currentSelected = eq.id ? selectedMap.get(eq.id) : undefined;
            const maxEstoque = Number(eq.quantidade) || 1;
            const isApto = isEquipamentoAptoParaEmprestimo(eq);
            const conflito = eq.id ? indisponibilidadeMap?.get(eq.id) : undefined;
            const isConflitado = Boolean(conflito);
            const isUsoFixo = Boolean(eq.usoPermanente);
            const isBloqueado = isConflitado || isUsoFixo || !isApto;

            return (
              <div
                key={eq.id}
                className={`pt-2 first:pt-0 flex items-center justify-between gap-3 p-2 rounded-xl transition-all ${
                  isBloqueado
                    ? 'bg-slate-950/60 opacity-60 border border-slate-800/40'
                    : isSelected
                    ? 'bg-cyan-500/10 border border-cyan-500/40 shadow-sm'
                    : 'hover:bg-slate-800/50 border border-transparent'
                }`}
              >
                {/* Lado Esquerdo: Checkbox + Ícone + Nome e Detalhes */}
                <div 
                  className={`flex items-center gap-3 min-w-0 flex-1 select-none ${
                    isBloqueado ? 'cursor-not-allowed' : 'cursor-pointer'
                  }`}
                  onClick={() => handleToggleItem(eq)}
                >
                  <div className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all flex-shrink-0 ${
                    isBloqueado
                      ? 'border-slate-800 bg-slate-900 text-slate-600'
                      : isSelected
                      ? 'bg-cyan-500 border-cyan-400 text-slate-950 font-bold'
                      : 'border-slate-700 bg-slate-950 hover:border-slate-500'
                  }`}>
                    {isBloqueado ? (
                      <Ban className="w-3 h-3 text-rose-500" />
                    ) : (
                      isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />
                    )}
                  </div>

                  <div className={`p-1.5 rounded-lg border flex-shrink-0 ${
                    isBloqueado
                      ? 'bg-slate-900 border-slate-800 text-slate-600'
                      : isSelected
                      ? 'bg-cyan-500/20 border-cyan-500/30'
                      : 'bg-slate-800/80 border-slate-700/60'
                  }`}>
                    {getCategoryIcon(eq.categoria)}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-xs font-semibold truncate ${
                        isBloqueado 
                          ? 'text-slate-400 line-through' 
                          : isSelected 
                          ? 'text-cyan-300 font-bold' 
                          : 'text-slate-200'
                      }`}>
                        {eq.nome}
                      </span>
                      {eq.patrimonio && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-cyan-400 border border-slate-700">
                          #{eq.patrimonio}
                        </span>
                      )}

                      {/* Badges de Bloqueio ou Conflito */}
                      {isConflitado && (
                        <span 
                          title={conflito?.motivo}
                          className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950/80 text-rose-300 border border-rose-800/80 flex items-center gap-1"
                        >
                          <Ban className="w-2.5 h-2.5" />
                          <span>Já agendado ({conflito?.solicitante} - {conflito?.aulasConflitantes.join(', ')})</span>
                        </span>
                      )}

                      {isUsoFixo && (
                        <span 
                          title={`Uso Permanente: ${eq.localPermanente || eq.responsavelPermanente || 'Alocado fixo'}`}
                          className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80 flex items-center gap-1"
                        >
                          <Building2 className="w-2.5 h-2.5" />
                          <span>Uso Fixo / Permanente</span>
                        </span>
                      )}

                      {!isApto && !isUsoFixo && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                          {eq.statusEquipamento || eq.estadoConservacao || 'Indisponível'}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 flex-wrap">
                      {eq.categoria && <span>{eq.categoria}</span>}
                      {eq.fabricante && <span>• {eq.fabricante}</span>}
                      {eq.modelo && <span>{eq.modelo}</span>}
                      {eq.localizacao && <span>• 📍 {eq.localizacao}</span>}
                    </div>
                  </div>
                </div>

                {/* Lado Direito: Ajuste de Quantidade (quando selecionado) ou Estoque Disponível */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  {isBloqueado ? (
                    <span className="text-[10px] font-bold text-rose-400/90 bg-rose-950/30 px-2 py-0.5 rounded border border-rose-900/40">
                      Bloqueado
                    </span>
                  ) : isSelected && eq.id ? (
                    <div className="flex items-center gap-1 bg-slate-950 border border-cyan-500/40 rounded-lg p-0.5 shadow-sm">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleQuantityChange(eq.id!, -1, maxEstoque);
                        }}
                        disabled={(currentSelected?.quantidade || 1) <= 1}
                        className="p-1 text-slate-400 hover:text-white disabled:opacity-30 rounded hover:bg-slate-800 transition-colors"
                        title="Diminuir quantidade"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-cyan-300 px-1.5 min-w-[20px] text-center">
                        {currentSelected?.quantidade || 1}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleQuantityChange(eq.id!, 1, maxEstoque);
                        }}
                        disabled={(currentSelected?.quantidade || 1) >= maxEstoque}
                        className="p-1 text-slate-400 hover:text-white disabled:opacity-30 rounded hover:bg-slate-800 transition-colors"
                        title="Aumentar quantidade"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <span className="text-[11px] font-medium text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700/60">
                      Disp: {maxEstoque} un.
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
