import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { doc, onSnapshot, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import Login from './components/Login';
import Equipamentos from './components/Equipamentos';
import Emprestimos from './components/Emprestimos';
import Configuracoes from './components/Configuracoes';
import { UserRole, UsuarioDoc } from './types';
import { 
  resolveUserRole, 
  SUPER_ADMIN_EMAIL, 
  isSuperAdminEmail, 
  USER_ROLES,
  PERMISSIONS
} from './lib/userRoles';
import { 
  Package, 
  ArrowRightLeft, 
  LogOut, 
  Loader2, 
  Boxes, 
  Settings, 
  ShieldCheck, 
  Crown, 
  User as UserIcon, 
  Sparkles,
  Eye,
  EyeOff,
  GraduationCap
} from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [userDoc, setUserDoc] = useState<UsuarioDoc | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'equipamentos' | 'emprestimos' | 'configuracoes'>('emprestimos');
  const [presetEquipamentoForLoan, setPresetEquipamentoForLoan] = useState<any>(null);

  // Modo de Simulação de Perfis Escolares (Exclusivo para Diretor, Vice-Diretor e Adm Total)
  const [simulatedRole, setSimulatedRole] = useState<UserRole | null>(null);

  // Monitorar estado de autenticação em tempo real
  useEffect(() => {
    let unsubDoc: (() => void) | null = null;

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);

      if (currentUser) {
        // Buscar/monitorar documento de perfil do usuário no Firestore
        const userRef = doc(db, 'usuarios', currentUser.uid);
        
        // Se for o super admin, garantir que o doc exista com perfil adm_total
        if (isSuperAdminEmail(currentUser.email)) {
          try {
            const snap = await getDoc(userRef);
            const userName = currentUser.email?.toLowerCase().includes('rodrigo') 
              ? 'Rodrigo Guergolet' 
              : (currentUser.displayName || currentUser.email?.split('@')[0] || 'Administrador Master');

            if (!snap.exists()) {
              await setDoc(userRef, {
                uid: currentUser.uid,
                usuario: 'rodrigo.guergolet',
                email: currentUser.email?.toLowerCase() || '',
                nome: userName,
                perfil: 'adm_total',
                status: 'ativo',
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
              });
            } else if (snap.data()?.perfil !== 'adm_total') {
              await setDoc(userRef, { 
                perfil: 'adm_total', 
                usuario: snap.data()?.usuario || 'rodrigo.guergolet',
                updatedAt: serverTimestamp() 
              }, { merge: true });
            }
          } catch (e) {
            console.warn('Verificação de perfil master:', e);
          }
        }

        unsubDoc = onSnapshot(userRef, (docSnap) => {
          if (docSnap.exists()) {
            setUserDoc(docSnap.data() as UsuarioDoc);
          } else {
            setUserDoc(null);
          }
        }, (err) => {
          console.warn('Erro ao escutar dados do usuário:', err);
        });
      } else {
        setUserDoc(null);
        setSimulatedRole(null);
      }

      setAuthLoading(false);
    });

    return () => {
      unsubscribe();
      if (unsubDoc) unsubDoc();
    };
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Erro ao realizar logout:', error);
    }
  };

  const handleSolicitarEmprestimo = (equipamento: any) => {
    setPresetEquipamentoForLoan(equipamento);
    setActiveTab('emprestimos');
  };

  const realRole: UserRole = resolveUserRole(user, userDoc);
  const canSimulate = PERMISSIONS.canSimulateRoles(realRole, user?.email);
  
  // Se houver simulação ativa e o usuário tiver permissão para simular, o papel vigente é o simulado
  const currentRole: UserRole = (canSimulate && simulatedRole) ? simulatedRole : realRole;
  const roleConfig = USER_ROLES[currentRole] || USER_ROLES.padrao;
  const realRoleConfig = USER_ROLES[realRole] || USER_ROLES.padrao;

  // Carregamento inicial do Firebase Auth
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-200">
        <div className="flex flex-col items-center gap-4">
          <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
          <p className="text-sm font-semibold tracking-wide text-slate-400">
            Carregando sistema de gestão escolar...
          </p>
        </div>
      </div>
    );
  }

  // Se não estiver autenticado, exibe exclusivamente o Login
  if (!user) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* BARRA SUPERIOR DE SIMULAÇÃO DE PERFIL (EXIBIDA QUANDO SIMULAÇÃO ESTÁ ATIVA) */}
      {simulatedRole && canSimulate && (
        <div className="bg-gradient-to-r from-amber-600/30 via-purple-600/30 to-cyan-600/30 border-b border-amber-500/40 px-4 py-2 text-xs backdrop-blur-md sticky top-0 z-50 shadow-lg">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5">
            <div className="flex items-center gap-2 text-amber-200">
              <Eye className="w-4 h-4 text-amber-400 animate-pulse shrink-0" />
              <span>
                <strong className="text-amber-300">Modo de Simulação:</strong> Visualizando telas e permissões como{' '}
                <span className={`inline-block px-2 py-0.5 rounded font-bold border text-[11px] ${roleConfig.badgeColor}`}>
                  {roleConfig.label}
                </span>
              </span>
              <span className="text-slate-400 text-[11px] hidden lg:inline">
                (Seu cargo real é {realRoleConfig.label})
              </span>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <span className="text-[11px] text-slate-300 hidden md:inline">Trocar perfil:</span>
              <select
                value={simulatedRole}
                onChange={(e) => setSimulatedRole(e.target.value as UserRole)}
                className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-400 cursor-pointer font-semibold"
              >
                <option value="PROFESSOR">Professor</option>
                <option value="CGPG">CGPG</option>
                <option value="SECRETARIA">Secretaria</option>
                <option value="PROFESSOR_PAAC">Professor PAAC</option>
                <option value="VICE_DIRETOR">Vice-Diretor</option>
                <option value="DIRETOR">Diretor</option>
              </select>

              <button
                onClick={() => setSimulatedRole(null)}
                className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>Encerrar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cabeçalho Principal do Sistema */}
      <header className={`sticky ${simulatedRole && canSimulate ? 'top-[41px]' : 'top-0'} z-40 bg-slate-900/80 border-b border-slate-800/80 backdrop-blur-xl transition-all`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            
            {/* Logo e Nome da Aplicação */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20 ring-2 ring-slate-800">
                <Package className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                  Gestão Escolar
                  <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                    Aulas & Recursos
                  </span>
                </h1>
                <p className="text-xs text-slate-400 hidden sm:block">Controle de agendamentos e inventário</p>
              </div>
            </div>

            {/* Navegação entre as Abas Principais */}
            <nav className="flex items-center p-1 bg-slate-950 rounded-xl border border-slate-800/80 shadow-inner">
              <button
                onClick={() => setActiveTab('emprestimos')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === 'emprestimos'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span>Agendamentos</span>
              </button>

              <button
                onClick={() => setActiveTab('equipamentos')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === 'equipamentos'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Boxes className="w-4 h-4" />
                <span>Equipamentos</span>
              </button>

              <button
                onClick={() => setActiveTab('configuracoes')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === 'configuracoes'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Configurações</span>
              </button>
            </nav>

            {/* Perfil, Badge de Nível e Botão de Logout */}
            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="text-xs flex items-center gap-2">
                  <span className="font-medium text-slate-300 truncate max-w-[160px]">
                    {userDoc?.nome || user.email}
                  </span>
                  
                  {/* Badge de Nível de Usuário */}
                  <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border ${roleConfig.badgeColor}`}>
                    {currentRole === 'DIRETOR' && <Crown className="w-3 h-3 text-purple-300" />}
                    {currentRole === 'VICE_DIRETOR' && <Crown className="w-3 h-3 text-blue-300" />}
                    {currentRole === 'PROFESSOR' && <GraduationCap className="w-3 h-3 text-emerald-300" />}
                    {currentRole === 'CGPG' && <ShieldCheck className="w-3 h-3 text-indigo-300" />}
                    {currentRole === 'SECRETARIA' && <ShieldCheck className="w-3 h-3 text-cyan-300" />}
                    {currentRole === 'PROFESSOR_PAAC' && <Sparkles className="w-3 h-3 text-rose-300" />}
                    <span>{roleConfig.label}</span>
                  </span>
                </div>
              </div>

              <button
                onClick={handleLogout}
                title="Encerrar sessão"
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 border border-slate-700/60 hover:border-rose-500/30 text-xs font-semibold transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sair</span>
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Conteúdo Principal Dinâmico */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'equipamentos' && (
          <Equipamentos 
            userRole={currentRole}
            onSolicitarEmprestimo={handleSolicitarEmprestimo} 
          />
        )}
        {activeTab === 'emprestimos' && (
          <Emprestimos 
            userRole={currentRole}
            currentUserName={userDoc?.nome || user.email?.split('@')[0] || ''}
            initialEquipamento={presetEquipamentoForLoan}
            onClearInitialEquipamento={() => setPresetEquipamentoForLoan(null)}
          />
        )}
        {activeTab === 'configuracoes' && (
          <Configuracoes 
            userRole={currentRole}
            currentUserEmail={user.email}
            simulatedRole={simulatedRole}
            onStartSimulation={(role) => setSimulatedRole(role)}
            onStopSimulation={() => setSimulatedRole(null)}
          />
        )}
      </main>

      {/* Rodapé Limpo */}
      <footer className="border-t border-slate-900 py-4 text-center text-xs text-slate-500 bg-slate-950">
        <p>Sistema Escolar de Agendamentos e Equipamentos • Perfis: Professor, CGPG, Secretaria, Professor PAAC, Vice-Diretor e Diretor</p>
      </footer>
    </div>
  );
}
