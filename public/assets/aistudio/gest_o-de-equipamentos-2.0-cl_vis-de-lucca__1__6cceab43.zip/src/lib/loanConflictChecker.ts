import { Equipamento, Kit, KitItem, Emprestimo } from '../types';
import { isEquipamentoAptoParaEmprestimo } from './userRoles';
import { gerarDatasRecorrentes, formatAulasSummary } from './schoolSchedule';

export interface ConflitoAgendamento {
  equipamentoId: string;
  equipamentoNome: string;
  solicitante: string;
  turmaOuSala?: string;
  data: string;
  aulas: string[];
  aulasConflitantes: string[];
  motivo: string;
  emprestimoId?: string;
}

/**
 * Verifica se dois conjuntos de aulas têm sobreposição.
 * Se qualquer um deles for vazio (representando o dia todo / sem aula específica),
 * considera-se sobreposição total com qualquer aula daquele turno/dia.
 */
export function areAulasOverlapping(aulas1?: string[] | null, aulas2?: string[] | null): boolean {
  if (!aulas1 || aulas1.length === 0) return true;
  if (!aulas2 || aulas2.length === 0) return true;
  return aulas1.some(a => aulas2.includes(a));
}

/**
 * Retorna quais aulas específicas estão em conflito entre dois conjuntos.
 */
export function getOverlappingAulas(aulas1?: string[] | null, aulas2?: string[] | null): string[] {
  if (!aulas1 || aulas1.length === 0) return aulas2 || ['Todas'];
  if (!aulas2 || aulas2.length === 0) return aulas1;
  return aulas1.filter(a => aulas2.includes(a));
}

/**
 * Verifica se um empréstimo está ativo na data indicada.
 */
export function isLoanActiveOnDate(emp: Emprestimo, targetDate: string): boolean {
  if (emp.status === 'Devolvido') return false;

  const dataAg = emp.dataAgendamento || emp.dataRetirada;
  if (dataAg === targetDate) return true;

  if (emp.dataRetirada && emp.dataDevolucao) {
    if (emp.dataRetirada <= targetDate && emp.dataDevolucao >= targetDate) {
      return true;
    }
  }

  // Se o item foi retirado fisicamente (retirado === true) e ainda não foi devolvido,
  // ele está em uso contínuo (ou em atraso) e não pode ser agendado para hoje.
  const todayStr = new Date().toISOString().split('T')[0];
  if (targetDate === todayStr && emp.retirado && emp.status === 'Pendente') {
    return true;
  }

  return false;
}

/**
 * Extrai todos os IDs de equipamentos individuais contidos num empréstimo.
 */
export function getEquipamentoIdsFromEmprestimo(emp: Emprestimo, kitsList: Kit[] = []): string[] {
  const ids = new Set<string>();

  // 1. Equipamento direto (individual)
  if (emp.equipamentoId && !emp.equipamentoId.startsWith('kit-') && emp.tipoEmprestimo !== 'kit') {
    ids.add(emp.equipamentoId);
  }

  // 2. Itens individuais em kitItem
  if (emp.itensEmprestados && Array.isArray(emp.itensEmprestados)) {
    emp.itensEmprestados.forEach(item => {
      if (item.equipamentoId) ids.add(item.equipamentoId);
    });
  }

  // 3. Lote / seleção múltipla
  if (emp.selectedEquipamentos && Array.isArray(emp.selectedEquipamentos)) {
    emp.selectedEquipamentos.forEach(item => {
      if (item.equipamentoId) ids.add(item.equipamentoId);
    });
  }

  // 4. Se for empréstimo de Kit, busca os equipamentos que compõem o kit
  if (emp.kitId && kitsList.length > 0) {
    const kit = kitsList.find(k => k.id === emp.kitId);
    if (kit && kit.itens) {
      kit.itens.forEach(item => {
        if (item.equipamentoId) ids.add(item.equipamentoId);
      });
    }
  }

  return Array.from(ids);
}

/**
 * Cria um mapa de indisponibilidade de equipamentos para uma data e horário (aulas) específicos.
 * Chave: ID do equipamento -> Dados do conflito.
 */
export function getEquipamentoIndisponibilidadeMap(
  targetDate: string,
  targetAulas: string[],
  emprestimosPendentes: Emprestimo[],
  kitsList: Kit[] = [],
  ignoreEmprestimoId?: string
): Map<string, ConflitoAgendamento> {
  const map = new Map<string, ConflitoAgendamento>();

  emprestimosPendentes.forEach(emp => {
    if (emp.status === 'Devolvido') return;
    if (ignoreEmprestimoId && emp.id === ignoreEmprestimoId) return;
    if (!isLoanActiveOnDate(emp, targetDate)) return;
    if (!areAulasOverlapping(emp.aulas, targetAulas)) return;

    const overlap = getOverlappingAulas(emp.aulas, targetAulas);
    const eqIds = getEquipamentoIdsFromEmprestimo(emp, kitsList);

    eqIds.forEach(eqId => {
      if (!map.has(eqId)) {
        map.set(eqId, {
          equipamentoId: eqId,
          equipamentoNome: emp.equipamentoNome || 'Equipamento',
          solicitante: emp.solicitante,
          turmaOuSala: emp.turmaOuSala || undefined,
          data: targetDate,
          aulas: emp.aulas || [],
          aulasConflitantes: overlap,
          motivo: `Já agendado para ${emp.solicitante}${emp.turmaOuSala ? ` (${emp.turmaOuSala})` : ''} nas aulas: ${overlap.join(', ')}`,
          emprestimoId: emp.id
        });
      }
    });
  });

  return map;
}

/**
 * Verifica se um equipamento específico está disponível para a data e aulas desejadas.
 */
export function checkEquipamentoConflict(
  equipamentoId: string,
  targetDate: string,
  targetAulas: string[],
  emprestimosPendentes: Emprestimo[],
  kitsList: Kit[] = [],
  ignoreEmprestimoId?: string
): ConflitoAgendamento | null {
  for (const emp of emprestimosPendentes) {
    if (ignoreEmprestimoId && emp.id === ignoreEmprestimoId) continue;
    if (emp.status === 'Devolvido') continue;
    if (!isLoanActiveOnDate(emp, targetDate)) continue;
    if (!areAulasOverlapping(emp.aulas, targetAulas)) continue;

    const eqIds = getEquipamentoIdsFromEmprestimo(emp, kitsList);
    if (eqIds.includes(equipamentoId)) {
      const overlap = getOverlappingAulas(emp.aulas, targetAulas);
      return {
        equipamentoId,
        equipamentoNome: emp.equipamentoNome,
        solicitante: emp.solicitante,
        turmaOuSala: emp.turmaOuSala || undefined,
        data: targetDate,
        aulas: emp.aulas || [],
        aulasConflitantes: overlap,
        motivo: `Já agendado para ${emp.solicitante}${emp.turmaOuSala ? ` (${emp.turmaOuSala})` : ''} nas aulas: ${overlap.join(', ')}`,
        emprestimoId: emp.id
      };
    }
  }
  return null;
}

/**
 * Validador completo e abrangente para criação/edição de agendamentos.
 * Garante:
 * 1. Não permite equipamentos inativos, inoperantes ou em uso permanente/fixo.
 * 2. Não permite agendar equipamentos que já estão agendados no mesmo dia e horário.
 * 3. Suporta agendamentos individuais, kits, lotes e séries recorrentes.
 */
export function validateAgendamento(params: {
  tipoEmprestimo: 'individual' | 'kit' | 'lote' | string;
  equipamentoId?: string;
  kitId?: string | null;
  itens?: KitItem[] | null;
  data: string;
  aulas: string[];
  isRecorrente?: boolean;
  diasSemana?: number[];
  dataFimRecorrencia?: string;
  equipamentos: Equipamento[];
  kits: Kit[];
  emprestimos: Emprestimo[];
  ignoreEmprestimoId?: string;
}): { isValid: boolean; errorMessage?: string; conflitos?: ConflitoAgendamento[] } {
  const {
    tipoEmprestimo,
    equipamentoId,
    kitId,
    itens,
    data,
    aulas,
    isRecorrente,
    diasSemana,
    dataFimRecorrencia,
    equipamentos,
    kits,
    emprestimos,
    ignoreEmprestimoId
  } = params;

  // 1. Coleta e validação dos equipamentos envolvidos quanto a status e uso fixo
  const eqIdsToCheck: string[] = [];

  if (tipoEmprestimo === 'kit') {
    const kitObj = kits.find(k => k.id === kitId);
    if (!kitObj) {
      return { isValid: false, errorMessage: 'Kit selecionado não encontrado.' };
    }
    if (kitObj.status === 'Inativo') {
      return { isValid: false, errorMessage: `O kit "${kitObj.nome}" está desativado no sistema e não pode ser agendado.` };
    }
    (kitObj.itens || []).forEach(item => {
      if (item.equipamentoId) eqIdsToCheck.push(item.equipamentoId);
    });
  } else if (tipoEmprestimo === 'lote') {
    if (!itens || itens.length === 0) {
      return { isValid: false, errorMessage: 'Nenhum equipamento selecionado no lote.' };
    }
    itens.forEach(item => {
      if (item.equipamentoId) eqIdsToCheck.push(item.equipamentoId);
    });
  } else {
    // Individual
    if (!equipamentoId) {
      return { isValid: false, errorMessage: 'Selecione um equipamento.' };
    }
    eqIdsToCheck.push(equipamentoId);
  }

  // Validação 1: Equipamentos Inativos ou em Uso Fixo/Permanente
  for (const eqId of eqIdsToCheck) {
    const eq = equipamentos.find(e => e.id === eqId);
    if (eq) {
      if (eq.usoPermanente) {
        return {
          isValid: false,
          errorMessage: `O equipamento "${eq.nome}" está alocado em USO FIXO / PERMANENTE (${eq.localPermanente || eq.responsavelPermanente || 'setor fixo'}) e não pode ser agendado para empréstimo.`
        };
      }
      if (!isEquipamentoAptoParaEmprestimo(eq)) {
        return {
          isValid: false,
          errorMessage: `O equipamento "${eq.nome}" está com status "${eq.statusEquipamento || 'Inativo'}" (${eq.estadoConservacao || 'Inoperante'}) e não está disponível para empréstimo.`
        };
      }
    }
  }

  // 2. Determinação de todas as datas a verificar (única ou série recorrente)
  let datasToCheck = [data];
  if (isRecorrente && diasSemana && diasSemana.length > 0 && dataFimRecorrencia) {
    datasToCheck = gerarDatasRecorrentes(data, dataFimRecorrencia, diasSemana);
    if (datasToCheck.length === 0) {
      return { isValid: false, errorMessage: 'Nenhuma data válida encontrada no intervalo de recorrência.' };
    }
  }

  // Validação 2: Conflitos de Agendamento Existente
  const conflitosEncontrados: ConflitoAgendamento[] = [];

  for (const dataItem of datasToCheck) {
    for (const eqId of eqIdsToCheck) {
      const conflito = checkEquipamentoConflict(
        eqId,
        dataItem,
        aulas,
        emprestimos,
        kits,
        ignoreEmprestimoId
      );

      if (conflito) {
        const eqObj = equipamentos.find(e => e.id === eqId);
        conflito.equipamentoNome = eqObj ? eqObj.nome : conflito.equipamentoNome;
        conflitosEncontrados.push(conflito);
      }
    }
  }

  if (conflitosEncontrados.length > 0) {
    const primeiro = conflitosEncontrados[0];
    const dataFormatada = primeiro.data.split('-').reverse().join('/');
    const aulasFormatadas = formatAulasSummary(primeiro.aulasConflitantes);

    const msg = conflitosEncontrados.length === 1
      ? `Não é possível agendar: O equipamento "${primeiro.equipamentoNome}" já está agendado para ${primeiro.solicitante}${primeiro.turmaOuSala ? ` (${primeiro.turmaOuSala})` : ''} no dia ${dataFormatada} na(s) aula(s) ${aulasFormatadas}.`
      : `Não é possível agendar: Foram encontrados ${conflitosEncontrados.length} conflitos com agendamentos existentes. Exemplo: "${primeiro.equipamentoNome}" já agendado para ${primeiro.solicitante} em ${dataFormatada} (${aulasFormatadas}).`;

    return {
      isValid: false,
      errorMessage: msg,
      conflitos: conflitosEncontrados
    };
  }

  return { isValid: true };
}
