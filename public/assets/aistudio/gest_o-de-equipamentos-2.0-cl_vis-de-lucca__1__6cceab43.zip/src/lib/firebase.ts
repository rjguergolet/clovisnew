import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, doc, getDocFromServer, Firestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

// Inicializa a aplicação Firebase com as credenciais do projeto
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Conecta ao Firestore (suporta banco padrão "(default)" ou nomeado)
export const db: Firestore = (firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)')
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

export const auth = getAuth(app);
export const getDb = (): Firestore => db;

// Validação de conectividade com o Firestore
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Aviso: Cliente offline ou verificando conexão com o Firebase.");
    }
  }
}

testConnection();
