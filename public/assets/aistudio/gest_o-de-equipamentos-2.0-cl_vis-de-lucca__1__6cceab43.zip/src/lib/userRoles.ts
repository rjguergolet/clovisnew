import { User } from 'firebase/auth';
import { UserRole, UsuarioDoc } from '../types';

export const SUPER_ADMIN_EMAILS = [
  'rodrigo.guergolet@educacao.sp.gov.br',
  'rjguergolet@gmail.com'
];

export const SUPER_ADMIN_USERNAMES = [
  'rodrigo.guergolet',
  'rodrigo',
  'rjguergolet',
  'admin',
  'master'
];

export const SUPER_ADMIN_EMAIL = 'rodrigo.guergolet@educacao.sp.gov.br';
export const SUPER_ADMIN_DEFAULT_PASSWORD = 'admin';
export function isEquipamentoAtivo(statusEquipamento?: string | null): boolean {
  if (!statusEquipamento) return true;
  const s = statusEquipamento.trim().toLowerCase();
  return s === 'ativo' || s === 'disponivel' || s === 'disponível';
}

export function isEquipamentoEmUsoFixo(equipamento: {
  usoPermanente?: boolean | string | null;
  responsavelPermanente?: string | null;
  localPermanente?: string | null;
}): boolean {
  if (equipamento.usoPermanente === true || String(equipamento.usoPermanente).toLowerCase() === 'true') {
    return true;
  }
  return false;
}

export function isEquipamentoAptoParaEmprestimo(equipamento: {
  statusEquipamento?: string | null;
  estadoConservacao?: string | null;
  usoPermanente?: boolean | string | null;
  responsavelPermanente?: string | null;
  localPermanente?: string | null;
}): boolean {
  // 1. Equipamentos de Uso Fixo / Permanente NUNCA podem ser agendados ou emprestados
  if (isEquipamentoEmUsoFixo(equipamento)) {
    return false;
  }
  
  // 2. Status do equipamento (deve ser Ativo ou Disponível)
  const statusOk = isEquipamentoAtivo(equipamento.statusEquipamento);
  if (!statusOk) return false;

  // 3. Estado de conservação (não pode ser Inoperante, Descartado ou Danificado grave)
  const estadoConservacao = (equipamento.estadoConservacao || '').trim().toLowerCase();
  const estadoOk = estadoConservacao !== 'inoperante' && estadoConservacao !== 'descartado';
  return estadoOk;
}

export function cleanUsername(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '.')
    .replace(/[^a-z0-9._-]/g, '');
}

export function usernameToAuthEmail(input: string): string {
  const trimmed = input.trim().toLowerCase();
  if (trimmed.includes('@')) {
    return trimmed;
  }
  const clean = cleanUsername(trimmed);
  if (clean === 'rodrigo.guergolet' || clean === 'rodrigo') {
    return SUPER_ADMIN_EMAIL;
  }
  if (clean === 'rjguergolet') {
    return 'rjguergolet@gmail.com';
  }
  return `${clean || 'usuario'}@equipamentos.local`;
}

export function isSuperAdminEmail(emailOrUser?: string | null): boolean {
  if (!emailOrUser) return false;
  const normalized = emailOrUser.trim().toLowerCase();
  const clean = cleanUsername(normalized);
  const withoutDomain = normalized.split('@')[0];

  return (
    SUPER_ADMIN_EMAILS.some(adminEmail => adminEmail.toLowerCase() === normalized) ||
    SUPER_ADMIN_USERNAMES.some(adminUser => adminUser.toLowerCase() === normalized || adminUser.toLowerCase() === clean || adminUser.toLowerCase() === withoutDomain)
  );
}

export const USER_ROLES: Record<string, { label: string; description: string; badgeColor: string; icon: string }> = {
  // Perfis Escolares Solicitados
  PROFESSOR: {
    label: 'Professor',
    description: 'Docente: consulta inventário de itens disponíveis e realiza agendamentos de equipamentos e kits para suas aulas (retirada e devolução são gerenciadas pela equipe escolar).',
    badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
    icon: 'GraduationCap'
  },
  CGPG: {
    label: 'CGPG',
    description: 'Coordenação Geral Pedagógica: acompanhamento pedagógico, agendamento de recursos e controle de uso.',
    badgeColor: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30',
    icon: 'BookOpen'
  },
  SECRETARIA: {
    label: 'Secretaria',
    description: 'Secretaria Escolar: gestão de registros, inventário, apoio administrativo e empréstimos.',
    badgeColor: 'bg-teal-500/10 text-teal-300 border-teal-500/30',
    icon: 'FileSpreadsheet'
  },
  VICE_DIRETOR: {
    label: 'Vice-Diretor',
    description: 'Vice-Direção: gestão administrativa, supervisão de equipamentos, agendamentos e controle geral.',
    badgeColor: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
    icon: 'ShieldCheck'
  },
  PROFESSOR_PAAC: {
    label: 'Professor PAAC',
    description: 'Professor PAAC (Apoio Pedagógico/Tecnologia): organização de materiais, kits pedagógicos e empréstimos.',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    icon: 'Sparkles'
  },
  DIRETOR: {
    label: 'Diretor',
    description: 'Direção Escolar: controle institucional, relatórios, gestão de inventário e permissões gerais.',
    badgeColor: 'bg-purple-500/10 text-purple-300 border-purple-500/30',
    icon: 'Crown'
  },

  // Perfis Legados / Administrativos do Sistema
  padrao: {
    label: 'Padrão',
    description: 'Operador padrão: visualização do inventário, consulta e realização de empréstimos/devoluções.',
    badgeColor: 'bg-slate-500/10 text-slate-300 border-slate-500/30',
    icon: 'User'
  },
  adm: {
    label: 'Adm',
    description: 'Administrador: controle total de equipamentos e empréstimos, exportação e importação de backups.',
    badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    icon: 'ShieldCheck'
  },
  adm_total: {
    label: 'Adm total',
    description: 'Super Administrador (Master): gestão total do sistema, criação de usuários, permissões e controle geral.',
    badgeColor: 'bg-amber-500/10 text-amber-300 border-amber-500/40 shadow-sm shadow-amber-500/10',
    icon: 'Crown'
  }
};

/**
 * Normaliza qualquer texto de perfil para a chave padrão reconhecida
 */
export function normalizeUserRole(inputRole?: string | null): string {
  if (!inputRole) return 'PROFESSOR';
  const clean = inputRole.trim().toUpperCase().replace(/[\s\-_]+/g, '_');

  if (clean === 'PROFESSOR' || clean === 'PROF' || clean === 'DOCENTE') return 'PROFESSOR';
  if (clean === 'CGPG' || clean === 'COORDENADOR' || clean === 'COORDENACAO' || clean === 'COORD') return 'CGPG';
  if (clean === 'SECRETARIA' || clean === 'SECRETARIO' || clean === 'SEC') return 'SECRETARIA';
  if (clean === 'VICE_DIRETOR' || clean === 'VICEDIRETOR' || clean === 'VICE_DIRECAO' || clean === 'VICE') return 'VICE_DIRETOR';
  if (clean === 'PROFESSOR_PAAC' || clean === 'PAAC' || clean === 'PROF_PAAC' || clean === 'PROCOA') return 'PROFESSOR_PAAC';
  if (clean === 'DIRETOR' || clean === 'DIRETORA' || clean === 'DIRECAO') return 'DIRETOR';
  if (clean === 'ADM_TOTAL' || clean === 'MASTER' || clean === 'SUPER_ADMIN' || clean === 'ADMIN_TOTAL') return 'adm_total';
  if (clean === 'ADM' || clean === 'ADMIN' || clean === 'ADMINISTRADOR') return 'adm';
  if (clean === 'PADRAO' || clean === 'USUARIO') return 'padrao';

  // Se já for uma chave conhecida
  if (USER_ROLES[clean]) return clean;
  if (USER_ROLES[clean.toLowerCase()]) return clean.toLowerCase();

  return clean;
}

/**
 * Retorna o papel de permissão efetivo do usuário.
 * Os e-mails de super admin sempre possuem 'adm_total'.
 */
export function resolveUserRole(user: User | null, userDoc?: UsuarioDoc | null): UserRole {
  if (!user || !user.email) return 'PROFESSOR';

  if (isSuperAdminEmail(user.email)) {
    return 'adm_total';
  }

  if (userDoc?.perfil) {
    const normalized = normalizeUserRole(String(userDoc.perfil));
    return normalized;
  }

  return 'PROFESSOR';
}

/**
 * Verifica se o usuário tem privilégio de Adm total
 */
export function isSuperAdmin(role: UserRole, email?: string | null): boolean {
  if (isSuperAdminEmail(email)) return true;
  const normalized = normalizeUserRole(String(role));
  return normalized === 'adm_total';
}

/**
 * Verifica se o usuário é Diretor, Vice-Diretor ou Super Administrador (Acesso Total)
 */
export function isDirectorOrTotal(role: UserRole, email?: string | null): boolean {
  if (isSuperAdminEmail(email)) return true;
  const normalized = normalizeUserRole(String(role));
  return (
    normalized === 'DIRETOR' ||
    normalized === 'VICE_DIRETOR' ||
    normalized === 'adm_total' ||
    normalized === 'adm'
  );
}

/**
 * Verifica se o usuário tem privilégio administrativo (Direção, Coordenação, Secretaria, PAAC ou Adm)
 */
export function isAdminOrAbove(role: UserRole, email?: string | null): boolean {
  if (isSuperAdminEmail(email)) return true;
  const normalized = normalizeUserRole(String(role));
  return (
    normalized === 'adm' ||
    normalized === 'adm_total' ||
    normalized === 'DIRETOR' ||
    normalized === 'VICE_DIRETOR' ||
    normalized === 'SECRETARIA' ||
    normalized === 'CGPG' ||
    normalized === 'PROFESSOR_PAAC'
  );
}

/**
 * Matriz de Permissões Rigorosa por Perfil Escolar
 * - PROFESSOR: Apenas agendamento e visualização de itens disponíveis.
 * - CGPG, SECRETARIA, PROFESSOR_PAAC: Acesso administrativo, mas NÃO podem deletar equipamentos ou dados em massa (apenas agendamentos de equipamentos).
 * - DIRETOR, VICE_DIRETOR, ADM_TOTAL: Acesso total ao sistema + Simulação de perfis.
 */
export const PERMISSIONS = {
  // Equipamentos (Inventário)
  canViewEquipamentos: (_role: UserRole) => true,
  canAddEquipamento: (role: UserRole) => isAdminOrAbove(role),
  canEditEquipamento: (role: UserRole) => isAdminOrAbove(role),
  // CGPG, Secretaria e Professor PAAC NÃO podem deletar equipamentos; apenas Diretor, Vice-Diretor e Adm Total
  canDeleteEquipamento: (role: UserRole) => isDirectorOrTotal(role),
  canAssignUsoPermanente: (role: UserRole) => isAdminOrAbove(role),
  
  // Empréstimos & Agendamentos
  canViewEmprestimos: (_role: UserRole) => true,
  canCreateEmprestimo: (_role: UserRole) => true, // Todos podem agendar
  // Editar agendamento: Apenas CGPG, Secretaria, PAAC, Diretor, Vice-Diretor e Adm Total (Professor NÃO pode editar)
  canEditEmprestimo: (role: UserRole) => isAdminOrAbove(role),
  // Retirada e Devolução: apenas CGPG, Secretaria, PAAC, Diretor, Vice-Diretor e Adm Total (Professor apenas agenda)
  canReturnEmprestimo: (role: UserRole) => isAdminOrAbove(role),
  canChangeEmprestimoStatus: (role: UserRole) => isAdminOrAbove(role),
  // Deletar agendamento de equipamento: CGPG, Secretaria, PAAC, Diretor, Vice-Diretor e Adm Total podem
  canDeleteEmprestimo: (role: UserRole) => isAdminOrAbove(role),
  canManageRecurringLoans: (role: UserRole) => isAdminOrAbove(role),

  // Configurações, Backups & Limpeza
  // Professor, CGPG, Secretaria e Professor PAAC têm acesso APENAS a troca de senha / Minha Conta.
  // Apenas Diretor, Vice-Diretor e Adm Total têm acesso às abas de Backups, Gestão de Usuários, Simulador e Banco.
  canAccessFullConfig: (role: UserRole, email?: string | null) => isDirectorOrTotal(role, email) || isSuperAdminEmail(email),
  canExportBackup: (role: UserRole) => isDirectorOrTotal(role),
  canImportBackup: (role: UserRole) => isDirectorOrTotal(role),
  canUploadBackup: (role: UserRole) => isDirectorOrTotal(role),
  canWipeDatabase: (role: UserRole) => isDirectorOrTotal(role),
  
  // Gestão de Usuários & Acessos
  canManageUsers: (role: UserRole) => isDirectorOrTotal(role),
  canViewUsers: (role: UserRole) => isDirectorOrTotal(role),
  canCreateUsers: (role: UserRole) => isDirectorOrTotal(role),
  canEditUserRole: (role: UserRole) => isDirectorOrTotal(role),
  canDeleteUsers: (role: UserRole) => isDirectorOrTotal(role),
  canToggleUserStatus: (role: UserRole) => isDirectorOrTotal(role),

  // Simulação de Perfis (Módulo Exclusivo para Direção e Adm Total)
  canSimulateRoles: (role: UserRole, email?: string | null) => isDirectorOrTotal(role, email) || isSuperAdminEmail(email),
};
