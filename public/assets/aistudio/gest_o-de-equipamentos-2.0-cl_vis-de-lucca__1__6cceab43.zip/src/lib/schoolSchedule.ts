import { AulaPeriod } from '../types';

export const AULAS_MANHA: AulaPeriod[] = [
  {
    id: 'M1',
    turno: 'Manhã',
    numero: 1,
    label: '1ª Aula',
    horario: '07:00 - 07:45',
    descricaoCompleta: '1ª Aula (07:00 - 07:45)'
  },
  {
    id: 'M2',
    turno: 'Manhã',
    numero: 2,
    label: '2ª Aula',
    horario: '07:45 - 08:30',
    descricaoCompleta: '2ª Aula (07:45 - 08:30)'
  },
  {
    id: 'M3',
    turno: 'Manhã',
    numero: 3,
    label: '3ª Aula',
    horario: '08:30 - 09:15',
    descricaoCompleta: '3ª Aula (08:30 - 09:15)'
  },
  {
    id: 'M4',
    turno: 'Manhã',
    numero: 4,
    label: '4ª Aula',
    horario: '09:30 - 10:15',
    descricaoCompleta: '4ª Aula (09:30 - 10:15)'
  },
  {
    id: 'M5',
    turno: 'Manhã',
    numero: 5,
    label: '5ª Aula',
    horario: '10:15 - 11:00',
    descricaoCompleta: '5ª Aula (10:15 - 11:00)'
  },
  {
    id: 'M6',
    turno: 'Manhã',
    numero: 6,
    label: '6ª Aula',
    horario: '11:00 - 11:45',
    descricaoCompleta: '6ª Aula (11:00 - 11:45)'
  },
  {
    id: 'M7',
    turno: 'Manhã',
    numero: 7,
    label: '7ª Aula',
    horario: '11:45 - 12:30',
    descricaoCompleta: '7ª Aula (11:45 - 12:30)'
  }
];

export const AULAS_TARDE: AulaPeriod[] = [
  {
    id: 'T1',
    turno: 'Tarde',
    numero: 1,
    label: '1ª Aula',
    horario: '13:00 - 13:45',
    descricaoCompleta: '1ª Aula (13:00 - 13:45)'
  },
  {
    id: 'T2',
    turno: 'Tarde',
    numero: 2,
    label: '2ª Aula',
    horario: '13:45 - 14:30',
    descricaoCompleta: '2ª Aula (13:45 - 14:30)'
  },
  {
    id: 'T3',
    turno: 'Tarde',
    numero: 3,
    label: '3ª Aula',
    horario: '14:30 - 15:15',
    descricaoCompleta: '3ª Aula (14:30 - 15:15)'
  },
  {
    id: 'T4',
    turno: 'Tarde',
    numero: 4,
    label: '4ª Aula',
    horario: '15:30 - 16:15',
    descricaoCompleta: '4ª Aula (15:30 - 16:15)'
  },
  {
    id: 'T5',
    turno: 'Tarde',
    numero: 5,
    label: '5ª Aula',
    horario: '16:15 - 17:00',
    descricaoCompleta: '5ª Aula (16:15 - 17:00)'
  },
  {
    id: 'T6',
    turno: 'Tarde',
    numero: 6,
    label: '6ª Aula',
    horario: '17:00 - 17:45',
    descricaoCompleta: '6ª Aula (17:00 - 17:45)'
  },
  {
    id: 'T7',
    turno: 'Tarde',
    numero: 7,
    label: '7ª Aula',
    horario: '17:45 - 18:30',
    descricaoCompleta: '7ª Aula (17:45 - 18:30)'
  }
];

export const TODAS_AS_AULAS: AulaPeriod[] = [...AULAS_MANHA, ...AULAS_TARDE];
export const ALL_AULAS: AulaPeriod[] = TODAS_AS_AULAS;

export const AULA_MAP: Record<string, AulaPeriod> = TODAS_AS_AULAS.reduce((acc, aula) => {
  acc[aula.id] = aula;
  return acc;
}, {} as Record<string, AulaPeriod>);

export function getAulaInfo(id: string): AulaPeriod | undefined {
  return AULA_MAP[id];
}

export function formatAulasSummary(aulas?: string[] | null): string {
  if (!aulas || aulas.length === 0) return 'Horário Integral / Não especificado';

  const manhaSelected = aulas.filter(id => id.startsWith('M'));
  const tardeSelected = aulas.filter(id => id.startsWith('T'));

  const parts: string[] = [];

  if (manhaSelected.length === 7) {
    parts.push('Manhã (Todas as 7 aulas)');
  } else if (manhaSelected.length > 0) {
    const numeros = manhaSelected.map(id => AULA_MAP[id]?.numero || id).sort((a, b) => Number(a) - Number(b));
    parts.push(`Manhã (${numeros.map(n => `${n}ª`).join(', ')})`);
  }

  if (tardeSelected.length === 7) {
    parts.push('Tarde (Todas as 7 aulas)');
  } else if (tardeSelected.length > 0) {
    const numeros = tardeSelected.map(id => AULA_MAP[id]?.numero || id).sort((a, b) => Number(a) - Number(b));
    parts.push(`Tarde (${numeros.map(n => `${n}ª`).join(', ')})`);
  }

  return parts.join(' • ') || `${aulas.length} aula(s)`;
}

export function determineTurnoFromAulas(aulas?: string[]): string {
  if (!aulas || aulas.length === 0) return 'Manhã';
  const hasM = aulas.some(id => id.startsWith('M'));
  const hasT = aulas.some(id => id.startsWith('T'));
  if (hasM && hasT) return 'Integral / Ambos';
  if (hasM) return 'Manhã';
  if (hasT) return 'Tarde';
  return 'Manhã';
}

export interface DiaSemanaOption {
  id: number; // 0=Dom, 1=Seg, 2=Ter, 3=Qua, 4=Qui, 5=Sex, 6=Sáb
  label: string;
  short: string;
}

export const DIAS_SEMANA_OPCOES: DiaSemanaOption[] = [
  { id: 1, label: 'Segunda-feira', short: 'Seg' },
  { id: 2, label: 'Terça-feira', short: 'Ter' },
  { id: 3, label: 'Quarta-feira', short: 'Qua' },
  { id: 4, label: 'Quinta-feira', short: 'Qui' },
  { id: 5, label: 'Sexta-feira', short: 'Sex' },
  { id: 6, label: 'Sábado', short: 'Sáb' }
];

/**
 * Gera todas as datas (YYYY-MM-DD) entre dataInicio e dataFim que coincidem com os dias da semana selecionados
 */
export function gerarDatasRecorrentes(
  dataInicioStr: string,
  dataFimStr: string,
  diasSemana: number[]
): string[] {
  if (!dataInicioStr || !dataFimStr || diasSemana.length === 0) return [];
  
  const datas: string[] = [];
  const start = new Date(dataInicioStr + 'T00:00:00');
  const end = new Date(dataFimStr + 'T23:59:59');

  if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) {
    return [];
  }

  const current = new Date(start);
  // Limite máximo de segurança (ex: 365 dias para evitar loops infinitos)
  let count = 0;
  while (current <= end && count < 400) {
    const dayOfWeek = current.getDay(); // 0 a 6
    if (diasSemana.includes(dayOfWeek)) {
      const year = current.getFullYear();
      const month = String(current.getMonth() + 1).padStart(2, '0');
      const day = String(current.getDate()).padStart(2, '0');
      datas.push(`${year}-${month}-${day}`);
    }
    current.setDate(current.getDate() + 1);
    count++;
  }

  return datas;
}
