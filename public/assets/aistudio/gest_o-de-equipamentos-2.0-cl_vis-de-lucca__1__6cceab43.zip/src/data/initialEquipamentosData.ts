// Lista de equipamentos pré-formatada a partir da planilha fornecida pelo usuário
export interface EquipamentoRawData {
  categoria: string;
  fabricante: string;
  modelo: string;
  numeroSerie: string;
  statusEquipamento: string;
  avaliacaoTecnica: string;
  descricao: string;
}

export const INITIAL_CSV_EQUIPAMENTOS_STRING = `CATEGORIA DO EQUIPAMENTO;FABRICANTE;MODELO;NÚMERO DE SÉRIE;STATUS DO EQUIPAMENTO;AVALIAÇÃO TÉCNICA;DESCRIÇÃO
Chromebooks;SAMSUNG;01-Chromebook Samsung 4;0ANS9QCY304458F;Ativo;Excelente;1
Chromebooks;Samsung;Chromebook Samsung 4;0ANS9QCY304189T;Manutenção;Danificado;Check ok Sem teclado (mal uso) - da pra usar com teclado físico Etiqueta nº18
Chromebooks;SAMSUNG;02 - Chromebook Samsung 4;0ANS9QCY304495A;Ativo;Bom;
Chromebooks;SAMSUNG;03-Chromebook Samsung 4;0ANS9Q CY304555B;Ativo;Bom;CHECK OK 26
Chromebooks;SAMSUNG;04 - Chromebook Samsung 23;0ANS9QAY506301Y;Ativo;Bom;CHECK OK 46
Chromebooks;SAMSUNG;05-Chromebook Samsung 4;0ANS9QCY301825W;Ativo;Bom;CHECK OK 41
Chromebooks;SAMSUNG;06 - Chromebook Samsung 4;0ANS9QCY304246E;Ativo;Excelente;
Chromebooks;SAMSUNG;07-Chromebook Samsung 4;0ANS9QCY201348F;Ativo;Bom;CHECK OK 74
Chromebooks;SAMSUNG;08-Chromebook Samsung 4;0ANS9QCY200861V;Ativo;Bom;CHECK OK  14
Desktop;LENOVO;ThinkCentre M75s;PE08G1C8;Manutenção;Bom;DISPONIVEL
Chromebooks;SAMSUNG;09 - Chromebook Samsung 4;0ANS9QCY301406W;Ativo;Bom;CHECK OK 27
Chromebooks;SAMSUNG;10 - Chromebook Samsung 23;0ANS9QCY304151X;Ativo;Bom;CHECK OK 11
Chromebooks;SAMSUNG;11-Chromebook Samsung 4;0ANS9QCY304222D;Ativo;Bom;CHECK OK  15
Chromebooks;SAMSUNG;12-Chromebook Samsung 4;0ANS9QCY201460N;Ativo;Bom;CHECK OK 36
Chromebooks;SAMSUNG;13 - Chromebook Samsung 4;0ANS9QCY301824X;Ativo;Bom;CHECK OK 07
Chromebooks;SAMSUNG;14 - Chromebook Samsung 4;0ANS9QCY304558P;Ativo;Bom;
Chromebooks;SAMSUNG;15 - Chromebook Samsung 4;0ANS9QCY304454V;Ativo;Bom;CHECK OK 48
Chromebooks;SAMSUNG;16 - Chromebook Samsung 21;0ANS9QCY201033Y;Ativo;Bom;CHECK OK 16
Chromebooks;SAMSUNG;16 - Chromebook Samsung 4;0ANS9QCY304510T;Ativo;Bom;
Chromebooks;SAMSUNG;17 - Chromebook Samsung 4;0ANS9QCY304564D;Ativo;Bom;
Chromebooks;SAMSUNG;18 - Chromebook Samsung 4;0ANS9QCY303112Z;Ativo;Bom;
Chromebooks;SAMSUNG;19-Chromebook Samsung 4;0ANS9QCY304194R;Ativo;Bom;CHECK OK 47
Chromebooks;SAMSUNG;20 - Chromebook Samsung 4;0ANS9QCY304496H;Ativo;Bom;
Chromebooks;SAMSUNG;21-Chromebook Samsung 4;0ANS9QCY301594D;Ativo;Excelente;CHECK OK 76
Chromebooks;SAMSUNG;22 - Chromebook Samsung 4;0ANS9QCY200914K;Ativo;Bom;
Chromebooks;SAMSUNG;23-Chromebook Samsung 4;0ANS9QCY200198V;Ativo;Bom;CHECK OK 12
Chromebooks;SAMSUNG;24- Chromebook Samsung 4;0ANS9QCY304464R;Ativo;Bom;CHECK OK 40
Chromebooks;SAMSUNG;25-Chromebook Samsung 4;0ANS9QCY304441V;Ativo;Bom;CHECK OK 17
Chromebooks;SAMSUNG;27 - Chromebook Samsung 4;0ANS9QCY304437H;Ativo;Bom;
Chromebooks;SAMSUNG;28 - Chromebook Samsung 4;0ANS9QCY304740H;Ativo;Bom;
Chromebooks;SAMSUNG;29 - Chromebook Samsung 4;0ANS9Q CY201466Z;Ativo;Bom;
Chromebooks;SAMSUNG;30 - Chromebook Samsung 4;0ANS9QCY200821A;Ativo;Bom;
Chromebooks;SAMSUNG;31 - Chromebook Samsung 4;0ANS9QCY304521Z;Ativo;Bom;
Chromebooks;SAMSUNG;32 - Chromebook Samsung 4;0ANS9QCY304443J;Ativo;Bom;
Chromebooks;SAMSUNG;33 -  Chromebook Samsung 4;0ANS9QCY304202V;Ativo;Excelente;Check ok Etiqueta nº39
Chromebooks;SAMSUNG;34 - Chromebook Samsung 4;0ANS9QCY304730L;Ativo;Bom;
Chromebooks;SAMSUNG;35 - Chromebook Samsung 22;0ANS9QCY304217J;Ativo;Bom;CHECK OK 25
Desktop;LENOVO;ThinkCentre M75s;PE06V7NB;Manutenção;Bom;DISPONIVEL
Desktop;LENOVO;ThinkCentre M75s;PE08G11Z;Manutenção;Bom;DISPONIVEL
Chromebooks;SAMSUNG;36-Chromebook Samsung 4;0ANS9Q CY200246D;Ativo;Bom;check ok
Chromebooks;SAMSUNG;37 - Chromebook Samsung 4;0ANS9QCY304563L;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G186;Manutenção;Bom;DISPONIVEL
Chromebooks;SAMSUNG;38 - Chromebook Samsung 4;0ANS9QCY304225R;Ativo;Bom;
Chromebooks;SAMSUNG;39 - Chromebook Samsung 4;0ANS9QCY302577V;Ativo;Bom;
Chromebooks;SAMSUNG;40 - Chromebook Samsung 4;0ANS9QCY301794W;Ativo;Bom;
Outros;MULTILASER;Multilaser_G_2;20.232.860.005.970;Inativo;Danificado;CHECK OK Celular  NÃO SEGURA CARGA
Chromebooks;SAMSUNG;41-Chromebook Samsung 4;0ANS9Q CY201461X;Ativo;Bom;41
Notebook;MULTILASER;ULTRABOOK UL150;2,70521E+14;Inativo;Danificado;CHECK OK 01 TECLADO INATIVO
Chromebooks;SAMSUNG;42-Chromebook Samsung 4;0ANS9Q CY304457Z;Ativo;Bom;42
Notebook;MULTILASER;ULTRABOOK UL150;260521204101213/SERIAL;Inativo;Danificado;CHECK OK TECLADO INATIVO
Notebook;MULTILASER;ULTRABOOK UL150;270521233317118/SERIAL;Inativo;Danificado;CHECK OK NÃO LIGA, BATERIA ESTUFADA
Notebook;MULTILASER;ULTRABOOK UL150;260521204102845/SERIAL;Inativo;Danificado;CHECK OK TECLAS V N NÃO FUNCIONAM
Chromebooks;SAMSUNG;43 - Chromebook Samsung 4;0ANS9QCY304451R;Ativo;Bom;
Chromebooks;SAMSUNG;44 - Chromebook Samsung 4;0ANS9QCY303598E;Ativo;Excelente;44
Notebook;POSITIVO;N1110 (128 GB);4AD91KR9D;Inativo;Danificado;CHECK OK 70 PROBLEMA DE REDE
Chromebooks;SAMSUNG;45-Chromebook Samsung 4;0ANS9QCY303578B;Ativo;Bom;45
Notebook;POSITIVO;N1110 (128 GB);4AD91JZ1Q;Inativo;Danificado;CHECK OK 74 BATERIA NÃO FUNCIONA
Notebook;POSITIVO;N1110 (128 GB);4AD91JQ1Z;Inativo;Danificado;Check ok Etiqueta 27 Falta teclas
Chromebooks;SAMSUNG;46-Chromebook Samsung 4;0ANS9QCY304220E;Ativo;Bom;46
Desktop;LENOVO;OUTRO;PE06SCKY;Ativo;Bom;DISPONIVEL
Notebook;POSITIVO;N1110 (128 GB);4AD91KL7L;Inativo;Danificado;CHECK OK 79 DOBRADIÇA
Desktop;LENOVO;OUTRO;PE06SCL7;Ativo;Bom;DISPONIVEL
Desktop;LENOVO;ThinkCentre M75s;PE08G17X;Ativo;Bom;
Notebook;POSITIVO;N1110 (128 GB);4AD91JJ78;Inativo;Danificado;CHECK OK 07 TELA AZUL
Notebook;POSITIVO;N1110 (128 GB);4AD91JK1H;Inativo;Danificado;Check ok etiqueta 22 s2 DISPONIVEL
Desktop;LENOVO;ThinkCentre M75s;PE08G19W;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G191;Ativo;Bom;
Notebook;POSITIVO;N1110 (128 GB);4AD91KF9D;Inativo;Danificado;CHECK OK TECLADO INATIVO
Desktop;LENOVO;ThinkCentre M75s;PE08019N;Ativo;Bom;DISPONIVEL
Notebook;POSITIVO;N1110 (128 GB);4AB419P4P;Inativo;Danificado;CHECK OK  22 FALTANDO 2 TECLAS SSD
Desktop;LENOVO;ThinkCentre M75s;PE08G17T;Ativo;Bom;
Notebook;POSITIVO;N1110 (128 GB);4AB41978R;Inativo;Danificado;CHECK OK 67 BATERIA NÃO CARREGA
Notebook;POSITIVO;N1110 (128 GB);4AD91JC33;Inativo;Danificado;CHECK OK 73 BATERIA NÃO CARREGA
Notebook;POSITIVO;N1110 (128 GB);4AD91JQ24;Inativo;Danificado;CHECK OK DOBRADIÇA
Notebook;POSITIVO;N1110 (128 GB);4AD91KP3D;Inativo;Danificado;CHECK OK 04 EM CURTO
Notebook;POSITIVO;N1110 (128 GB);SS2;Inativo;Danificado;CHECK OK TELA QUEBRADA
Notebook;POSITIVO;N1110 (128 GB);4AD91KR3J;Inativo;Danificado;CHECK OK 24 TECLADO INATIVO
Notebook;POSITIVO;N1110 (128 GB);4AB419208;Inativo;Danificado;CHECK OK 020 SSD
Notebook;POSITIVO;N1110 (128 GB);4AD91JS84;Inativo;Danificado;CHECK OK 77 SSD
Desktop;LENOVO;ThinkCentre M75s;PE06V6S2;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G0GG;Ativo;Bom;
Notebook;POSITIVO;N1110 (128 GB);4AD91KQ85;Inativo;Danificado;CHECK OK 01 TECLADO INATIVO
Notebook;POSITIVO;N1110 (128 GB);4AD91JX0F;Inativo;Danificado;CHECK OK 76 SSD
Desktop;LENOVO;ThinkCentre M75s;PE08G11Y;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G17P;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE06V6TH;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G1C8;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G156;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91KC5K;Inativo;Danificado;CHeck ok DOBRADIA E BATERIA Etiqueta 20
Desktop;LENOVO;ThinkCentre M75s;PE08G11W;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G15C;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G17V;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91JW51;Inativo;Danificado;CHECK OK BATERIA 91
Desktop;LENOVO;ThinkCentre M75s;PE06V6VQ;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91KY1C;Inativo;Danificado;Check ok Não liga Etiqueta 18
Notebook;POSITIVO;N1110 (32 GB);4AD91JJ4T;Inativo;Danificado;Check ok etiqueta 25 SSD RUIM
Notebook;POSITIVO;N1110 (32 GB);41AD91JD0R;Manutenção;Danificado;check ok Problema no teclado
Notebook;POSITIVO;N1110 (32 GB);4AB419T41;Inativo;Danificado;Check ok etiqueta 23 FORMATAR ssd pequeno
Notebook;POSITIVO;N1110 (32 GB);4AB418Z4C;Inativo;Danificado;Check ok etiqueta 12 FORMATAR - sem memória
Notebook;POSITIVO;N1110 (32 GB);4AD91JG2A;Manutenção;Danificado;Check ok Etiqueta 02 TECLADO
Notebook;POSITIVO;N1110 (32 GB);4AD91JWOC;Manutenção;Danificado;CHECK OK TECLADO 01 SALA 01
Notebook;POSITIVO;N1110 (32 GB);4AB91JG5P;Manutenção;Danificado;check ok possivelmente placa de rede etiqueta 37
Notebook;POSITIVO;N1110 (32 GB);4AD91JZ2V;Inativo;Danificado;CHECK OK TECLADO 071
Desktop;LENOVO;ThinkCentre M75s;PE08G17Q;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91JF0X;Manutenção;Danificado;Check ok etiqueta 21 DOBRADIA
Notebook;POSITIVO;N1110 (32 GB);4AB419350;Inativo;Danificado;CHECK OK TECLADO e NÃO LIGA 90
Desktop;LENOVO;ThinkCentre M75s;PE06V6Q7;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AB41962U;Manutenção;Em análise;Check ok SSD e tela Etiqueta 22
Notebook;POSITIVO;N1110 (32 GB);4AD91KD28;Inativo;Danificado;CHECK OK 66
Notebook;POSITIVO;N1110 (32 GB);4AB419B0Z;Inativo;Em análise;Check ok SSD RUIM Etiqueta 11
Notebook;POSITIVO;N1110 (32 GB);4AB41923N;Manutenção;Danificado;Check ok etiqueta 11 FORMATAR Não acessa login
Notebook;POSITIVO;N1110 (32 GB);4AB419J1S;Inativo;Danificado;Check ok etiqueta 31 FORMATAR - sem memória
Notebook;POSITIVO;N1110 (32 GB);4AB41934V;Inativo;Danificado;Check ok etiqueta 36 SSD RUIM
Notebook;POSITIVO;N1110 (32 GB);4AD91JV4T;Inativo;Danificado;CHECK OK FORMATAR SSD 90
Notebook;POSITIVO;N1110 (32 GB);4AD91JR3C;Manutenção;Danificado;Check ok Etiqueta 02 TECLADO
Notebook;POSITIVO;N1110 (32 GB);4AB419H6B;Inativo;Danificado;Check ok etiqueta 95 SISTEMA
Notebook;POSITIVO;N1110 (32 GB);4AD91JG3F;Inativo;Danificado;Check ok Etiqueta 36 teclado e rede
Notebook;POSITIVO;N1110 (32 GB);4AD91JP7Q;Manutenção;Danificado;check ok Sem teclas no teclado etiqueta 11
Notebook;POSITIVO;N1110 (32 GB);4AB419R1G;Inativo;Danificado;Check ok etiqueta 97 TELA
Notebook;POSITIVO;N1110 (32 GB);4AD91KJ3V;Inativo;Danificado;Check ok etiqueta 37 Não liga e sem CAMERA
Notebook;POSITIVO;N1110 (32 GB);4AD91JF12;Inativo;Danificado;CHECK OK DOBRADIÇA
Notebook;POSITIVO;N1110 (32 GB);4AB41971S;Inativo;Danificado;CHECK OK SSD RUIM SALA 02
Desktop;LENOVO;ThinkCentre M75s;PE08G11Z;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AB419C9B;Inativo;Danificado;check ok etiqueta 94 SSD problema
Notebook;POSITIVO;N1110 (32 GB);4AD91JV09;Inativo;Danificado;Check ok Etiqueta 18 BATERIA
Notebook;POSITIVO;N1110 (32 GB);4AD91JG99;Inativo;Danificado;Check ok etiqueta 95 TECLADO
Notebook;POSITIVO;N1110 (32 GB);4AB418Z37;Inativo;Danificado;Check ok etiqueta 07 TECLADO
Notebook;POSITIVO;N1110 (32 GB);4AB419P05;Inativo;Danificado;Check ok Etiqueta 30 TECLADO
Notebook;POSITIVO;N1110 (32 GB);4AD91KV2Q;Inativo;Danificado;Check ok Etiqueta 27 Carcaça quebrada - Mal uso
Notebook;POSITIVO;N1110 (32 GB);4AD91JL54;Manutenção;Danificado;check Etiqueta 23
Notebook;POSITIVO;N1110 (32 GB);4AB41966E;Inativo;Danificado;Check ok etiqueta 96 FORMATAR - ssd pequena
Notebook;POSITIVO;N1110 (32 GB);4AD91JW86;Inativo;Danificado;Check ok Tela boa SSD ruim Etiqueta 03
Notebook;POSITIVO;N1110 (32 GB);4AB419M4G;Inativo;Excelente;Check ok etiqueta 30 NO LIGA
Notebook;POSITIVO;N1110 (32 GB);4AD91KK43;Inativo;Danificado;Check ok Etiqueta 17 BIOS
Desktop;LENOVO;ThinkCentre M75s;PE08G123;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91JD8V;Inativo;Danificado;Check ok etiqueta 95 TELA
Notebook;POSITIVO;N1110 (32 GB);4AB419923;Manutenção;Danificado;CHECK OK TECLADO 31 SALA 02
Notebook;POSITIVO;N1110 (32 GB);4AB419B29;Manutenção;Em análise;check  Não tem garantia Equipamento 18 Provavel SSD
Desktop;LENOVO;ThinkCentre M75s;PE08G11C;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G17Y;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE06V6Q5;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91JJ09;Inativo;Danificado;Check ok Etiqueto 96 NO LIGA
Desktop;LENOVO;ThinkCentre M75s;PE08G124;Ativo;Bom;
Notebook;POSITIVO;N1110 (32 GB);4AD91JQ0U;Inativo;Danificado;Check ok Etiqueta 09 s02 SSD danificado
Notebook;POSITIVO;N1110 (32 GB);4AD91JD0R;Manutenção;Em análise;Check ok Tela boa teclado quebrado Etiqueta 16
Notebook;POSITIVO;N1110 (32 GB);4AB419D4P;Inativo;Danificado;Check ok etiqueta 13 TECLADO - NIT
Desktop;LENOVO;ThinkCentre M75s;PE08GDNF;Ativo;Bom;DISPONIVEL
Notebook;POSITIVO;N1110 (32 GB);A4B41962U;Manutenção;Danificado;Check ok Tela azul Etiqueta 07
Notebook;POSITIVO;N1110 (32 GB);4AD91JN7K;Manutenção;Danificado;Check ok Etiqueta 25 Não liga
Notebook;POSITIVO;N1110 (32 GB);SS03;Inativo;Danificado;CHECK OK 12 PROBLEMA DE REDE
Desktop;LENOVO;ThinkCentre M75s;PE08G19W;Ativo;Bom;
Notebook;POSITIVO;N1110 (64 GB);4AB419002;Inativo;Danificado;CHECK OK DOBRADIÇA 069
Notebook;POSITIVO;N1110 (64 GB);4AD91KX31;Inativo;Danificado;check ok etiqueta 12 Teclado digitando sozinho
Notebook;POSITIVO;N1110 (64 GB);4AD91JN6F;Inativo;Danificado;CHECK OK 19 FALTANDO 22 TECLAS
Desktop;LENOVO;ThinkCentre M75s;PE08G151;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08GDWF;Ativo;Bom;
Notebook;POSITIVO;N1110 (64 GB);4AD91KT9J;Inativo;Danificado;CHECK OK 15 FALTANDO 7 TECLAS TELA AZUL
Notebook;POSITIVO;N1110 (64 GB);4AD91JS00;Inativo;Danificado;CHECK OK SEM WIFI 17 CARRINHO 02
Desktop;LENOVO;ThinkCentre M75s;PE08G18H;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G18P;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G175;Ativo;Bom;
Notebook;POSITIVO;N1110 (64 GB);4AB41976H;Inativo;Danificado;Check ok etiqueta 03 TECLADO
Notebook;POSITIVO;N1110 (64 GB);4AD91KW2T;Inativo;Danificado;CHECK OK SSD 30 SALA 02
Notebook;POSITIVO;N1110 (64 GB);4AD91JG00;Inativo;Danificado;CHECK OK 03 SEM CÂMERA, ESQUENTANDO FIO
Notebook;POSITIVO;N1110 (64 GB);4AD91JY42;Inativo;Danificado;check ok Dobradiça quebrada Etiqueta 11
Desktop;LENOVO;ThinkCentre M75s;PE06V6SB;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE08G121;Ativo;Bom;
Desktop;LENOVO;ThinkCentre M75s;PE06V6VG;Ativo;Bom;
Notebook;POSITIVO;01-N1110 (128 GB);4AB419189;Ativo;Bom;CHECK OK 68
Notebook;POSITIVO;02-N1110 (128 GB);4AB419W4A;Ativo;Bom;CHECK OK 10
Notebook;POSITIVO;03-N1110 (64 GB);4AD91JL3U;Ativo;Bom;CHECK OK 35 FALTANDO 6 TECLAS
Notebook;POSITIVO;04-N1110 (32 GB);4AD91JD5G;Ativo;Bom;CHECK OK 30
Notebook;POSITIVO;04-T2072;4AL26BG43;Ativo;Excelente;CHECK OK 04
Notebook;POSITIVO;05-N1110 (64 GB);4AD91JS15;Ativo;Bom;CHECK OK 20 FALTANDO 13 TECLAS
Notebook;POSITIVO;N1110 (64 GB);4AD91JV2J;Inativo;Danificado;CHECK OK 16 TECLADO INATIVO
Notebook;POSITIVO;06 - T2072;4AL26BH46;Ativo;Excelente;6
Notebook;POSITIVO;06-N1110 (64 GB);4AD91KD5N;Ativo;Bom;CHECK OK 017
Notebook;POSITIVO;07-N1110 (32 GB);4AD91612;Ativo;Excelente;
Tablet;POSITIVO;T2040;4AC26RP80;Manutenção;Danificado;Check ok T111 352930983056245
Tablet;POSITIVO;T2040;4AC30352G;Manutenção;Em análise;cHECK OK T110 352930983131717
Notebook;POSITIVO;08-N1110 (32 GB);4AD91JY8M;Ativo;Bom;CHECK OK  88
Notebook;POSITIVO;09-N1110 (64 GB);4AB41949N;Ativo;Bom;CHECK OK 16 TECLADO
Tablet;POSITIVO;T2040;4AC19778R;Manutenção;Danificado;Check ok t112 352930982720569
Notebook;POSITIVO;10-N1110 (32 GB);4AB72H06V;Ativo;Bom;Check ok bateria e armazenamento Etiqueta 32
Notebook;POSITIVO;11-N1110 (32 GB);4AD91JQ5J;Ativo;Bom;CHeck ok Etiqueta 21 FUNCIONANDO Uma tecla faltando
Notebook;POSITIVO;12-N1110 (32 GB);4AD91JY6C;Ativo;Excelente;cHECK OK 014 15 TECLAS FALTANDO MAS AINDA FUNCIONAL
Notebook;POSITIVO;13-N1110 (128 GB);4AD91JN45;Ativo;Bom;CHECK OK
Notebook;POSITIVO;14 - N1110 (32 GB);4AD91JXZP;Ativo;Excelente;
Notebook;POSITIVO;15-N1110 (32 GB);4AB41970N;Ativo;Bom;Check ok Etiqueta 01
Tablet;POSITIVO;T2040;4AC30382P;Manutenção;Em análise;CHECK OK T108
Notebook;POSITIVO;16-N1110 (64 GB);4AD91JR5M;Ativo;Excelente;CHECK OK 15
Notebook;POSITIVO;17-N1110 (64 GB);4AD91JW66;Ativo;Bom;CHECK OK 25 FALTA 9 TECLAS
Notebook;POSITIVO;18-N1110 (64 GB);4AD91JQ93;Ativo;Bom;Check ok etiqueta 05 TECLADO sem o enter
Notebook;POSITIVO;19-N1110 (64 GB);4AD91JJ30;Ativo;Bom;CHECK OK  08
Notebook;POSITIVO;20-N1110 (32 GB);4AD91KL46;Ativo;Bom;CHECK OK FUNCIONANDO 27 SALA 02
Notebook;POSITIVO;21-N1110 (128 GB);4AD91JW9L;Ativo;Bom;CHECK OK 19 FALTANDO 19 TECLAS
Notebook;POSITIVO;22-N1110 (128 GB);4AD91JD6L;Ativo;Bom;CHECK OK 09
Notebook;POSITIVO;23-N1110 (128 GB);4AD91JN1Q;Ativo;Bom;CHECK OK  12 FALTANDO 5 TECLAS
Notebook;POSITIVO;24-N1110 (128 GB);4AD91KY34;Ativo;Bom;CHECK OK 06
Notebook;POSITIVO;25-N1110 (128 GB);4AD91KQ16;Ativo;Bom;CHECK OK 87
Notebook;POSITIVO;26N1110 (32 GB);4AD91JL8J;Ativo;Bom;chECK OK 33
Notebook;POSITIVO;27-N1110 (32 GB);4AD91JL1K;Ativo;Bom;CHECK OK 06
Notebook;POSITIVO;28-N1110 (64 GB);4AB418X8Q;Ativo;Bom;CHECK OK 13 FALTANDO 3 TECLAS
Notebook;POSITIVO;29-N1110 (64 GB);4AB41972X;Ativo;Bom;CHECK OK 8
Notebook;POSITIVO;30-N1110 (128 GB);4AB41930B;Ativo;Bom;CHECK OK 20 FALTANDO DUAS TECLAS
Notebook;POSITIVO;31-N1110 (128 GB);4AB419F1G;Ativo;Bom;Check ok 89 FALTANDO UMA TECLA
Notebook;POSITIVO;32-N1110 (128 GB);4AD91JD21;Ativo;Bom;CHECK OK 06 TECLADO SEM UMA TECLA
Notebook;POSITIVO;33-N1110 (64 GB);4AD91JH18;Ativo;Bom;CHECK OK 38  FALTANDO 3 TECLAS
Notebook;POSITIVO;34N1110 (64 GB);4AD91JP90;Ativo;Bom;CHECK OK 21 FALTANDO 6 TECLAS
Notebook;POSITIVO;35-N1110 (128 GB);4AB419P1A;Ativo;Bom;CHECK OK 34
Notebook;POSITIVO;36-N1110 (64 GB);4AF189F4C;Ativo;Bom;CHECK OK 86
Notebook;POSITIVO;37-N1110 (128 GB);4AD91JV1E;Ativo;Bom;CHECK OK 09 FALTANDO 2 TECLAS
Notebook;POSITIVO;38-N1110 (128 GB);4AD91KK8N;Ativo;Regular;CHECK OK 07 FALTANDO 4 TECLAS
Notebook;POSITIVO;39-N1110 (32 GB);4AB41963Z;Ativo;Excelente;CHECK OK  14 10 TECLAS FORA
Notebook;POSITIVO;40-N1110 (32 GB);4AD91JK51;Ativo;Excelente;CHECK OK 28
Notebook;POSITIVO;41-N1110 (128 GB);4AD91JP4B;Ativo;Bom;CHECK OK  87
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY304571W;Manutenção;Danificado;CHECK OK  84
Notebook;POSITIVO;42-N1110 (64 GB);4AD91JC1T;Ativo;Bom;CHECK OK 34
Notebook;POSITIVO;43-N1110 (128 GB);4AD91JL4Z;Ativo;Bom;CHECK OK 21 FALTANDO 6 TECLAS
Notebook;POSITIVO;44-N1110 (32 GB);4AD91JJ2J;Ativo;Excelente;cHECK OK  06
Notebook;POSITIVO;45-N1110 (64 GB);4AD91KW9S;Ativo;Bom;CHECK OK 10 FALTANDO 9 TECLAS
Notebook;POSITIVO;46-N1110 (32 GB);4AD91JS3F;Ativo;Bom;CHECK OK 50
Notebook;LENOVO;IdeaPad S145;PE06SCKV;Ativo;Bom;Check ok
Notebook;LENOVO;IdeaPad S145;PE06SCL7;Ativo;Bom;check ok
Notebook;MULTILASER;ULTRABOOK UL150;270521233316999/SERIAL;Ativo;Bom;CHECK OK Utilizavel
Notebook;MULTILASER;ULTRABOOK UL150;260521204100728/SERIAL;Ativo;Bom;CHECK OK Utilizavel
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY304459T;Manutenção;Em análise;check ok  82
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY304253T;Manutenção;Em análise;CHECK OK  81
Notebook;MULTILASER;ULTRABOOK UL150;280521152500445/SERIAL;Ativo;Bom;CHECK OK Utilizavel
Outros;XIAOMI;2201117TG;37799/F2WD10131;Ativo;Bom;CHECK OK Celular DIREÇÃO
Outros;XIAOMI;23106RN0DA;51601/64QV04662;Ativo;Bom;CHECK OK Celular 7
Outros;XIAOMI;23106RN0DA;51221/63ZU05642;Ativo;Bom;CHECK OK Celular 2
Outros;XIAOMI;23106RN0DA;51598/64PP03381;Ativo;Bom;CHECK OK Celular 5
Outros;XIAOMI;23106RN0DA;51644/64R200526;Ativo;Bom;CHECK OK Celular 1
Outros;XIAOMI;2311DRN14I;51326/845404467;Ativo;Bom;CHECK OK  Celular 8
Outros;XIAOMI;2311DRN14I;51326/848404489;Ativo;Bom;CHECK OK Celular 9
Outros;REALME;23129RN51X;54094/64RB07891;Ativo;Bom;CHECK OK Celular 6
Outros;REALME;RMX3710;3505161310017410.;Ativo;Bom;CHECK OK Celular 3
Outros;REALME;RMX3710;3706161810007696.;Ativo;Bom;CHECK OK Celular 10
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY200188J;Manutenção;Danificado;check ok  83
Outros;REALME;RMX3710;3706161810004031.;Ativo;Bom;CHECK OK Celular 4
Tablet;POSITIVO;011-T2072;4AL26BN2E;Ativo;Excelente;CHECK OK 011
Tablet;POSITIVO;012-T2072;4AL21DL96;Ativo;Excelente;CHECK OK 012
Tablet;POSITIVO;013-T2072;4AL27F90T;Ativo;Excelente;CHECK OK 013
Tablet;POSITIVO;015-T2072;4AL21D58P;Ativo;Excelente;CHECK OK 015
Tablet;POSITIVO;018-T2072;4AL21F54J;Ativo;Excelente;CHECK OK 018
Tablet;POSITIVO;01-T2072;4AL26BL6S;Ativo;Excelente;CHECK OK 01
Tablet;POSITIVO;021-T2072;4AL27FH26;Ativo;Excelente;CHECK OK 021
Tablet;POSITIVO;023-T2072;4AL27FH9Q;Ativo;Excelente;CHECK OK 023
Tablet;POSITIVO;024-T2072;4AL26BN40;Ativo;Excelente;CHECK OK 024
Tablet;POSITIVO;026-T2072;4AL26BB19;Ativo;Excelente;CHECK OK 026
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY304440N;Manutenção;Danificado;check ok - Touchpad quebrado. Etiqueta nº 13
Tablet;POSITIVO;027-T2072;4AL27FJ2X;Ativo;Excelente;CHECK OK 027
Tablet;POSITIVO;028-T2072;4AL27FK35;Ativo;Excelente;CHECK OK 028
Tablet;POSITIVO;029-T2072;4AL27FG20;Ativo;Excelente;CHECK OK 029
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY304570X;Manutenção;Danificado;CHECK OK 80
Tablet;POSITIVO;02-T2072;4AL26BL97;Ativo;Excelente;CHECK OK 02
Chromebooks;SAMSUNG;Chromebook Samsung 4;0ANS9QCY200062F;Manutenção;Em análise;check ok 82
Notebook;SAMSUNG;N1110 (32 GB);SS03;Inativo;Danificado;CHECK OK TELA QUEBRADA
Tablet;POSITIVO;032-T2072;4AL21DP2J;Ativo;Excelente;CHECK OK 032
Tablet;POSITIVO;035-T2072;4AL26BB5T;Ativo;Excelente;CHECK OK 035
Tablet;POSITIVO;036-T2072;4AL26BL5N;Ativo;Excelente;CHECK OK 036
Tablet;POSITIVO;037-T2072;4AL26BK94;Ativo;Excelente;CHECK OK 037
Tablet;POSITIVO;038-T2072;4AL26BN04;Ativo;Excelente;CHECK OK 038
Tablet;POSITIVO;039-T2072;4AL26B982;Ativo;Excelente;CHECK OK 039
Tablet;POSITIVO;03-T2072;4AL26BS3Y;Ativo;Excelente;CHECK ON 03
Tablet;POSITIVO;041-T2072;4AL26C695;Ativo;Excelente;CHECK OK 041
Tablet;POSITIVO;042-T2072;4AL26BZ3J;Ativo;Excelente;CHECK OK 042
Tablet;POSITIVO;046-T2072;4AL26BM4L;Ativo;Excelente;CHECK OK 046
Tablet;POSITIVO;048-T2072;4AL26BM6V;Ativo;Excelente;CHECK OK 048
Tablet;POSITIVO;049-T2072;4AL26BS71;Ativo;Excelente;CHECK OK 049
Tablet;POSITIVO;053-T2072;4AL27FP74;Ativo;Excelente;CHECK OK 053
Tablet;POSITIVO;055-T2072;4AL26BM01;Ativo;Excelente;CHECK OK 055
Tablet;POSITIVO;05-T2072;4AL26BC5W;Ativo;Excelente;CHECK OK 05
Tablet;POSITIVO;061-T2072;4AL27FP2F;Ativo;Excelente;CHECK OK 061
Tablet;POSITIVO;065-T2072;4AL27FN83;Ativo;Excelente;CHECK OK 065
Tablet;POSITIVO;066-T2072;4AL26BM5Q;Ativo;Excelente;CHECK OK 066
Tablet;POSITIVO;068-T2072;4AL26BG3Y;Ativo;Excelente;CHECK OK 068
Tablet;POSITIVO;070-T2072;4AL21F583;Ativo;Excelente;CHECK OK 070
Tablet;POSITIVO;071-T2072;4AL26BQ2N;Ativo;Excelente;CHECK OK 071
Tablet;POSITIVO;072-T2072;4AL26BC2H;Ativo;Excelente;CHECK OK 072
Tablet;POSITIVO;073-T2072;4AL26BX28;Ativo;Excelente;CHECK OK 073
Tablet;POSITIVO;075-T2072;4AL26BF8K;Ativo;Excelente;CHECK OK 075
Tablet;POSITIVO;076-T2072;4AL26BN3J;Ativo;Excelente;CHECK OK 076
Tablet;POSITIVO;077-T2072;4AL26CQ44;Ativo;Excelente;CHECK OK 077
Tablet;POSITIVO;07-T2072;4AL21F73K;Ativo;Excelente;CHECK OK 07
Tablet;POSITIVO;081-T2072;4AL26BP0A;Ativo;Excelente;CHECK OK 081
Tablet;POSITIVO;084-T2072;4AL26BS58;Ativo;Excelente;CHECK OK 084
Tablet;POSITIVO;085-T2072;4AL26BP64;Ativo;Excelente;CHECK OK 085
Tablet;POSITIVO;089-T2072;4AL26BB9D;Ativo;Excelente;CHECK OK 089
Tablet;POSITIVO;08-T2072;4AL26BG0J;Ativo;Excelente;CHECK OK 08
Tablet;POSITIVO;098-T2072;4AL21F62C;Ativo;Excelente;CHECK OK 098
Tablet;POSITIVO;09-T2072;4AL26BK8Z;Ativo;Excelente;CHECK OK 09
Tablet;POSITIVO;100-T2040;4AC18K12V;Ativo;Bom;CHECK OK  T105 352930982718688
Tablet;POSITIVO;101-T2040;4AC299H4J;Ativo;Bom;check ok T114
Tablet;POSITIVO;102-T2040;4AC18K772;Ativo;Bom;CHECK OK 352930982718910 T101
Tablet;POSITIVO;103-T2040;4AC314411;Ativo;Bom;CHECK OK 352930983133366 T102
Tablet;POSITIVO;104-T2040;4AC26RQ29;Ativo;Bom;CHECK 352930983056260 T100
Tablet;POSITIVO;105-T2040;4AC18K56R;Ativo;Bom;CHECK OK T104 352930982718886
Tablet;POSITIVO;106-T2024;4AC18TZ9F;Ativo;Excelente;CHECK OK T103
Tablet;POSITIVO;107-T2040;4AC18XW8T;Ativo;Bom;CHECK OK T107 352930982716120
Tablet;POSITIVO;10-T2072;4AL26BG10;Ativo;Excelente;CHECK OK 10
Tablet;POSITIVO;13-T2072;4AL2F90T;Ativo;Excelente;CHECK OK 13
Tablet;POSITIVO;14-T2072;4AL210Z9C;Ativo;Excelente;CHECK OK 14
Tablet;POSITIVO;16-T2072;4AL21F550;Ativo;Excelente;CHECK OK 16
Tablet;POSITIVO;17-T2072;4AL21F50Z;Ativo;Excelente;CHECK OK 17
Tablet;POSITIVO;19-T2072;4A321D95Y;Ativo;Excelente;CHECK OK 19
Tablet;POSITIVO;20-T2072;4AL27FC4M;Ativo;Excelente;CHECK OK 20
Tablet;POSITIVO;22-T2072;4AL227FG7D;Ativo;Excelente;CHECK OK  22
Tablet;POSITIVO;25-T2072;4AL27F81V;Ativo;Excelente;CHECK OK 25
Tablet;POSITIVO;30-T2072;4AL27FF9K;Ativo;Excelente;CHECK OK  30
Tablet;POSITIVO;31-T2072;4AL26BR3V;Ativo;Excelente;CHECK OK 31
Tablet;POSITIVO;33-T2072;4L26BF55;Ativo;Excelente;CHECK OK 33
Tablet;POSITIVO;40-T2072;4AL26BK5N;Ativo;Excelente;CHECK OK 40
Tablet;POSITIVO;43-T2072;4AL26BN5T;Ativo;Excelente;CHECK OK 43
Tablet;POSITIVO;44-T2072;4AL26BC4R;Ativo;Excelente;CHECK OK 44
Tablet;POSITIVO;45-T2072;4AL26BS8N;Ativo;Excelente;CHECK OK 45
Tablet;POSITIVO;47-T2072;4AL21F808;Ativo;Excelente;CHECK OK 47
Tablet;POSITIVO;50-T2072;4AL26BG2T;Ativo;Excelente;CHECK OK 50
Tablet;POSITIVO;51-T2072;4AL27FF08;Ativo;Excelente;CHECK OK 51
Tablet;POSITIVO;52-T2072;4AL26BL7X;Ativo;Excelente;CHECK OK 52
Tablet;POSITIVO;54-T2072;4AL26B95Z;Ativo;Excelente;CHECK OK 54
Tablet;POSITIVO;56-T2072;4AL27FF65;Ativo;Excelente;CHECK OK 56
Tablet;POSITIVO;57-T2072;4AL27FG1J;Ativo;Excelente;CHECK OK 57
Tablet;POSITIVO;58-T2072;4AL26BK5K;Ativo;Excelente;CHECK OK 58
Tablet;POSITIVO;59-T2072;4AL27FM5L;Ativo;Excelente;CHECK OK 59
Tablet;POSITIVO;60-T2072;4AL26BJ0S;Ativo;Excelente;CHECK OK 60
Tablet;POSITIVO;62-T2072;4AL27FN14;Ativo;Excelente;CHECK OK 62
Tablet;POSITIVO;63-T2072;4AL27FH0H;Ativo;Excelente;CHECK OK 63
Tablet;POSITIVO;64-T2072;4AL27FM4G;Ativo;Excelente;CHECK OK 64
Tablet;POSITIVO;67-T2072;4AL21DL12;Ativo;Excelente;CHECK OK 67
Tablet;POSITIVO;69-T2072;4AL21F10N;Ativo;Excelente;CHECK OK 69
Tablet;POSITIVO;74-T2072;4AL26B85K;Ativo;Excelente;CHECK OK 74
Tablet;POSITIVO;77-T2072;4AL26CQ44;Ativo;Excelente;CHECK OK 77
Tablet;POSITIVO;78-T2072;4AL26B90Y;Ativo;Excelente;CHECK OK 78
Tablet;POSITIVO;79-T2072;4AL26BZ19;Ativo;Excelente;CHECK OK 79
Tablet;POSITIVO;80-T2072;4AL26CP56;Ativo;Excelente;CHECK OK 80
Tablet;POSITIVO;82-T2072;4AL26BS43;Ativo;Excelente;CHECK OK 82
Tablet;POSITIVO;83 - T2072;4AL21D38J;Ativo;Excelente;83
Tablet;POSITIVO;86-T2072;4AL26CQ2U;Ativo;Excelente;CHECK OK 86
Tablet;POSITIVO;87-T2072;4AL26BG58;Ativo;Excelente;CHECK OK 87
Tablet;POSITIVO;88-T2072;4AL26BH2W;Ativo;Excelente;CHECK OK 88
Tablet;POSITIVO;90-T2072;4AL26BV1X;Ativo;Excelente;CHECK OK 90
Tablet;POSITIVO;90-T2072;4AL26BV1X;Ativo;Excelente;CHECK OK 90
Tablet;POSITIVO;91-T2072;4AL26BT31;Ativo;Excelente;CHECK OK 91
Tablet;POSITIVO;92-T2072;4AL26BS6D;Ativo;Excelente;CHECK OK 92
Tablet;POSITIVO;93-T2072;4AL26BK7U;Ativo;Excelente;CHECK OK 93
Notebook;POSITIVO;SS01;SS01;Inativo;Danificado;CHECK OK S/ WIFI ETIQUETA 019
Tablet;POSITIVO;94-T2072;4AL26BP79;Ativo;Excelente;CHECK OK 94
Tablet;POSITIVO;95-T2072;4AL21F82I;Ativo;Excelente;CHECK OK 95
Tablet;POSITIVO;96-T2072;4AL21F25F;Ativo;Excelente;CHECK OK 96
Tablet;POSITIVO;97-T2072;4AL21F044;Ativo;Excelente;97
Tablet;POSITIVO;99-T2040;4AC26RWOH;Ativo;Bom;CHECK OK T 106 352930983056146
Tablet;POSITIVO;T2024;SS04;Ativo;Excelente;check ok t113
Tablet;POSITIVO;T2040;4AC18XZ82;Ativo;Bom;CHECK OK T109 352930982718449`;

export function parseCSVEquipamentos(csvText: string): any[] {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length <= 1) return [];

  // Identificar delimitador (; ou ,)
  const headerLine = lines[0];
  const delimiter = headerLine.includes(';') ? ';' : ',';
  const headers = headerLine.split(delimiter).map(h => h.trim().toUpperCase());

  const items: any[] = [];

  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine) continue;

    const cols = rawLine.split(delimiter).map(c => c.trim());
    if (cols.length === 0) continue;

    // Mapeamento flexível
    let categoria = 'Outros';
    let fabricante = '';
    let modelo = '';
    let numeroSerie = '';
    let statusEquipamento = 'Ativo';
    let avaliacaoTecnica = 'Bom';
    let descricao = '';

    headers.forEach((h, idx) => {
      const val = cols[idx] || '';
      if (h.includes('CATEGORIA')) categoria = val || categoria;
      else if (h.includes('FABRICANTE')) fabricante = val;
      else if (h.includes('MODELO')) modelo = val;
      else if (h.includes('SÉRIE') || h.includes('SERIE') || h.includes('PATRIMONIO') || h.includes('PATRIMÔNIO')) numeroSerie = val;
      else if (h.includes('STATUS')) statusEquipamento = val || statusEquipamento;
      else if (h.includes('AVALIAÇÃO') || h.includes('AVALIACAO') || h.includes('ESTADO')) avaliacaoTecnica = val || avaliacaoTecnica;
      else if (h.includes('DESCRIÇÃO') || h.includes('DESCRICAO') || h.includes('OBS')) descricao = val;
    });

    // Se o header não coincidiu (fallback por índice posicional padrão do CSV)
    if (!modelo && cols.length >= 3) {
      categoria = cols[0] || 'Outros';
      fabricante = cols[1] || '';
      modelo = cols[2] || '';
      numeroSerie = cols[3] || '';
      statusEquipamento = cols[4] || 'Ativo';
      avaliacaoTecnica = cols[5] || 'Bom';
      descricao = cols[6] || '';
    }

    // Normalizar categoria
    let catNormalizada = categoria;
    const catUpper = categoria.toUpperCase();
    if (catUpper.includes('CHROMEBOOK')) catNormalizada = 'Chromebooks';
    else if (catUpper.includes('NOTEBOOK')) catNormalizada = 'Notebook';
    else if (catUpper.includes('DESKTOP')) catNormalizada = 'Desktop';
    else if (catUpper.includes('TABLET')) catNormalizada = 'Tablet';
    else if (catUpper.includes('3D')) catNormalizada = 'Impressão 3D';
    else if (catUpper.includes('FERRAMENTA')) catNormalizada = 'Ferramentas';
    else if (catUpper.includes('AUDIO') || catUpper.includes('VÍDEO') || catUpper.includes('VIDEO')) catNormalizada = 'Audiovisual';
    else if (catUpper.includes('ELETRÔN') || catUpper.includes('ELETRON')) catNormalizada = 'Eletrônicos';
    else if (catUpper.includes('INFORMÁT') || catUpper.includes('INFORMAT')) catNormalizada = 'Informática';
    else if (catUpper.includes('ROBÓT') || catUpper.includes('ROBOT')) catNormalizada = 'Robótica';
    else catNormalizada = 'Outros';

    // Normalizar estado de conservação
    let estadoConservacao = 'Bom';
    const avUpper = avaliacaoTecnica.toUpperCase();
    if (avUpper.includes('EXCELENTE') || avUpper.includes('NOVO')) estadoConservacao = 'Novo';
    else if (avUpper.includes('BOM') || avUpper.includes('REGULAR')) estadoConservacao = 'Bom';
    else if (avUpper.includes('DANIFICADO') || avUpper.includes('REPARO') || avUpper.includes('MANUTENÇÃO') || avUpper.includes('ANÁLISE') || avUpper.includes('ANALISE')) estadoConservacao = 'Precisa de Reparo';
    else if (avUpper.includes('INOPERANTE') || avUpper.includes('INATIVO')) estadoConservacao = 'Inoperante';

    // Montar nome descritivo
    const nomeComposto = [fabricante, modelo].filter(Boolean).join(' ') || `Item ${i}`;

    // Observações combinando avaliação original e descrição
    const obsParts: string[] = [];
    if (descricao) obsParts.push(descricao);
    if (statusEquipamento && statusEquipamento !== 'Ativo') obsParts.push(`Status: ${statusEquipamento}`);
    if (avaliacaoTecnica) obsParts.push(`Condição: ${avaliacaoTecnica}`);

    items.push({
      nome: nomeComposto.slice(0, 200),
      patrimonio: numeroSerie.slice(0, 100),
      categoria: catNormalizada,
      estadoConservacao: estadoConservacao,
      quantidade: 1,
      localizacao: 'Armário / Sala TI',
      observacoes: obsParts.join(' | ').slice(0, 1000),
      fabricante: fabricante.slice(0, 100),
      modelo: modelo.slice(0, 150),
      numeroSerie: numeroSerie.slice(0, 100),
      statusEquipamento: statusEquipamento.slice(0, 50),
      avaliacaoTecnica: avaliacaoTecnica.slice(0, 50),
      importedAt: new Date().toISOString()
    });
  }

  return items;
}
